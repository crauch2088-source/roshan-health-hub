//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BDdTCLuo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/repo/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/setup"
		],
		preloads: [
			"/assets/index-cxURt-Qn.js",
			"/assets/i18n-Ck9Teb2i.js",
			"/assets/link-BduzYzS1.js",
			"/assets/preload-helper-5AidsvkQ.js",
			"/assets/useMatch-Bv4JVF7Q.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-cxURt-Qn.js"
		} }]
	},
	"/": {
		filePath: "/home/user/repo/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-COywBSIu.js",
			"/assets/useNavigate-DdCOwrZY.js",
			"/assets/db-Cpk46L67.js"
		]
	},
	"/_authenticated": {
		filePath: "/home/user/repo/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounting",
			"/_authenticated/analytics",
			"/_authenticated/appointments",
			"/_authenticated/audit",
			"/_authenticated/billing",
			"/_authenticated/certificates",
			"/_authenticated/clinic",
			"/_authenticated/dashboard",
			"/_authenticated/expenses",
			"/_authenticated/finance",
			"/_authenticated/followups",
			"/_authenticated/insurance",
			"/_authenticated/inventory",
			"/_authenticated/lab",
			"/_authenticated/lab-catalog",
			"/_authenticated/partners",
			"/_authenticated/patients",
			"/_authenticated/pharmacy",
			"/_authenticated/queue",
			"/_authenticated/reports",
			"/_authenticated/settings",
			"/_authenticated/users",
			"/_authenticated/visits",
			"/_authenticated/billing_/$invoiceId",
			"/_authenticated/clinic_/$visitId",
			"/_authenticated/lab_/$orderId",
			"/_authenticated/patients_/$patientId"
		],
		preloads: [
			"/assets/route-TqIL4I7_.js",
			"/assets/useNavigate-DdCOwrZY.js",
			"/assets/kit-BORJPru5.js",
			"/assets/wallet-BMFecPvF.js",
			"/assets/stethoscope-BcVIrFsZ.js",
			"/assets/dist-YGK52Wfy.js",
			"/assets/flask-conical-BIb0cf9i.js",
			"/assets/landmark-Bp2GoUFQ.js",
			"/assets/plus-B_XPxSIl.js",
			"/assets/receipt-BQvJfjcW.js",
			"/assets/shield-check-CGH4wZe4.js",
			"/assets/users-C9LlCqVC.js",
			"/assets/dist-DAZVaeDq.js",
			"/assets/es2015-D681WoG0.js",
			"/assets/dialog-C3KHQQF4.js",
			"/assets/dist-BCk1FJlF.js",
			"/assets/dist-4LrANmku.js",
			"/assets/command-B_kpNQlH.js",
			"/assets/search-DvJgRhgY.js",
			"/assets/dist-B83ubVoH.js"
		]
	},
	"/auth": {
		filePath: "/home/user/repo/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CTb5UEM7.js",
			"/assets/useNavigate-DdCOwrZY.js",
			"/assets/db-Cpk46L67.js",
			"/assets/kit-BORJPru5.js",
			"/assets/card-UDmMXW42.js"
		]
	},
	"/setup": {
		filePath: "/home/user/repo/src/routes/setup.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-DpoNB8FJ.js",
			"/assets/useNavigate-DdCOwrZY.js",
			"/assets/db-Cpk46L67.js",
			"/assets/kit-BORJPru5.js",
			"/assets/circle-check-CzPw0iVS.js",
			"/assets/card-UDmMXW42.js"
		]
	},
	"/_authenticated/accounting": {
		filePath: "/home/user/repo/src/routes/_authenticated/accounting.tsx",
		children: void 0,
		preloads: [
			"/assets/accounting-CEkscDk4.js",
			"/assets/db-Cpk46L67.js",
			"/assets/truck-aUarEoEw.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/analytics": {
		filePath: "/home/user/repo/src/routes/_authenticated/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-CD5Jg-BN.js",
			"/assets/db-Cpk46L67.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Cs3Cesej.js"
		]
	},
	"/_authenticated/appointments": {
		filePath: "/home/user/repo/src/routes/_authenticated/appointments.tsx",
		children: void 0,
		preloads: [
			"/assets/appointments-Bu4NMMt-.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/patient-picker-BwWQ8AF8.js",
			"/assets/trash-2-BWzV5Axh.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/audit": {
		filePath: "/home/user/repo/src/routes/_authenticated/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-DXsYmtDm.js",
			"/assets/db-Cpk46L67.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/billing": {
		filePath: "/home/user/repo/src/routes/_authenticated/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-B-2Onzbs.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/patient-picker-BwWQ8AF8.js",
			"/assets/trash-2-BWzV5Axh.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/certificates": {
		filePath: "/home/user/repo/src/routes/_authenticated/certificates.tsx",
		children: void 0,
		preloads: [
			"/assets/certificates-D498RW_b.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/patient-picker-BwWQ8AF8.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/clinic": {
		filePath: "/home/user/repo/src/routes/_authenticated/clinic.tsx",
		children: void 0,
		preloads: [
			"/assets/clinic-Bd7Gxams.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/home/user/repo/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-C9QSD4EJ.js",
			"/assets/db-Cpk46L67.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/pharmacy-CDLv5QU7.js"
		]
	},
	"/_authenticated/expenses": {
		filePath: "/home/user/repo/src/routes/_authenticated/expenses.tsx",
		children: void 0,
		preloads: [
			"/assets/expenses-CqtPXzGl.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/finance": {
		filePath: "/home/user/repo/src/routes/_authenticated/finance.tsx",
		children: void 0,
		preloads: [
			"/assets/finance-Cbk7aqze.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Cs3Cesej.js"
		]
	},
	"/_authenticated/followups": {
		filePath: "/home/user/repo/src/routes/_authenticated/followups.tsx",
		children: void 0,
		preloads: [
			"/assets/followups-CXMc97Ht.js",
			"/assets/db-Cpk46L67.js",
			"/assets/patient-picker-BwWQ8AF8.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/insurance": {
		filePath: "/home/user/repo/src/routes/_authenticated/insurance.tsx",
		children: void 0,
		preloads: [
			"/assets/insurance-DcE9lYSF.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/patient-picker-BwWQ8AF8.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Cs3Cesej.js"
		]
	},
	"/_authenticated/inventory": {
		filePath: "/home/user/repo/src/routes/_authenticated/inventory.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory-CF_zmwKH.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/truck-aUarEoEw.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Cs3Cesej.js",
			"/assets/pharmacy-CDLv5QU7.js"
		]
	},
	"/_authenticated/lab": {
		filePath: "/home/user/repo/src/routes/_authenticated/lab.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-BD82SHo2.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/lab-catalog": {
		filePath: "/home/user/repo/src/routes/_authenticated/lab-catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-catalog-CNfMyszH.js",
			"/assets/db-Cpk46L67.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/switch-BMu8M8wZ.js"
		]
	},
	"/_authenticated/partners": {
		filePath: "/home/user/repo/src/routes/_authenticated/partners.tsx",
		children: void 0,
		preloads: [
			"/assets/partners-CBOV_fzH.js",
			"/assets/db-Cpk46L67.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js"
		]
	},
	"/_authenticated/patients": {
		filePath: "/home/user/repo/src/routes/_authenticated/patients.tsx",
		children: void 0,
		preloads: [
			"/assets/patients-06BnK__e.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/pharmacy": {
		filePath: "/home/user/repo/src/routes/_authenticated/pharmacy.tsx",
		children: void 0,
		preloads: [
			"/assets/pharmacy-Bd7wbx5i.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/pharmacy-CDLv5QU7.js"
		]
	},
	"/_authenticated/queue": {
		filePath: "/home/user/repo/src/routes/_authenticated/queue.tsx",
		children: void 0,
		preloads: [
			"/assets/queue-CLeK2IX_.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/user/repo/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DwLpFtBv.js",
			"/assets/db-Cpk46L67.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Cs3Cesej.js",
			"/assets/pharmacy-CDLv5QU7.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/user/repo/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CszNl9Qe.js",
			"/assets/db-Cpk46L67.js",
			"/assets/card-UDmMXW42.js"
		]
	},
	"/_authenticated/users": {
		filePath: "/home/user/repo/src/routes/_authenticated/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-CAQk0mFm.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/switch-BMu8M8wZ.js"
		]
	},
	"/_authenticated/visits": {
		filePath: "/home/user/repo/src/routes/_authenticated/visits.tsx",
		children: void 0,
		preloads: [
			"/assets/visits-DTzJoaY7.js",
			"/assets/db-Cpk46L67.js",
			"/assets/select-UecZCct3.js",
			"/assets/patient-picker-BwWQ8AF8.js",
			"/assets/trash-2-BWzV5Axh.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/billing_/$invoiceId": {
		filePath: "/home/user/repo/src/routes/_authenticated/billing_.$invoiceId.tsx",
		children: void 0,
		preloads: [
			"/assets/billing_._invoiceId-Dl1JOHzC.js",
			"/assets/useParams-CGFb77ll.js",
			"/assets/db-Cpk46L67.js",
			"/assets/arrow-left-nWjfXtaS.js",
			"/assets/select-UecZCct3.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/clinic_/$visitId": {
		filePath: "/home/user/repo/src/routes/_authenticated/clinic_.$visitId.tsx",
		children: void 0,
		preloads: [
			"/assets/clinic_._visitId-Cj9XuO8x.js",
			"/assets/db-Cpk46L67.js",
			"/assets/arrow-left-nWjfXtaS.js",
			"/assets/select-UecZCct3.js",
			"/assets/circle-check-CzPw0iVS.js",
			"/assets/card-UDmMXW42.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/lab_/$orderId": {
		filePath: "/home/user/repo/src/routes/_authenticated/lab_.$orderId.tsx",
		children: void 0,
		preloads: [
			"/assets/lab_._orderId-qUN_BgbP.js",
			"/assets/useParams-CGFb77ll.js",
			"/assets/db-Cpk46L67.js",
			"/assets/arrow-left-nWjfXtaS.js",
			"/assets/circle-check-CzPw0iVS.js",
			"/assets/card-UDmMXW42.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/patients_/$patientId": {
		filePath: "/home/user/repo/src/routes/_authenticated/patients_.$patientId.tsx",
		children: void 0,
		preloads: [
			"/assets/patients_._patientId-BecqFV0t.js",
			"/assets/useParams-CGFb77ll.js",
			"/assets/db-Cpk46L67.js",
			"/assets/arrow-left-nWjfXtaS.js",
			"/assets/select-UecZCct3.js",
			"/assets/table-Dz7IIFZw.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Cs3Cesej.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
