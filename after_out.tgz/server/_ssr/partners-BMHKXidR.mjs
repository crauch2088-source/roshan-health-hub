import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, l as useSave, o as s, r as n } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as Plus } from "../_libs/lucide-react.mjs";
import { _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-BmCdZVQb.mjs";
import { n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-ChVCEi1n.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/partners-BMHKXidR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PartnersPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "partners.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnersPageInner, {})
	});
}
function PartnersPageInner() {
	const { t } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		contact_person: "",
		phone: "",
		discount_percent: "0"
	});
	const list = useRows(["partners-all"], () => supabase.from("partners").select("*").is("deleted_at", null).order("name", { ascending: true }));
	const create = useSave(async () => {
		const { error } = await supabase.from("partners").insert({
			name: form.name,
			contact_person: form.contact_person || null,
			phone: form.phone || null,
			discount_percent: Number(form.discount_percent) || 0
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["partners-all"], ["partners"]],
		successMessage: t("saved"),
		onDone: () => setOpen(false)
	});
	const rows = list.data ?? [];
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("partners"),
			subtitle: t("contracted_entities"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-partners"
			}), can("partners.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t("add")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("partners") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("name")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("contact_person"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.contact_person,
									onChange: (e) => setForm({
										...form,
										contact_person: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("phone"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.phone,
									onChange: (e) => setForm({
										...form,
										phone: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("discount_percent"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									dir: "ltr",
									min: 0,
									max: 100,
									value: form.discount_percent,
									onChange: (e) => setForm({
										...form,
										discount_percent: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.name || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				] })]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("contact_person") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("phone") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("discount_percent") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: s(p, "name")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(p, "contact_person") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(p, "phone") || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						dir: "ltr",
						children: [n(p, "discount_percent"), "%"]
					})
				] }, s(p, "id"))) })]
			})
		}) })
	] });
}
//#endregion
export { PartnersPage as component };
