import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as csvExport } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { $ as ChevronLeft, A as LoaderCircle, F as Inbox, H as FileDown, Q as ChevronRight, S as Printer, c as TriangleAlert, g as Search, p as ShieldOff, t as X } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Label$1 } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kit-asLB5pSR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-semibold cursor-pointer transition-[background-color,color,border-color,box-shadow,transform] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 focus-visible:ring-offset-1 focus-visible:ring-offset-background active:translate-y-px disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed disabled:translate-y-0 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-sm hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent/80 hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4 py-2 sm:h-9",
			sm: "h-9 rounded-md px-3 text-xs sm:h-8",
			lg: "h-11 rounded-md px-6",
			icon: "size-10 sm:size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base shadow-xs transition-[border-color,box-shadow] placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/20 disabled:cursor-not-allowed disabled:bg-muted/40 disabled:opacity-60 md:h-9 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Label$1.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full resize-y rounded-md border border-input bg-background px-3 py-2 text-base shadow-xs transition-[border-color,box-shadow] placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/20 disabled:cursor-not-allowed disabled:bg-muted/40 disabled:opacity-60 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function PageHeader({ title, subtitle, eyebrow, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "no-print mb-5 grid grid-cols-1 items-end gap-3 border-b border-border pb-4 sm:mb-6 sm:grid-cols-[minmax(0,1fr)_auto]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 space-y-1",
			children: [
				eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold text-primary rtl:tracking-normal sm:tracking-wide",
					children: eyebrow
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "truncate text-xl font-extrabold tracking-tight text-foreground rtl:tracking-normal sm:text-2xl",
					children: title
				}),
				subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl text-sm text-muted-foreground",
					children: subtitle
				}) : null
			]
		}), children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex w-full flex-wrap items-center gap-2 sm:w-auto sm:justify-end [&>*]:max-w-full",
			children
		}) : null]
	});
}
function Loading() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-24 items-center justify-center gap-2 p-6 text-sm text-muted-foreground",
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }),
			" ",
			t("loading")
		]
	});
}
/** Skeleton rows for table/list areas — used where a spinner alone reads as "stuck" on slower connections. */
function LoadingRows({ count = 4 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 p-4",
		role: "status",
		children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full animate-pulse rounded-md bg-muted/60" }, i))
	});
}
function ErrorBox({ error, onRetry }) {
	const { t } = useLang();
	if (!error) return null;
	const message = error instanceof Error ? error.message : String(error);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "alert",
		className: "mb-4 flex items-start gap-2.5 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "mt-0.5 size-4 shrink-0",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 break-words",
				children: message
			}),
			onRetry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				className: "shrink-0",
				onClick: onRetry,
				children: t("retry")
			}) : null
		]
	});
}
/** Empty result of an active search or filter: offers to clear it. */
function NoResults({ onClear }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
			className: "size-5",
			"aria-hidden": true
		}),
		title: t("no_results"),
		action: onClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			onClick: onClear,
			children: t("clear")
		}) : void 0
	});
}
function Empty({ label, title, description, action, icon }) {
	const { t } = useLang();
	const heading = title ?? label ?? t("no_data");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 px-5 py-10 text-center sm:py-12",
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-11 items-center justify-center rounded-lg bg-muted/80 text-muted-foreground",
				children: icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, {
					className: "size-5",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-foreground",
					children: heading
				}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-xs text-muted-foreground",
					children: description
				}) : null]
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pt-1",
				children: action
			}) : null
		]
	});
}
/** Full-page access denied state used by PermissionGate. */
function Forbidden({ message }) {
	const { t, lang } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[50vh] flex-col items-center justify-center gap-4 px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, {
					className: "size-6",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight",
					children: lang === "ar" ? "غير مصرح" : "Access denied"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm text-muted-foreground",
					children: message ?? t("no_permission")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					children: lang === "ar" ? "العودة للرئيسية" : "Back to dashboard"
				})
			})
		]
	});
}
/**
* Gate that renders children only when the user holds the required permission.
* Fails closed while permissions are loading or when the user lacks access.
*/
function PermissionGate({ perm, children, fallback }) {
	const { can, permissionsReady, loading } = useAuth();
	if (loading || !permissionsReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	if (!(Array.isArray(perm) ? perm : [perm]).some((p) => can(p))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Forbidden, {}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
/** Lightweight page-level skeleton for first paint. */
function PageSkeleton({ rows = 5 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 p-1",
		role: "status",
		"aria-busy": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-7 w-48 max-w-full animate-pulse rounded-md bg-muted/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-72 max-w-full animate-pulse rounded-md bg-muted/50" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-20 animate-pulse rounded-lg bg-muted/60" }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingRows, { count: rows })
		]
	});
}
var metricTones = {
	default: "text-foreground",
	primary: "text-primary",
	success: "text-success",
	warning: "text-warning",
	destructive: "text-destructive"
};
/** One figure inside a MetricStrip: hairline-separated, no card chrome of its own. */
function Metric({ label, value, hint, tone = "default", icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-1 border-s border-t border-border p-3.5 max-sm:[&:nth-child(odd):last-child]:col-span-2 sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs font-medium",
					children: label
				}), icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 [&_svg]:size-4",
					children: icon
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("truncate text-xl font-extrabold tabular-nums leading-tight sm:text-2xl", metricTones[tone]),
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
/**
* Summary figures as one joined surface instead of a grid of separate cards.
* Internal dividers come from each Metric's own start/top border; the outer
* edge is clipped, so any number of metrics wraps cleanly at every width.
*/
function MetricStrip({ children, cols = "sm:grid-cols-3 xl:grid-cols-4", label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: label ? "group" : void 0,
		"aria-label": label,
		className: "overflow-hidden rounded-xl border border-border bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("-ms-px -mt-px grid grid-cols-2", cols),
			children
		})
	});
}
/** Standalone metric (kept for pages that place a single figure). */
function StatCard(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden rounded-xl border border-border bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "-ms-px -mt-px",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, { ...props })
		})
	});
}
function Field({ label, children, hint, className }) {
	const uid = (0, import_react.useId)();
	const labelId = `${uid}-label`;
	const hintId = `${uid}-hint`;
	const control = (0, import_react.isValidElement)(children) && (children.type === Input || children.type === Textarea) ? children : null;
	const controlId = control ? control.props.id ?? `${uid}-control` : null;
	const rendered = control && controlId ? (0, import_react.cloneElement)(control, {
		id: controlId,
		...hint && !control.props["aria-describedby"] ? { "aria-describedby": hintId } : {}
	}) : children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-1.5", className),
		role: "group",
		"aria-labelledby": labelId,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				id: labelId,
				...controlId ? { htmlFor: controlId } : {},
				className: "text-xs font-semibold text-foreground/80",
				children: label
			}),
			rendered,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: hintId,
				className: "text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
var statusTones = {
	waiting: "bg-warning/15 text-warning border-warning/30",
	pending: "bg-warning/15 text-warning border-warning/30",
	in_progress: "bg-primary/15 text-primary border-primary/30",
	collected: "bg-primary/15 text-primary border-primary/30",
	completed: "bg-success/15 text-success border-success/30",
	verified: "bg-success/15 text-success border-success/30",
	dispensed: "bg-success/15 text-success border-success/30",
	scheduled: "bg-primary/15 text-primary border-primary/30",
	paid: "bg-success/15 text-success border-success/30",
	partial: "bg-warning/15 text-warning border-warning/30",
	unpaid: "bg-destructive/15 text-destructive border-destructive/30",
	open: "bg-warning/15 text-warning border-warning/30",
	reversed: "bg-muted text-muted-foreground",
	cancelled: "bg-muted text-muted-foreground",
	no_show: "bg-muted text-muted-foreground",
	missed: "bg-destructive/15 text-destructive border-destructive/30",
	inactive: "bg-muted text-muted-foreground",
	active: "bg-success/15 text-success border-success/30",
	suspended: "bg-warning/15 text-warning border-warning/30",
	expired: "bg-destructive/15 text-destructive border-destructive/30",
	draft: "bg-muted text-muted-foreground",
	submitted: "bg-primary/15 text-primary border-primary/30",
	under_review: "bg-primary/15 text-primary border-primary/30",
	approved: "bg-success/15 text-success border-success/30",
	partially_approved: "bg-warning/15 text-warning border-warning/30",
	rejected: "bg-destructive/15 text-destructive border-destructive/30"
};
function StatusBadge({ status }) {
	const { t } = useLang();
	const key = (status || "").toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		variant: "outline",
		className: cn("gap-1.5 rounded-full px-2.5 font-medium transition-colors", statusTones[key] ?? ""),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			className: "size-1.5 shrink-0 rounded-full bg-current"
		}), t(key) === key ? status || "—" : t(key)]
	});
}
function ExportButtons({ rows, filename }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => csvExport(rows, filename),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "size-4" }),
				" ",
				t("export_excel")
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => window.print(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }),
				" ",
				t("print")
			]
		})]
	});
}
function PrintButton() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size: "sm",
		className: "no-print",
		onClick: () => window.print(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }),
			" ",
			t("print")
		]
	});
}
/** Prev/next pagination bar for tables driven by usePagedRows(). */
function Pager({ page, pageCount, count, pageSize, hasPrev, hasNext, onPrev, onNext, isFetching }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-t border-border/70 bg-muted/20 p-3 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: count != null ? `${t("page")} ${page} ${t("of")} ${pageCount ?? 1} · ${count} ${t("records")}` : `${t("page")} ${page}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				disabled: !hasPrev || isFetching,
				onClick: onPrev,
				"aria-label": t("previous"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 rtl:rotate-180" }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: t("previous")
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				disabled: !hasNext || isFetching,
				onClick: onNext,
				"aria-label": t("next"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: t("next")
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 rtl:rotate-180" })
				]
			})]
		})]
	});
}
function SectionTitle({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
		className: "mb-3 mt-1 flex items-center gap-3 text-[13px] font-bold text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			className: "h-px flex-1 bg-border"
		})]
	});
}
/**
* The one surface for lists and tables: hairline border, no shadow, optional
* title row with an icon, a count and a trailing action. Body is flush, so
* tables and divided lists run edge to edge.
*/
function DataPanel({ title, icon, count, action, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("min-w-0 overflow-hidden rounded-xl border border-border bg-card", className),
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex min-h-12 items-center justify-between gap-3 border-b border-border px-4 py-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex min-w-0 items-center gap-2 text-sm font-bold text-foreground",
				children: [
					icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 [&_svg]:size-4",
						children: icon
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: title
					}),
					count != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold tabular-nums text-muted-foreground",
						children: count
					}) : null
				]
			}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: action
			}) : null]
		}) : null, children]
	});
}
/** Row of search and filter controls above a list. */
function Toolbar({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("no-print flex flex-wrap items-center gap-2 sm:gap-3", className),
		children
	});
}
/** Search box shared by list pages: leading icon, clear button, 44px touch height. */
function SearchField({ value, onChange, placeholder, label, className }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative min-w-0 flex-1 basis-60", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				"aria-hidden": true,
				className: "pointer-events-none absolute start-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "search",
				placeholder: placeholder ?? t("search"),
				"aria-label": label ?? placeholder ?? t("search"),
				value,
				onChange: (e) => onChange(e.target.value),
				className: "h-11 rounded-lg border-border bg-card ps-10 pe-10 text-sm [&::-webkit-search-cancel-button]:appearance-none"
			}),
			value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(""),
				"aria-label": t("clear"),
				className: "absolute end-1 top-1/2 flex size-9 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
					className: "size-4",
					"aria-hidden": true
				})
			}) : null
		]
	});
}
/** Round initial (first letter of a name) used as the identity mark in lists and headers. */
function InitialAvatar({ name, size = "md" }) {
	const initial = (name || "").trim().charAt(0).toUpperCase() || "•";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-hidden": true,
		className: cn("flex shrink-0 items-center justify-center rounded-full bg-primary/10 font-bold text-primary", size === "lg" ? "size-14 text-xl" : "size-10 text-base"),
		children: initial
	});
}
/** Phone list row: identity and context on the start side, one action on the end side. */
function RecordRow({ main, trailing, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0",
			children: main
		}), trailing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0",
			children: trailing
		}) : null]
	});
}
/**
* Identity strip for a record (patient, visit, order): who it is, the facts a
* clinician scans first, and the actions that belong to the whole record.
*/
function DetailHeader({ name, facts, actions, eyebrow }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "no-print mb-5 rounded-xl border border-border bg-card p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-start gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InitialAvatar, {
					name,
					size: "lg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 basis-56 space-y-1",
					children: [eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold text-primary",
						children: eyebrow
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "break-words text-xl font-extrabold leading-tight tracking-tight rtl:tracking-normal sm:text-2xl",
						children: name
					})]
				}),
				actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex w-full flex-wrap items-center gap-2 sm:w-auto",
					children: actions
				}) : null
			]
		}), facts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-4 grid grid-cols-2 gap-x-4 gap-y-3 border-t border-border pt-4 sm:grid-cols-[repeat(auto-fit,minmax(8rem,1fr))]",
			children: facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs font-medium text-muted-foreground",
					children: f.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-0.5 truncate text-sm font-semibold text-foreground",
					children: f.value
				})]
			}, f.label))
		}) : null]
	});
}
//#endregion
export { cn as A, SearchField as C, Textarea as D, StatusBadge as E, Toolbar as O, RecordRow as S, StatCard as T, PageHeader as _, Empty as a, PermissionGate as b, Field as c, Input as d, Loading as f, NoResults as g, MetricStrip as h, DetailHeader as i, buttonVariants as k, Forbidden as l, Metric as m, Button as n, ErrorBox as o, LoadingRows as p, DataPanel as r, ExportButtons as s, Badge as t, InitialAvatar as u, PageSkeleton as v, SectionTitle as w, PrintButton as x, Pager as y };
