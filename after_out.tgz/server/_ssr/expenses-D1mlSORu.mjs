import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { C as Plus } from "../_libs/lucide-react.mjs";
import { D as Textarea, T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-asLB5pSR.mjs";
import { n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-WDSquJSC.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, c as todayISO, n as EXPENSE_CATEGORIES, s as money } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DcyYd86X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/expenses-D1mlSORu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExpensesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "accounting.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpensesPageInner, {})
	});
}
function ExpensesPageInner() {
	const { t } = useLang();
	const { can, user } = useAuth();
	const { currency } = useSettings();
	const [month, setMonth] = (0, import_react.useState)(todayISO().slice(0, 7));
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		category: EXPENSE_CATEGORIES[0] ?? "other",
		amount: "0",
		description: "",
		expense_date: todayISO()
	});
	const list = useRows(["expenses", month], () => supabase.from("expenses").select("*").gte("expense_date", `${month}-01`).lte("expense_date", `${month}-31`).is("deleted_at", null).order("expense_date", { ascending: false }));
	const create = useSave(async () => {
		const { error } = await supabase.from("expenses").insert({
			category: form.category,
			amount: Number(form.amount) || 0,
			description: form.description || null,
			expense_date: form.expense_date,
			created_by: user?.id ?? null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["expenses", month], ["acc-expenses"]],
		successMessage: t("saved"),
		onDone: () => setOpen(false)
	});
	const rows = list.data ?? [];
	const total = rows.reduce((sum, r) => sum + n(r, "amount"), 0);
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("expenses"),
			subtitle: month,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "month",
					dir: "ltr",
					value: month,
					onChange: (e) => setMonth(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: `roshan-expenses-${month}`
				}),
				can("accounting.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
								" ",
								t("add")
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("expenses") }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("category"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.category,
										onValueChange: (v) => setForm({
											...form,
											category: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: EXPENSE_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: c,
											children: t(c)
										}, c)) })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("amount"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										dir: "ltr",
										value: form.amount,
										onChange: (e) => setForm({
											...form,
											amount: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("date"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										dir: "ltr",
										value: form.expense_date,
										onChange: (e) => setForm({
											...form,
											expense_date: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("description"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										rows: 2,
										value: form.description,
										onChange: (e) => setForm({
											...form,
											description: e.target.value
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setOpen(false),
							children: t("cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: create.isPending,
							onClick: () => create.mutate(void 0),
							children: create.isPending ? t("saving") : t("save")
						})] })
					] })]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: t("total"),
				value: money(total, currency)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: t("records"),
				value: String(rows.length)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("category") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("description") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: formatDate(s(e, "expense_date"))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: t(s(e, "category")) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(e, "description") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(e, "amount"), currency) })
				] }, s(e, "id"))) })]
			})
		}) })
	] });
}
//#endregion
export { ExpensesPage as component };
