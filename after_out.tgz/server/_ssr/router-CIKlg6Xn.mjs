import { i as __toESM, t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { C as useRouter, J as redirect, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as dbError, r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CIKlg6Xn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var Ctx = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [session, setSession] = (0, import_react.useState)(null);
	const [user, setUser] = (0, import_react.useState)(null);
	const [perms, setPerms] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [error, setError] = (0, import_react.useState)(null);
	const [permissionsReady, setPermissionsReady] = (0, import_react.useState)(false);
	const clearProfile = (0, import_react.useCallback)(() => {
		setUser(null);
		setPerms(/* @__PURE__ */ new Set());
		setPermissionsReady(false);
	}, []);
	const loadProfile = (0, import_react.useCallback)(async (authUserId) => {
		if (!authUserId) {
			clearProfile();
			return;
		}
		setPermissionsReady(false);
		setError(null);
		const { data, error: profileError } = await supabase.from("users").select("id, full_name, email, phone, role_id, active, roles(code, name)").eq("auth_user_id", authUserId).maybeSingle();
		if (profileError) {
			setError(dbError(profileError));
			clearProfile();
			return;
		}
		if (!data) {
			setUser(null);
			setPerms(/* @__PURE__ */ new Set());
			setPermissionsReady(true);
			return;
		}
		const userData = data;
		const roleRel = Array.isArray(userData.roles) ? userData.roles[0] : userData.roles;
		const appUser = {
			id: userData.id,
			full_name: userData.full_name ?? null,
			email: userData.email ?? null,
			phone: userData.phone ?? null,
			role_id: userData.role_id ?? null,
			role_code: roleRel?.code ?? null,
			role_name: roleRel?.name ?? null,
			active: userData.active ?? false
		};
		if (!appUser.active) {
			setUser(appUser);
			setPerms(/* @__PURE__ */ new Set());
			setPermissionsReady(true);
			setError("Your Roshan account is inactive.");
			return;
		}
		setUser(appUser);
		if (appUser.role_code === "super_admin") {
			setPerms(/* @__PURE__ */ new Set(["*"]));
			setPermissionsReady(true);
			return;
		}
		if (!appUser.role_id) {
			setPerms(/* @__PURE__ */ new Set());
			setPermissionsReady(true);
			setError("No application role is assigned to this account.");
			return;
		}
		const { data: rolePermissions, error: permissionsError } = await supabase.from("role_permissions").select("permissions(code)").eq("role_id", appUser.role_id);
		if (permissionsError) {
			setPerms(/* @__PURE__ */ new Set());
			setPermissionsReady(false);
			setError(dbError(permissionsError));
			return;
		}
		const codes = (rolePermissions ?? []).map((row) => row.permissions?.code).filter((code) => Boolean(code));
		setPerms(new Set(codes));
		setPermissionsReady(true);
	}, [clearProfile]);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		const initialize = async () => {
			const { data, error: sessionError } = await supabase.auth.getSession();
			if (!mounted) return;
			if (sessionError) {
				setError(sessionError.message);
				setSession(null);
				clearProfile();
				setLoading(false);
				return;
			}
			setSession(data.session);
			if (data.session?.user?.id) await loadProfile(data.session.user.id);
			else clearProfile();
			if (mounted) setLoading(false);
		};
		initialize();
		const { data: { subscription } } = supabase.auth.onAuthStateChange((event, nextSession) => {
			if (!mounted) return;
			setSession(nextSession);
			if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") setTimeout(() => {
				if (!mounted) return;
				loadProfile(nextSession?.user?.id);
			}, 0);
			if (event === "SIGNED_OUT") clearProfile();
		});
		return () => {
			mounted = false;
			subscription.unsubscribe();
		};
	}, [clearProfile, loadProfile]);
	const signIn = (0, import_react.useCallback)(async (email, password) => {
		const normalizedEmail = email.trim().toLowerCase();
		const { error: signInError } = await supabase.auth.signInWithPassword({
			email: normalizedEmail,
			password
		});
		if (signInError) throw new Error(signInError.message);
	}, []);
	const signOut = (0, import_react.useCallback)(async () => {
		const { error: signOutError } = await supabase.auth.signOut();
		clearProfile();
		if (signOutError) throw new Error(signOutError.message);
	}, [clearProfile]);
	const refresh = (0, import_react.useCallback)(async () => {
		const { data, error: sessionError } = await supabase.auth.getSession();
		if (sessionError) {
			setError(sessionError.message);
			return;
		}
		setSession(data.session);
		await loadProfile(data.session?.user?.id);
	}, [loadProfile]);
	const isSuperAdmin = user?.role_code === "super_admin";
	const can = (0, import_react.useCallback)((code) => {
		if (!user || !user.active) return false;
		if (!permissionsReady) return false;
		if (isSuperAdmin) return true;
		if (!code) return true;
		return perms.has(code);
	}, [
		user,
		permissionsReady,
		isSuperAdmin,
		perms
	]);
	const canModule = (0, import_react.useCallback)((module) => can(`${module}.read`), [can]);
	const value = (0, import_react.useMemo)(() => ({
		loading,
		session,
		user,
		perms,
		error,
		permissionsReady,
		can,
		canModule,
		isSuperAdmin,
		signIn,
		signOut,
		refresh
	}), [
		loading,
		session,
		user,
		perms,
		error,
		permissionsReady,
		can,
		canModule,
		isSuperAdmin,
		signIn,
		signOut,
		refresh
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value,
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(Ctx);
	if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
	return ctx;
}
var dict = {
	app_name: {
		ar: "مركز روشان الطبي",
		en: "Roshan Medical Center"
	},
	app_short: {
		ar: "روشان",
		en: "Roshan"
	},
	sign_in: {
		ar: "تسجيل الدخول",
		en: "Sign in"
	},
	sign_out: {
		ar: "تسجيل الخروج",
		en: "Sign out"
	},
	email: {
		ar: "البريد الإلكتروني",
		en: "Email"
	},
	password: {
		ar: "كلمة المرور",
		en: "Password"
	},
	forgot_password: {
		ar: "نسيت كلمة المرور؟",
		en: "Forgot password?"
	},
	reset_password: {
		ar: "إعادة تعيين كلمة المرور",
		en: "Reset password"
	},
	send_reset_link: {
		ar: "إرسال رابط الاستعادة",
		en: "Send reset link"
	},
	new_password: {
		ar: "كلمة المرور الجديدة",
		en: "New password"
	},
	update_password: {
		ar: "تحديث كلمة المرور",
		en: "Update password"
	},
	first_run_setup: {
		ar: "التهيئة الأولى للنظام",
		en: "First-time setup"
	},
	create_super_admin: {
		ar: "إنشاء حساب المدير العام",
		en: "Create Super Admin"
	},
	setup_done: {
		ar: "تمت التهيئة",
		en: "Setup complete"
	},
	signup_disabled: {
		ar: "التسجيل العام مغلق. المدير العام فقط يمكنه إنشاء المستخدمين.",
		en: "Public signup is closed. Only the Super Admin creates users."
	},
	dashboard: {
		ar: "الرئيسية",
		en: "Dashboard"
	},
	navigation: {
		ar: "التنقل",
		en: "Navigation"
	},
	main_navigation: {
		ar: "القائمة الرئيسية",
		en: "Main navigation"
	},
	breadcrumb: {
		ar: "مسار الصفحة",
		en: "Breadcrumb"
	},
	search_failed: {
		ar: "تعذّر إكمال البحث في بعض الأقسام. حاول مرة أخرى.",
		en: "Search could not be completed for some sections. Try again."
	},
	searching: {
		ar: "جارٍ البحث…",
		en: "Searching…"
	},
	skip_to_content: {
		ar: "الانتقال إلى المحتوى",
		en: "Skip to content"
	},
	patients: {
		ar: "المرضى",
		en: "Patients"
	},
	visits: {
		ar: "الزيارات",
		en: "Visits"
	},
	queue: {
		ar: "الطابور",
		en: "Queue"
	},
	appointments: {
		ar: "المواعيد",
		en: "Appointments"
	},
	clinic: {
		ar: "العيادة",
		en: "Clinic"
	},
	laboratory: {
		ar: "المختبر",
		en: "Laboratory"
	},
	lab_catalog: {
		ar: "إعداد التحاليل",
		en: "Test catalogue"
	},
	pharmacy: {
		ar: "الصيدلية",
		en: "Pharmacy"
	},
	inventory: {
		ar: "المخزون",
		en: "Inventory"
	},
	billing: {
		ar: "الفواتير",
		en: "Billing"
	},
	accounting: {
		ar: "المحاسبة",
		en: "Accounting"
	},
	finance_hub: {
		ar: "المركز المالي",
		en: "Finance Hub"
	},
	finance_hub_subtitle: {
		ar: "الخزنة، التحصيل، المستحقات وديون الموردين",
		en: "Cashbox, collections, receivables and supplier debts"
	},
	finance_overview: {
		ar: "نظرة عامة",
		en: "Overview"
	},
	cashbox: {
		ar: "الخزنة",
		en: "Cashbox"
	},
	receivables: {
		ar: "مستحقات العملاء",
		en: "Receivables"
	},
	suppliers_finance: {
		ar: "الموردون",
		en: "Suppliers"
	},
	supplier_payment: {
		ar: "دفعة مورد",
		en: "Supplier payment"
	},
	add_supplier: {
		ar: "إضافة مورد",
		en: "Add supplier"
	},
	new_supplier_bill: {
		ar: "فاتورة مورد جديدة",
		en: "New supplier bill"
	},
	cashbox_balance: {
		ar: "رصيد الخزنة",
		en: "Cashbox balance"
	},
	supplier_debt: {
		ar: "ديون الموردين",
		en: "Supplier debt"
	},
	cashbox_entry: {
		ar: "حركة خزنة",
		en: "Cashbox entry"
	},
	bank: {
		ar: "بنكي",
		en: "Bank"
	},
	reverse: {
		ar: "عكس القيد",
		en: "Reverse"
	},
	reversed: {
		ar: "معكوس",
		en: "Reversed"
	},
	reversal: {
		ar: "قيد عكسي",
		en: "Reversal"
	},
	reversal_reason: {
		ar: "سبب العكس",
		en: "Reversal reason"
	},
	reversal_reason_required: {
		ar: "سبب العكس مطلوب",
		en: "A reversal reason is required"
	},
	record_payment: {
		ar: "تسجيل دفعة",
		en: "Record payment"
	},
	total_billed: {
		ar: "إجمالي الفواتير",
		en: "Total billed"
	},
	total_paid: {
		ar: "إجمالي المدفوع",
		en: "Total paid"
	},
	paid_amount: {
		ar: "المبلغ المدفوع",
		en: "Paid amount"
	},
	description: {
		ar: "الوصف",
		en: "Description"
	},
	reference: {
		ar: "المرجع",
		en: "Reference"
	},
	income: {
		ar: "إيراد",
		en: "Income"
	},
	expense: {
		ar: "مصروف",
		en: "Expense"
	},
	manual: {
		ar: "يدوي",
		en: "Manual"
	},
	insurance: {
		ar: "التأمين",
		en: "Insurance"
	},
	insurance_subtitle: {
		ar: "شركات التأمين، الخطط، عضوية المرضى والمطالبات",
		en: "Companies, plans, patient membership, and claims"
	},
	insurance_companies: {
		ar: "شركات التأمين",
		en: "Insurance companies"
	},
	insurance_plans: {
		ar: "خطط التأمين",
		en: "Insurance plans"
	},
	patient_insurance: {
		ar: "تأمين المريض",
		en: "Patient insurance"
	},
	insurance_claims: {
		ar: "مطالبات التأمين",
		en: "Insurance claims"
	},
	deactivate: {
		ar: "إلغاء التفعيل",
		en: "Deactivate"
	},
	activate: {
		ar: "تفعيل",
		en: "Activate"
	},
	default_coverage_percent: {
		ar: "نسبة التغطية الافتراضية",
		en: "Default coverage %"
	},
	policy_number: {
		ar: "رقم الوثيقة",
		en: "Policy number"
	},
	member_number: {
		ar: "رقم العضوية",
		en: "Member number"
	},
	new_claim: {
		ar: "مطالبة جديدة",
		en: "New claim"
	},
	claim_number: {
		ar: "رقم المطالبة",
		en: "Claim number"
	},
	submitted: {
		ar: "تم الإرسال",
		en: "Submitted"
	},
	under_review: {
		ar: "قيد المراجعة",
		en: "Under review"
	},
	approved: {
		ar: "معتمدة",
		en: "Approved"
	},
	partially_approved: {
		ar: "معتمدة جزئياً",
		en: "Partially approved"
	},
	rejected: {
		ar: "مرفوضة",
		en: "Rejected"
	},
	pending_claims: {
		ar: "مطالبات قيد الانتظار",
		en: "Pending claims"
	},
	outstanding_insurance: {
		ar: "مستحقات التأمين",
		en: "Outstanding insurance"
	},
	approved_amount: {
		ar: "المبلغ المعتمد",
		en: "Approved amount"
	},
	covered_amount: {
		ar: "المبلغ المغطى",
		en: "Covered amount"
	},
	patient_amount: {
		ar: "مبلغ المريض",
		en: "Patient amount"
	},
	confirm_status_change: {
		ar: "تأكيد تغيير الحالة؟",
		en: "Confirm this status change?"
	},
	analytics: {
		ar: "التحليلات",
		en: "Analytics"
	},
	analytics_subtitle: {
		ar: "اتجاهات الإيرادات، الصيدلية والأداء السريري",
		en: "Revenue, pharmacy, and clinical performance trends"
	},
	month: {
		ar: "الشهر",
		en: "Month"
	},
	revenue_12mo: {
		ar: "الإيرادات (12 شهراً)",
		en: "Revenue (12mo)"
	},
	expenses_12mo: {
		ar: "المصروفات (12 شهراً)",
		en: "Expenses (12mo)"
	},
	revenue_trends: {
		ar: "اتجاهات الإيرادات",
		en: "Revenue trends"
	},
	expense_trends: {
		ar: "اتجاهات المصروفات",
		en: "Expense trends"
	},
	insurance_revenue: {
		ar: "إيرادات التأمين",
		en: "Insurance revenue"
	},
	outstanding_receivables: {
		ar: "المستحقات المتبقية",
		en: "Outstanding receivables"
	},
	supplier_debt_analysis: {
		ar: "تحليل ديون الموردين",
		en: "Supplier debt analysis"
	},
	fefo_waste_units: {
		ar: "وحدات الهدر (FEFO)",
		en: "FEFO waste units"
	},
	expiry_forecast_value: {
		ar: "قيمة المخزون المعرض للانتهاء",
		en: "Expiry forecast value"
	},
	pharmacy_performance: {
		ar: "أداء الصيدلية",
		en: "Pharmacy performance"
	},
	fefo_waste_tracking: {
		ar: "تتبع الهدر (FEFO)",
		en: "FEFO waste tracking"
	},
	expiry_forecasting: {
		ar: "توقع انتهاء الصلاحية",
		en: "Expiry forecasting"
	},
	value_at_risk: {
		ar: "القيمة المعرضة للخطر",
		en: "Value at risk"
	},
	visits_12mo: {
		ar: "الزيارات (12 شهراً)",
		en: "Visits (12mo)"
	},
	appointments_12mo: {
		ar: "المواعيد (12 شهراً)",
		en: "Appointments (12mo)"
	},
	lab_revenue_12mo: {
		ar: "إيرادات المختبر (12 شهراً)",
		en: "Lab revenue (12mo)"
	},
	visit_trends: {
		ar: "اتجاهات الزيارات",
		en: "Visit trends"
	},
	doctor_productivity: {
		ar: "إنتاجية الأطباء",
		en: "Doctor productivity"
	},
	department_statistics: {
		ar: "إحصائيات الأقسام",
		en: "Department statistics"
	},
	appointment_analytics: {
		ar: "تحليلات المواعيد",
		en: "Appointment analytics"
	},
	laboratory_analytics: {
		ar: "تحليلات المختبر",
		en: "Laboratory analytics"
	},
	unassigned: {
		ar: "غير محدد",
		en: "Unassigned"
	},
	executive_summary: {
		ar: "الملخص التنفيذي",
		en: "Executive summary"
	},
	clinical_summary: {
		ar: "الملخص السريري",
		en: "Clinical summary"
	},
	pending_tasks: {
		ar: "مهام قيد الانتظار",
		en: "Pending tasks"
	},
	pharmacy_summary: {
		ar: "ملخص الصيدلية",
		en: "Pharmacy summary"
	},
	insurance_summary: {
		ar: "ملخص التأمين",
		en: "Insurance summary"
	},
	revenue_summary: {
		ar: "ملخص الإيرادات",
		en: "Revenue summary"
	},
	recent_activity: {
		ar: "النشاط الأخير",
		en: "Recent activity"
	},
	cash_in: {
		ar: "داخل الخزنة",
		en: "Cash in"
	},
	cash_out: {
		ar: "خارج الخزنة",
		en: "Cash out"
	},
	deposit: {
		ar: "إيداع",
		en: "Deposit"
	},
	withdrawal: {
		ar: "سحب",
		en: "Withdrawal"
	},
	invalid_amount: {
		ar: "أدخل مبلغاً صحيحاً أكبر من صفر",
		en: "Enter a valid amount greater than zero"
	},
	payment_exceeds_balance: {
		ar: "المبلغ يتجاوز الرصيد المستحق",
		en: "Payment exceeds the outstanding balance"
	},
	refresh: {
		ar: "تحديث",
		en: "Refresh"
	},
	type: {
		ar: "النوع",
		en: "Type"
	},
	expenses: {
		ar: "المصروفات",
		en: "Expenses"
	},
	partners: {
		ar: "الجهات المتعاقدة",
		en: "Partners"
	},
	reports: {
		ar: "التقارير",
		en: "Reports"
	},
	users: {
		ar: "المستخدمون",
		en: "Users"
	},
	settings: {
		ar: "الإعدادات",
		en: "Settings"
	},
	audit_log: {
		ar: "سجل التغييرات",
		en: "Audit log"
	},
	system_status: {
		ar: "حالة النظام",
		en: "System status"
	},
	followups: {
		ar: "المتابعات",
		en: "Follow-ups"
	},
	certificates: {
		ar: "الشهادات",
		en: "Certificates"
	},
	clinical: {
		ar: "السريري",
		en: "Clinical"
	},
	finance: {
		ar: "المالية",
		en: "Finance"
	},
	administration: {
		ar: "الإدارة",
		en: "Administration"
	},
	search_placeholder: {
		ar: "بحث عن مريض، زيارة، تحليل أو دواء…",
		en: "Search patients, visits, labs, medicines…"
	},
	search_everywhere: {
		ar: "بحث شامل",
		en: "Search everywhere"
	},
	no_results: {
		ar: "لا توجد نتائج",
		en: "No results found"
	},
	type_to_search: {
		ar: "ابدأ الكتابة للبحث…",
		en: "Start typing to search…"
	},
	recent_searches: {
		ar: "عمليات البحث الأخيرة",
		en: "Recent searches"
	},
	search_history: {
		ar: "سجل البحث",
		en: "Search history"
	},
	recent_pages: {
		ar: "الصفحات الأخيرة",
		en: "Recent pages"
	},
	clear: {
		ar: "مسح",
		en: "Clear"
	},
	favorites: {
		ar: "المفضلة",
		en: "Favorites"
	},
	pin: {
		ar: "تثبيت",
		en: "Pin"
	},
	unpin: {
		ar: "إلغاء التثبيت",
		en: "Unpin"
	},
	pages: {
		ar: "الصفحات",
		en: "Pages"
	},
	quick_actions: {
		ar: "إجراءات سريعة",
		en: "Quick actions"
	},
	new_patient: {
		ar: "مريض جديد",
		en: "New patient"
	},
	new_visit: {
		ar: "زيارة جديدة",
		en: "New visit"
	},
	new_lab_order: {
		ar: "طلب تحليل جديد",
		en: "New lab order"
	},
	new_lab_order_hint: {
		ar: "يجب إنشاء طلب التحليل من داخل زيارة نشطة. تم فتح قائمة الزيارات.",
		en: "Lab orders are created from inside an active visit. Opening the visits list."
	},
	collapse_sidebar: {
		ar: "طي القائمة",
		en: "Collapse sidebar"
	},
	expand_sidebar: {
		ar: "توسيع القائمة",
		en: "Expand sidebar"
	},
	home: {
		ar: "الرئيسية",
		en: "Home"
	},
	patient_result: {
		ar: "مريض",
		en: "Patient"
	},
	visit_result: {
		ar: "زيارة",
		en: "Visit"
	},
	lab_result: {
		ar: "تحليل",
		en: "Lab test"
	},
	medicine_result: {
		ar: "دواء",
		en: "Medicine"
	},
	more: {
		ar: "المزيد",
		en: "More"
	},
	details: {
		ar: "التفاصيل",
		en: "Details"
	},
	retry: {
		ar: "إعادة المحاولة",
		en: "Retry"
	},
	view_all: {
		ar: "عرض الكل",
		en: "View all"
	},
	account: {
		ar: "الحساب",
		en: "Account"
	},
	save: {
		ar: "حفظ",
		en: "Save"
	},
	saving: {
		ar: "جارٍ الحفظ…",
		en: "Saving…"
	},
	cancel: {
		ar: "إلغاء",
		en: "Cancel"
	},
	add: {
		ar: "إضافة",
		en: "Add"
	},
	open: {
		ar: "فتح",
		en: "Open"
	},
	edit: {
		ar: "تعديل",
		en: "Edit"
	},
	delete: {
		ar: "حذف",
		en: "Delete"
	},
	search: {
		ar: "بحث",
		en: "Search"
	},
	loading: {
		ar: "جارٍ التحميل…",
		en: "Loading…"
	},
	no_data: {
		ar: "لا توجد بيانات",
		en: "No records"
	},
	print: {
		ar: "طباعة",
		en: "Print"
	},
	export_excel: {
		ar: "تصدير Excel",
		en: "Export Excel"
	},
	export_pdf: {
		ar: "تصدير PDF",
		en: "Export PDF"
	},
	today: {
		ar: "اليوم",
		en: "Today"
	},
	total: {
		ar: "الإجمالي",
		en: "Total"
	},
	status: {
		ar: "الحالة",
		en: "Status"
	},
	actions: {
		ar: "إجراءات",
		en: "Actions"
	},
	notes: {
		ar: "ملاحظات",
		en: "Notes"
	},
	date: {
		ar: "التاريخ",
		en: "Date"
	},
	amount: {
		ar: "المبلغ",
		en: "Amount"
	},
	quantity: {
		ar: "الكمية",
		en: "Quantity"
	},
	price: {
		ar: "السعر",
		en: "Price"
	},
	name: {
		ar: "الاسم",
		en: "Name"
	},
	code: {
		ar: "الرمز",
		en: "Code"
	},
	category: {
		ar: "التصنيف",
		en: "Category"
	},
	none: {
		ar: "بدون",
		en: "None"
	},
	required: {
		ar: "مطلوب",
		en: "Required"
	},
	saved: {
		ar: "تم الحفظ",
		en: "Saved"
	},
	back: {
		ar: "رجوع",
		en: "Back"
	},
	previous: {
		ar: "السابق",
		en: "Previous"
	},
	next: {
		ar: "التالي",
		en: "Next"
	},
	page: {
		ar: "صفحة",
		en: "Page"
	},
	of: {
		ar: "من",
		en: "of"
	},
	mrn: {
		ar: "الرقم الطبي",
		en: "MRN"
	},
	full_name: {
		ar: "الاسم الكامل",
		en: "Full name"
	},
	gender: {
		ar: "الجنس",
		en: "Gender"
	},
	male: {
		ar: "ذكر",
		en: "Male"
	},
	female: {
		ar: "أنثى",
		en: "Female"
	},
	dob: {
		ar: "تاريخ الميلاد",
		en: "Date of birth"
	},
	age: {
		ar: "العمر",
		en: "Age"
	},
	phone: {
		ar: "الهاتف",
		en: "Phone"
	},
	address: {
		ar: "العنوان",
		en: "Address"
	},
	occupation: {
		ar: "المهنة",
		en: "Occupation"
	},
	marital_status: {
		ar: "الحالة الاجتماعية",
		en: "Marital status"
	},
	blood_group: {
		ar: "فصيلة الدم",
		en: "Blood group"
	},
	national_id: {
		ar: "الرقم الوطني",
		en: "National ID"
	},
	register_patient: {
		ar: "تسجيل مريض",
		en: "Register patient"
	},
	patient: {
		ar: "المريض",
		en: "Patient"
	},
	search_patient_placeholder: {
		ar: "ابحث بالاسم أو الرقم الطبي أو الهاتف أو الرقم الوطني",
		en: "Search by name, MRN, phone or national ID"
	},
	add_new_patient: {
		ar: "إضافة مريض جديد",
		en: "Add new patient"
	},
	duplicate_patient_hint: {
		ar: "تأكد من عدم تسجيل هذا المريض من قبل قبل إنشاء سجل جديد.",
		en: "Double-check this patient isn't already registered before creating a new record."
	},
	recent_patients: {
		ar: "مرضى حديثون",
		en: "Recent patients"
	},
	previous_visits: {
		ar: "الزيارات السابقة",
		en: "Previous visits"
	},
	last_visit: {
		ar: "آخر زيارة",
		en: "Last visit"
	},
	outstanding_balance: {
		ar: "الرصيد المستحق",
		en: "Outstanding balance"
	},
	visit_type: {
		ar: "نوع الزيارة",
		en: "Visit type"
	},
	walk_in: {
		ar: "بدون موعد",
		en: "Walk-in"
	},
	scheduled: {
		ar: "بموعد",
		en: "Scheduled"
	},
	department: {
		ar: "القسم",
		en: "Department"
	},
	doctor: {
		ar: "الطبيب",
		en: "Doctor"
	},
	consultation_fee: {
		ar: "قيمة الاستشارة",
		en: "Consultation fee"
	},
	waiting: {
		ar: "في الانتظار",
		en: "Waiting"
	},
	in_progress: {
		ar: "قيد المعالجة",
		en: "In progress"
	},
	ordered: {
		ar: "تم الطلب",
		en: "Ordered"
	},
	sample_collected: {
		ar: "تم أخذ العينة",
		en: "Sample collected"
	},
	priority: {
		ar: "الأولوية",
		en: "Priority"
	},
	completed: {
		ar: "مكتملة",
		en: "Completed"
	},
	cancelled: {
		ar: "ملغاة",
		en: "Cancelled"
	},
	confirmed: {
		ar: "مؤكد",
		en: "Confirmed"
	},
	arrived: {
		ar: "حضر",
		en: "Arrived"
	},
	no_show: {
		ar: "لم يحضر",
		en: "No show"
	},
	queue_number: {
		ar: "رقم الطابور",
		en: "Queue no."
	},
	call_next: {
		ar: "نداء التالي",
		en: "Call next"
	},
	vitals: {
		ar: "العلامات الحيوية",
		en: "Vitals"
	},
	clinical_notes: {
		ar: "الملاحظات السريرية",
		en: "Clinical notes"
	},
	diagnoses: {
		ar: "التشخيصات",
		en: "Diagnoses"
	},
	prescription: {
		ar: "الوصفة الطبية",
		en: "Prescription"
	},
	lab_orders: {
		ar: "طلبات المختبر",
		en: "Lab orders"
	},
	procedures: {
		ar: "الإجراءات",
		en: "Procedures"
	},
	bp: {
		ar: "ضغط الدم",
		en: "Blood pressure"
	},
	pulse: {
		ar: "النبض",
		en: "Pulse"
	},
	rr: {
		ar: "التنفس",
		en: "Resp. rate"
	},
	temperature: {
		ar: "الحرارة",
		en: "Temperature"
	},
	spo2: {
		ar: "تشبع الأكسجين",
		en: "SpO2"
	},
	weight: {
		ar: "الوزن",
		en: "Weight"
	},
	height: {
		ar: "الطول",
		en: "Height"
	},
	bmi: {
		ar: "كتلة الجسم",
		en: "BMI"
	},
	lmp: {
		ar: "آخر دورة (LMP)",
		en: "LMP"
	},
	edd: {
		ar: "الموعد المتوقع للولادة",
		en: "EDD"
	},
	gestational_age: {
		ar: "عمر الحمل",
		en: "Gestational age"
	},
	chief_complaint: {
		ar: "الشكوى الرئيسية",
		en: "Chief complaint"
	},
	hpi: {
		ar: "تفاصيل الشكوى",
		en: "History of presenting illness"
	},
	pmh: {
		ar: "التاريخ المرضي",
		en: "Past medical history"
	},
	psh: {
		ar: "التاريخ الجراحي",
		en: "Past surgical history"
	},
	drug_history: {
		ar: "تاريخ الأدوية",
		en: "Drug history"
	},
	allergy_history: {
		ar: "الحساسية",
		en: "Allergy history"
	},
	family_history: {
		ar: "التاريخ العائلي",
		en: "Family history"
	},
	social_history: {
		ar: "التاريخ الاجتماعي",
		en: "Social history"
	},
	examination: {
		ar: "الفحص",
		en: "Examination"
	},
	assessment: {
		ar: "التقييم",
		en: "Assessment"
	},
	plan: {
		ar: "الخطة",
		en: "Plan"
	},
	icd10: {
		ar: "رمز ICD-10",
		en: "ICD-10 code"
	},
	primary: {
		ar: "أساسي",
		en: "Primary"
	},
	secondary: {
		ar: "ثانوي",
		en: "Secondary"
	},
	medicine: {
		ar: "الدواء",
		en: "Medicine"
	},
	dosage: {
		ar: "الجرعة",
		en: "Dosage"
	},
	frequency: {
		ar: "التكرار",
		en: "Frequency"
	},
	duration: {
		ar: "المدة",
		en: "Duration"
	},
	instructions: {
		ar: "تعليمات",
		en: "Instructions"
	},
	external_pharmacy: {
		ar: "صيدلية خارجية",
		en: "External pharmacy"
	},
	internal_pharmacy: {
		ar: "صيدلية روشان",
		en: "Roshan pharmacy"
	},
	complete_visit: {
		ar: "إنهاء الزيارة",
		en: "Complete visit"
	},
	visit_locked: {
		ar: "الزيارة مكتملة — للقراءة فقط",
		en: "Visit completed — read only"
	},
	sample: {
		ar: "العينة",
		en: "Sample"
	},
	collect_sample: {
		ar: "سحب العينة",
		en: "Collect sample"
	},
	enter_results: {
		ar: "إدخال النتائج",
		en: "Enter results"
	},
	verify: {
		ar: "اعتماد",
		en: "Verify"
	},
	verified: {
		ar: "معتمد",
		en: "Verified"
	},
	result: {
		ar: "النتيجة",
		en: "Result"
	},
	reference_range: {
		ar: "المعدل الطبيعي",
		en: "Reference range"
	},
	parameters: {
		ar: "المؤشرات",
		en: "Parameters"
	},
	unit: {
		ar: "الوحدة",
		en: "Unit"
	},
	test: {
		ar: "التحليل",
		en: "Test"
	},
	sample_type: {
		ar: "نوع العينة",
		en: "Sample type"
	},
	optional_note: {
		ar: "كل المؤشرات اختيارية — يمكن ترك أي حقل فارغاً",
		en: "All parameters are optional — any field may be left blank"
	},
	medicines: {
		ar: "الأدوية",
		en: "Medicines"
	},
	generic_name: {
		ar: "الاسم العلمي",
		en: "Generic name"
	},
	brand_name: {
		ar: "الاسم التجاري",
		en: "Brand name"
	},
	strength: {
		ar: "التركيز",
		en: "Strength"
	},
	dosage_form: {
		ar: "الشكل الدوائي",
		en: "Dosage form"
	},
	batch_number: {
		ar: "رقم التشغيلة",
		en: "Batch no."
	},
	expiry_date: {
		ar: "تاريخ الانتهاء",
		en: "Expiry date"
	},
	purchase_price: {
		ar: "سعر الشراء",
		en: "Purchase price"
	},
	cost_price: {
		ar: "سعر التكلفة",
		en: "Cost price"
	},
	selling_price: {
		ar: "سعر البيع",
		en: "Selling price"
	},
	in_stock: {
		ar: "المتوفر",
		en: "In stock"
	},
	stock: {
		ar: "المخزون",
		en: "Stock"
	},
	low_stock: {
		ar: "مخزون منخفض",
		en: "Low stock"
	},
	expiring: {
		ar: "قارب الانتهاء",
		en: "Expiring"
	},
	dispense: {
		ar: "صرف",
		en: "Dispense"
	},
	dispensed: {
		ar: "تم الصرف",
		en: "Dispensed"
	},
	reorder_level: {
		ar: "حد إعادة الطلب",
		en: "Reorder level"
	},
	receive_stock: {
		ar: "استلام مخزون",
		en: "Receive stock"
	},
	batches: {
		ar: "التشغيلات",
		en: "Batches"
	},
	suppliers: {
		ar: "الموردون",
		en: "Suppliers"
	},
	purchase_history: {
		ar: "سجل المشتريات",
		en: "Purchase history"
	},
	quantity_received: {
		ar: "الكمية المستلمة",
		en: "Quantity received"
	},
	remaining_quantity: {
		ar: "الكمية المتبقية",
		en: "Remaining quantity"
	},
	manufacture_date: {
		ar: "تاريخ التصنيع",
		en: "Manufacture date"
	},
	invoice_reference: {
		ar: "رقم فاتورة المورد",
		en: "Invoice reference"
	},
	select_medicine: {
		ar: "اختر الدواء",
		en: "Select medicine"
	},
	invalid_quantity: {
		ar: "كمية غير صحيحة",
		en: "Invalid quantity"
	},
	legacy_receive_hint: {
		ar: "لتتبع كامل للتشغيلة وتاريخ الانتهاء، استخدم تبويب \"التشغيلات\" بدلاً من ذلك.",
		en: "For full batch and expiry tracking, use the Batches tab instead."
	},
	all: {
		ar: "الكل",
		en: "All"
	},
	healthy: {
		ar: "سليم",
		en: "Healthy"
	},
	expiring_soon: {
		ar: "قارب على الانتهاء",
		en: "Expiring soon"
	},
	expired: {
		ar: "منتهي الصلاحية",
		en: "Expired"
	},
	expiring_medicines: {
		ar: "أدوية قاربت على الانتهاء",
		en: "Expiring medicines"
	},
	expired_medicines: {
		ar: "أدوية منتهية الصلاحية",
		en: "Expired medicines"
	},
	low_stock_medicines: {
		ar: "أدوية منخفضة المخزون",
		en: "Low stock medicines"
	},
	low_stock_batches: {
		ar: "تشغيلات منخفضة المخزون",
		en: "Low stock batches"
	},
	movement_history: {
		ar: "سجل الحركة",
		en: "Movement history"
	},
	batches_used: {
		ar: "التشغيلات المستخدمة",
		en: "Batches used"
	},
	quantity_dispensed: {
		ar: "الكمية المصروفة",
		en: "Quantity dispensed"
	},
	legacy_stock: {
		ar: "مخزون سابق (بدون تشغيلة)",
		en: "Legacy stock (no batch)"
	},
	name_required: {
		ar: "الاسم مطلوب",
		en: "Name is required"
	},
	purchase: {
		ar: "شراء",
		en: "Purchase"
	},
	adjustment: {
		ar: "تسوية",
		en: "Adjustment"
	},
	return: {
		ar: "إرجاع",
		en: "Return"
	},
	writeoff: {
		ar: "إتلاف",
		en: "Write-off"
	},
	expiry_report: {
		ar: "تقرير انتهاء الصلاحية",
		en: "Expiry report"
	},
	low_stock_report: {
		ar: "تقرير المخزون المنخفض",
		en: "Low stock report"
	},
	batch_inventory_report: {
		ar: "تقرير مخزون التشغيلات",
		en: "Batch inventory report"
	},
	pharmacy_expiry_threshold: {
		ar: "حد التنبيه لانتهاء الصلاحية (أيام)",
		en: "Expiry alert threshold (days)"
	},
	invoice: {
		ar: "فاتورة",
		en: "Invoice"
	},
	invoices: {
		ar: "الفواتير",
		en: "Invoices"
	},
	invoice_number: {
		ar: "رقم الفاتورة",
		en: "Invoice no."
	},
	new_invoice: {
		ar: "فاتورة جديدة",
		en: "New invoice"
	},
	add_item: {
		ar: "إضافة بند",
		en: "Add item"
	},
	discount: {
		ar: "الخصم",
		en: "Discount"
	},
	subtotal: {
		ar: "المجموع",
		en: "Subtotal"
	},
	net: {
		ar: "الصافي",
		en: "Net"
	},
	paid: {
		ar: "المدفوع",
		en: "Paid"
	},
	balance: {
		ar: "المتبقي",
		en: "Balance"
	},
	payment: {
		ar: "الدفع",
		en: "Payment"
	},
	take_payment: {
		ar: "تسجيل دفعة",
		en: "Record payment"
	},
	payment_method: {
		ar: "طريقة الدفع",
		en: "Payment method"
	},
	cash: {
		ar: "نقداً",
		en: "Cash"
	},
	bankak: {
		ar: "بنكك",
		en: "Bankak"
	},
	unpaid: {
		ar: "غير مدفوعة",
		en: "Unpaid"
	},
	partial: {
		ar: "مدفوعة جزئياً",
		en: "Partial"
	},
	consultation: {
		ar: "استشارة",
		en: "Consultation"
	},
	revenue: {
		ar: "الإيرادات",
		en: "Revenue"
	},
	profit: {
		ar: "الأرباح",
		en: "Profit"
	},
	net_profit: {
		ar: "صافي الربح",
		en: "Net profit"
	},
	patients_today: {
		ar: "مرضى اليوم",
		en: "Patients today"
	},
	visits_today: {
		ar: "زيارات اليوم",
		en: "Visits today"
	},
	appointments_today: {
		ar: "مواعيد اليوم",
		en: "Appointments today"
	},
	revenue_today: {
		ar: "إيرادات اليوم",
		en: "Revenue today"
	},
	expenses_today: {
		ar: "مصروفات اليوم",
		en: "Expenses today"
	},
	pending_lab: {
		ar: "طلبات مختبر معلقة",
		en: "Pending lab orders"
	},
	pending_pharmacy: {
		ar: "وصفات معلقة",
		en: "Pending prescriptions"
	},
	waiting_patients: {
		ar: "مرضى في الانتظار",
		en: "Waiting patients"
	},
	upcoming_appointments: {
		ar: "مواعيد قادمة",
		en: "Upcoming appointments"
	},
	daily_revenue: {
		ar: "الإيراد اليومي",
		en: "Daily revenue"
	},
	monthly_revenue: {
		ar: "الإيراد الشهري",
		en: "Monthly revenue"
	},
	visits_by_department: {
		ar: "الزيارات حسب القسم",
		en: "Visits by department"
	},
	lab_activity: {
		ar: "نشاط المختبر",
		en: "Laboratory activity"
	},
	pharmacy_activity: {
		ar: "نشاط الصيدلية",
		en: "Pharmacy activity"
	},
	upcoming_followups: {
		ar: "متابعات قادمة",
		en: "Upcoming follow-ups"
	},
	system_configuration: {
		ar: "إعدادات النظام",
		en: "System configuration"
	},
	center_info: {
		ar: "معلومات المركز",
		en: "Center information"
	},
	center_name: {
		ar: "اسم المركز",
		en: "Center name"
	},
	center_name_ar: {
		ar: "اسم المركز بالعربية",
		en: "Center name (Arabic)"
	},
	currency: {
		ar: "العملة",
		en: "Currency"
	},
	tax_percent: {
		ar: "نسبة الضريبة %",
		en: "Tax %"
	},
	invoice_footer: {
		ar: "تذييل الفاتورة",
		en: "Invoice footer"
	},
	receipt_footer: {
		ar: "تذييل الإيصال",
		en: "Receipt footer"
	},
	language: {
		ar: "اللغة",
		en: "Language"
	},
	role: {
		ar: "الدور",
		en: "Role"
	},
	active: {
		ar: "نشط",
		en: "Active"
	},
	inactive: {
		ar: "غير نشط",
		en: "Inactive"
	},
	no_permission: {
		ar: "لا تمتلك صلاحية الوصول لهذه الصفحة",
		en: "You do not have permission to view this page"
	},
	migration_needed: {
		ar: "النظام يحتاج تنفيذ ملف الترقية db/roshan_phase1_migration.sql على قاعدة البيانات",
		en: "The database migration db/roshan_phase1_migration.sql has not been applied yet"
	},
	certificate_type: {
		ar: "نوع الشهادة",
		en: "Certificate type"
	},
	medical_certificate: {
		ar: "شهادة طبية",
		en: "Medical certificate"
	},
	sick_leave: {
		ar: "إجازة مرضية",
		en: "Sick leave"
	},
	fitness: {
		ar: "شهادة لياقة",
		en: "Fitness certificate"
	},
	content: {
		ar: "النص",
		en: "Content"
	},
	valid_from: {
		ar: "من",
		en: "Valid from"
	},
	valid_to: {
		ar: "إلى",
		en: "Valid to"
	},
	attachments: {
		ar: "المرفقات",
		en: "Attachments"
	},
	file_url: {
		ar: "رابط الملف",
		en: "File URL"
	},
	reason: {
		ar: "السبب",
		en: "Reason"
	},
	due_date: {
		ar: "تاريخ المتابعة",
		en: "Follow-up date"
	},
	pending: {
		ar: "معلق",
		en: "Pending"
	},
	missed: {
		ar: "فائت",
		en: "Missed"
	},
	done: {
		ar: "منجز",
		en: "Done"
	},
	supplier: {
		ar: "المورد",
		en: "Supplier"
	},
	contact_person: {
		ar: "الشخص المسؤول",
		en: "Contact person"
	},
	discount_percent: {
		ar: "نسبة الخصم %",
		en: "Discount %"
	},
	agreement_notes: {
		ar: "ملاحظات الاتفاقية",
		en: "Agreement notes"
	},
	from_date: {
		ar: "من تاريخ",
		en: "From"
	},
	to_date: {
		ar: "إلى تاريخ",
		en: "To"
	},
	db_status: {
		ar: "حالة قاعدة البيانات",
		en: "Database status"
	},
	connected: {
		ar: "متصل",
		en: "Connected"
	},
	records: {
		ar: "سجلات",
		en: "records"
	}
};
var LangCtx = (0, import_react.createContext)(null);
function LanguageProvider({ children }) {
	const [lang, setLang] = (0, import_react.useState)("ar");
	(0, import_react.useEffect)(() => {
		const stored = window.localStorage.getItem("roshan-lang");
		if (stored === "en" || stored === "ar") setLang(stored);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
	}, [lang]);
	const toggle = (0, import_react.useCallback)(() => {
		setLang((prev) => {
			const next = prev === "ar" ? "en" : "ar";
			window.localStorage.setItem("roshan-lang", next);
			return next;
		});
	}, []);
	const t = (0, import_react.useCallback)((k) => dict[k]?.[lang] ?? k, [lang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangCtx.Provider, {
		value: {
			lang,
			dir: lang === "ar" ? "rtl" : "ltr",
			t,
			toggle
		},
		children
	});
}
function useLang() {
	const ctx = (0, import_react.useContext)(LangCtx);
	if (!ctx) throw new Error("useLang must be used inside LanguageProvider");
	return ctx;
}
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var styles_default = "/assets/styles-DU4qZ0Sp.css";
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function getErrorMessage(error) {
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	return "An unexpected error occurred.";
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: getErrorMessage(error)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$31 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ROSHAN Medical Center" },
			{
				name: "description",
				content: "ROSHAN Medical Center management system — reception, clinics, laboratory, pharmacy and billing in one place."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@500;700;800&display=swap"
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$31.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			position: "top-center",
			richColors: true
		})] }) })
	});
}
var $$splitComponentImporter$30 = () => import("./routes-B6QYudhc.mjs");
var Route$30 = createFileRoute("/")({
	ssr: false,
	head: () => ({ meta: [
		{ title: "ROSHAN Medical Center — Clinic Management System" },
		{
			name: "description",
			content: "ROSHAN Medical Center management system: reception, clinics, EMR, laboratory, pharmacy, billing and accounting."
		},
		{
			property: "og:title",
			content: "ROSHAN Medical Center — Clinic Management System"
		},
		{
			property: "og:description",
			content: "ROSHAN Medical Center management system: reception, clinics, EMR, laboratory, pharmacy, billing and accounting."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$30, "component")
});
var $$splitComponentImporter$29 = () => import("./route-xWrYSo67.mjs");
var Route$29 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { authUser: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./auth-DuL5bNN-.mjs");
var Route$28 = createFileRoute("/auth")({
	ssr: false,
	head: () => ({ meta: [
		{ title: "Sign in — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Staff sign-in for the ROSHAN Medical Center management system."
		},
		{
			property: "og:title",
			content: "Sign in — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Staff sign-in for the ROSHAN Medical Center management system."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./setup--YC5q8Jw.mjs");
var Route$27 = createFileRoute("/setup")({
	ssr: false,
	head: () => ({ meta: [
		{ title: "First-time setup — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Create the first Super Admin account for the ROSHAN Medical Center system."
		},
		{
			property: "og:title",
			content: "First-time setup — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Create the first Super Admin account for the ROSHAN Medical Center system."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./accounting-DLEvbn4Z.mjs");
var Route$26 = createFileRoute("/_authenticated/accounting")({
	head: () => ({ meta: [{ title: "Finance — ROSHAN Medical Center" }] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./analytics-CuVEM3B5.mjs");
var Route$25 = createFileRoute("/_authenticated/analytics")({
	head: () => ({ meta: [
		{ title: "Analytics — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Revenue, pharmacy, and clinical performance trends."
		},
		{
			property: "og:title",
			content: "Analytics — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Revenue, pharmacy, and clinical performance trends."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
/** "2026-03" -> "Mar 2026" (or an Arabic-numeral-safe equivalent via Intl when lang=ar handled by caller). */
/** Groups rows by month and sums one numeric field, returning the last N months in order (oldest first). */
var $$splitComponentImporter$24 = () => import("./appointments-Cna5RFnc.mjs");
var Route$24 = createFileRoute("/_authenticated/appointments")({
	head: () => ({ meta: [
		{ title: "Appointments — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Manage patient appointments and scheduling."
		},
		{
			property: "og:title",
			content: "Appointments — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Manage patient appointments and scheduling."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./audit-B-BJIWgu.mjs");
var Route$23 = createFileRoute("/_authenticated/audit")({
	head: () => ({ meta: [
		{ title: "Audit Log — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Traceable record of system actions by user, table and time."
		},
		{
			property: "og:title",
			content: "Audit Log — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Traceable record of system actions by user, table and time."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
/** Keeps free-text search safe to embed in a PostgREST `.or()` filter string. */
var $$splitComponentImporter$22 = () => import("./billing-Cx8aBaDC.mjs");
var Route$22 = createFileRoute("/_authenticated/billing")({
	head: () => ({ meta: [
		{ title: "Billing — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Create invoices, record payments and track outstanding balances."
		},
		{
			property: "og:title",
			content: "Billing — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Create invoices, record payments and track outstanding balances."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./certificates-BMWC7QhM.mjs");
var Route$21 = createFileRoute("/_authenticated/certificates")({
	head: () => ({ meta: [{ title: "Medical Certificates — ROSHAN Medical Center" }] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./clinic-jF4Y-3Py.mjs");
var Route$20 = createFileRoute("/_authenticated/clinic")({
	head: () => ({ meta: [
		{ title: "Clinic — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Doctor consultation and patient management."
		},
		{
			property: "og:title",
			content: "Clinic — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Doctor consultation and patient management."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./dashboard-D8Er4YlJ.mjs");
var Route$19 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "Dashboard — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Live clinic overview: patients, visits, laboratory, pharmacy and revenue."
		},
		{
			property: "og:title",
			content: "Dashboard — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Live clinic overview: patients, visits, laboratory, pharmacy and revenue."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
/** "View all" link in a panel header; hidden when the user may not open the destination. */
var $$splitComponentImporter$18 = () => import("./expenses-C_UWI_p3.mjs");
var Route$18 = createFileRoute("/_authenticated/expenses")({
	head: () => ({ meta: [
		{ title: "Expenses — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Record and review operating expenses by category and date."
		},
		{
			property: "og:title",
			content: "Expenses — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Record and review operating expenses by category and date."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./finance-Dv76E3Xb.mjs");
var Route$17 = createFileRoute("/_authenticated/finance")({
	head: () => ({ meta: [
		{ title: "Finance — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Cashbox, patient receivables, and supplier bills/payments."
		},
		{
			property: "og:title",
			content: "Finance — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Cashbox, patient receivables, and supplier bills/payments."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./followups-DLITzv51.mjs");
var Route$16 = createFileRoute("/_authenticated/followups")({
	head: () => ({ meta: [
		{ title: "Follow-ups — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Track scheduled patient follow-up visits and contact status."
		},
		{
			property: "og:title",
			content: "Follow-ups — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Track scheduled patient follow-up visits and contact status."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./insurance-C4pQCS-G.mjs");
var Route$15 = createFileRoute("/_authenticated/insurance")({
	head: () => ({ meta: [
		{ title: "Insurance — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Insurance companies, plans, patient membership, and claims."
		},
		{
			property: "og:title",
			content: "Insurance — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Insurance companies, plans, patient membership, and claims."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./inventory-od3UNVEy.mjs");
var Route$14 = createFileRoute("/_authenticated/inventory")({
	head: () => ({ meta: [
		{ title: "Inventory — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Medicine stock levels, batch tracking, expiry and suppliers."
		},
		{
			property: "og:title",
			content: "Inventory — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Medicine stock levels, batch tracking, expiry and suppliers."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./lab-CFEoxa4F.mjs");
var Route$13 = createFileRoute("/_authenticated/lab")({
	head: () => ({ meta: [{ title: "Laboratory — ROSHAN Medical Center" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./lab-catalog-DEDWWkHA.mjs");
var Route$12 = createFileRoute("/_authenticated/lab-catalog")({
	head: () => ({ meta: [
		{ title: "Test catalogue — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Manage laboratory tests, prices, units and reference ranges."
		},
		{
			property: "og:title",
			content: "Test catalogue — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Manage laboratory tests, prices, units and reference ranges."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./partners-BMHKXidR.mjs");
var Route$11 = createFileRoute("/_authenticated/partners")({
	head: () => ({ meta: [
		{ title: "Partners — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Contracted companies and insurers with agreed discounts."
		},
		{
			property: "og:title",
			content: "Partners — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Contracted companies and insurers with agreed discounts."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./patients-BDiVd7wI.mjs");
var Route$10 = createFileRoute("/_authenticated/patients")({
	head: () => ({ meta: [
		{ title: "Patients — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Search, register and open patient charts."
		},
		{
			property: "og:title",
			content: "Patients — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Search, register and open patient charts."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./pharmacy-CrtbA3IP.mjs");
var Route$9 = createFileRoute("/_authenticated/pharmacy")({
	head: () => ({ meta: [
		{ title: "Pharmacy — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Dispense prescriptions using FEFO batch stock and bill medicines."
		},
		{
			property: "og:title",
			content: "Pharmacy — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Dispense prescriptions using FEFO batch stock and bill medicines."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./queue-DuAcRaaL.mjs");
var Route$8 = createFileRoute("/_authenticated/queue")({
	head: () => ({ meta: [{ title: "Queue — ROSHAN Medical Center" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./reports-CjQcGKg6.mjs");
var Route$7 = createFileRoute("/_authenticated/reports")({
	head: () => ({ meta: [
		{ title: "Reports — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Operational reports: visits, diagnoses, laboratory volume and revenue."
		},
		{
			property: "og:title",
			content: "Reports — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Operational reports: visits, diagnoses, laboratory volume and revenue."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./settings-CAc3T4pl.mjs");
var Route$6 = createFileRoute("/_authenticated/settings")({
	head: () => ({ meta: [
		{ title: "Settings — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Center identity, currency and invoice preferences."
		},
		{
			property: "og:title",
			content: "Settings — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Center identity, currency and invoice preferences."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./users-CpWtNkXK.mjs");
var Route$5 = createFileRoute("/_authenticated/users")({
	head: () => ({ meta: [
		{ title: "Users — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Staff accounts, roles and access management."
		},
		{
			property: "og:title",
			content: "Users — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Staff accounts, roles and access management."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./visits-BFfXkXfI.mjs");
var Route$4 = createFileRoute("/_authenticated/visits")({
	validateSearch: (search) => ({ patient: typeof search["patient"] === "string" ? search["patient"] : void 0 }),
	head: () => ({ meta: [
		{ title: "Visits — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Register walk-in and scheduled visits and route patients to clinics."
		},
		{
			property: "og:title",
			content: "Visits — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Register walk-in and scheduled visits and route patients to clinics."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./billing_._invoiceId-psFChCX1.mjs");
var Route$3 = createFileRoute("/_authenticated/billing_/$invoiceId")({
	head: () => ({ meta: [
		{ title: "Invoice — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Printable invoice with line items, payments and outstanding balance."
		},
		{
			property: "og:title",
			content: "Invoice — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Printable invoice with line items, payments and outstanding balance."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./clinic_._visitId-BkDGyvri.mjs");
var Route$2 = createFileRoute("/_authenticated/clinic_/$visitId")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./lab_._orderId-uNgA7C5Z.mjs");
var Route$1 = createFileRoute("/_authenticated/lab_/$orderId")({
	head: () => ({ meta: [{ title: "Lab order — ROSHAN Medical Center" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./patients_._patientId-DmWMegud.mjs");
var Route = createFileRoute("/_authenticated/patients_/$patientId")({
	head: () => ({ meta: [
		{ title: "Patient chart — ROSHAN Medical Center" },
		{
			name: "description",
			content: "Patient demographics, visit history, laboratory results and invoices."
		},
		{
			property: "og:title",
			content: "Patient chart — ROSHAN Medical Center"
		},
		{
			property: "og:description",
			content: "Patient demographics, visit history, laboratory results and invoices."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$30.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$31
});
var AuthenticatedRouteRoute = Route$29.update({
	id: "/_authenticated",
	getParentRoute: () => Route$31
});
var AuthRoute = Route$28.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$31
});
var SetupRoute = Route$27.update({
	id: "/setup",
	path: "/setup",
	getParentRoute: () => Route$31
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAccountingRoute: Route$26.update({
		id: "/accounting",
		path: "/accounting",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedAnalyticsRoute: Route$25.update({
		id: "/analytics",
		path: "/analytics",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedAppointmentsRoute: Route$24.update({
		id: "/appointments",
		path: "/appointments",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedAuditRoute: Route$23.update({
		id: "/audit",
		path: "/audit",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedBillingRoute: Route$22.update({
		id: "/billing",
		path: "/billing",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedCertificatesRoute: Route$21.update({
		id: "/certificates",
		path: "/certificates",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedClinicRoute: Route$20.update({
		id: "/clinic",
		path: "/clinic",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedDashboardRoute: Route$19.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedExpensesRoute: Route$18.update({
		id: "/expenses",
		path: "/expenses",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedFinanceRoute: Route$17.update({
		id: "/finance",
		path: "/finance",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedFollowupsRoute: Route$16.update({
		id: "/followups",
		path: "/followups",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedInsuranceRoute: Route$15.update({
		id: "/insurance",
		path: "/insurance",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedInventoryRoute: Route$14.update({
		id: "/inventory",
		path: "/inventory",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedLabRoute: Route$13.update({
		id: "/lab",
		path: "/lab",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedLabCatalogRoute: Route$12.update({
		id: "/lab-catalog",
		path: "/lab-catalog",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPartnersRoute: Route$11.update({
		id: "/partners",
		path: "/partners",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPatientsRoute: Route$10.update({
		id: "/patients",
		path: "/patients",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPharmacyRoute: Route$9.update({
		id: "/pharmacy",
		path: "/pharmacy",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedQueueRoute: Route$8.update({
		id: "/queue",
		path: "/queue",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedReportsRoute: Route$7.update({
		id: "/reports",
		path: "/reports",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedSettingsRoute: Route$6.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedUsersRoute: Route$5.update({
		id: "/users",
		path: "/users",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedVisitsRoute: Route$4.update({
		id: "/visits",
		path: "/visits",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedBillingInvoiceIdRoute: Route$3.update({
		id: "/billing_/$invoiceId",
		path: "/billing/$invoiceId",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedClinicVisitIdRoute: Route$2.update({
		id: "/clinic_/$visitId",
		path: "/clinic/$visitId",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedLabOrderIdRoute: Route$1.update({
		id: "/lab_/$orderId",
		path: "/lab/$orderId",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPatientsPatientIdRoute: Route.update({
		id: "/patients_/$patientId",
		path: "/patients/$patientId",
		getParentRoute: () => AuthenticatedRouteRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AuthRoute,
	SetupRoute
};
var routeTree = Route$31._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { useAuth as a, useLang as i, Route$2 as n, Route$4 as r, router_exports as t };
