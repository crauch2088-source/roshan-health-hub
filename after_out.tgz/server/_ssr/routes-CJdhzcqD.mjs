import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as rpc } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CJdhzcqD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Landing() {
	const navigate = useNavigate();
	const { loading, session, user } = useAuth();
	const { t } = useLang();
	(0, import_react.useEffect)(() => {
		if (loading) return;
		if (session && user) {
			navigate({
				to: "/dashboard",
				replace: true
			});
			return;
		}
		rpc("setup_required").then((need) => {
			navigate({
				to: need ? "/setup" : "/auth",
				replace: true
			});
		}).catch(() => {
			navigate({
				to: "/auth",
				replace: true
			});
		});
	}, [
		loading,
		session,
		user,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col items-center justify-center gap-4 bg-gradient-to-b from-accent/40 to-background px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/roshan-logo.png",
				alt: t("app_name"),
				className: "h-24 object-contain"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-foreground",
				children: t("app_name")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: t("loading")
			})
		]
	});
}
//#endregion
export { Landing as component };
