import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, l as useSave, o as s, r as n, t as b, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as Plus, D as Pencil } from "../_libs/lucide-react.mjs";
import { _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-BmCdZVQb.mjs";
import { n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-ChVCEi1n.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { s as money } from "./medical-CD1sc5il.mjs";
import { t as Switch } from "./switch-WdfqgukX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-catalog-DEDWWkHA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var blank = {
	name: "",
	name_ar: "",
	category: "",
	unit: "",
	price: "0",
	normal_min: "",
	normal_max: "",
	reference_range: ""
};
function LabCatalogPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "lab_admin.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabCatalogPageInner, {})
	});
}
function LabCatalogPageInner() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const { currency } = useSettings();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(blank);
	const [search, setSearch] = (0, import_react.useState)("");
	const tests = useRows(["lab-catalog"], () => supabase.from("lab_tests").select("*").is("deleted_at", null).order("name", { ascending: true }));
	const create = useSave(async () => {
		const { error } = await supabase.from("lab_tests").insert({
			name: form.name,
			name_ar: form.name_ar || null,
			category: form.category || null,
			unit: form.unit || null,
			price: Number(form.price) || 0,
			normal_min: form.normal_min === "" ? null : Number(form.normal_min),
			normal_max: form.normal_max === "" ? null : Number(form.normal_max),
			reference_range: form.reference_range || null,
			active: true
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["lab-catalog"], ["lab-tests"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm(blank);
		}
	});
	const toggle = useSave(async ({ id, active }) => {
		const { error } = await supabase.from("lab_tests").update({ active }).eq("id", id);
		if (error) throw new Error(error.message);
		return null;
	}, { invalidate: [["lab-catalog"], ["lab-tests"]] });
	const update = useSave(async ({ id }) => {
		const { error } = await supabase.from("lab_tests").update({
			name: form.name,
			name_ar: form.name_ar || null,
			category: form.category || null,
			unit: form.unit || null,
			price: Number(form.price) || 0,
			normal_min: form.normal_min === "" ? null : Number(form.normal_min),
			normal_max: form.normal_max === "" ? null : Number(form.normal_max),
			reference_range: form.reference_range || null
		}).eq("id", id);
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["lab-catalog"], ["lab-tests"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setEditingId(null);
			setForm(blank);
		}
	});
	const rows = (tests.data ?? []).filter((x) => `${s(x, "name")} ${s(x, "name_ar")} ${s(x, "code")} ${s(x, "category")}`.toLowerCase().includes(search.trim().toLowerCase()));
	if (tests.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("lab_catalog"),
			subtitle: t("tests_and_prices"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: t("search"),
					value: search,
					onChange: (e) => setSearch(e.target.value),
					className: "w-full sm:w-48"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: "roshan-lab-catalog"
				}),
				can("lab_admin.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: (value) => {
						setOpen(value);
						if (!value) {
							setEditingId(null);
							setForm(blank);
						}
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => {
								setEditingId(null);
								setForm(blank);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
								" ",
								t("add")
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-h-[90vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editingId ? t("edit") : t("lab_catalog") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: `${t("name")} (EN) *`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.name,
											onChange: (e) => setForm({
												...form,
												name: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: `${t("name")} (AR)`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.name_ar,
											onChange: (e) => setForm({
												...form,
												name_ar: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("category"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.category,
											onChange: (e) => setForm({
												...form,
												category: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("unit"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											dir: "ltr",
											value: form.unit,
											onChange: (e) => setForm({
												...form,
												unit: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("price"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.price,
											onChange: (e) => setForm({
												...form,
												price: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("reference_range"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											dir: "ltr",
											value: form.reference_range,
											onChange: (e) => setForm({
												...form,
												reference_range: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: `${t("normal_min")}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.normal_min,
											onChange: (e) => setForm({
												...form,
												normal_min: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: `${t("normal_max")}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.normal_max,
											onChange: (e) => setForm({
												...form,
												normal_max: e.target.value
											})
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setOpen(false),
								children: t("cancel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: !form.name || create.isPending || update.isPending,
								onClick: () => editingId ? update.mutate({ id: editingId }) : create.mutate(void 0),
								children: create.isPending || update.isPending ? t("saving") : t("save")
							})] })
						]
					})]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: tests.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("category") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("unit") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("reference_range") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("price") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "no-print",
						children: t("active")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: lang === "ar" ? s(x, "name_ar") || s(x, "name") : s(x, "name")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(x, "category") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(x, "unit") || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(x, "reference_range") || (s(x, "normal_min") && s(x, "normal_max") ? `${s(x, "normal_min")} - ${s(x, "normal_max")}` : "—")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(x, "price"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "no-print",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: b(x, "active"),
							disabled: !can("lab_admin.manage"),
							onCheckedChange: (v) => toggle.mutate({
								id: s(x, "id"),
								active: v
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "no-print text-end",
						children: can("lab_admin.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => {
								setEditingId(s(x, "id"));
								setForm({
									name: s(x, "name"),
									name_ar: s(x, "name_ar"),
									category: s(x, "category"),
									unit: s(x, "unit"),
									price: s(x, "price") || "0",
									normal_min: s(x, "normal_min"),
									normal_max: s(x, "normal_max"),
									reference_range: s(x, "reference_range")
								});
								setOpen(true);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }),
								" ",
								t("edit")
							]
						}) : null
					})
				] }, s(x, "id"))) })]
			})
		}) })
	] });
}
//#endregion
export { LabCatalogPage as component };
