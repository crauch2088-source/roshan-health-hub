import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s, r as n, s as usePagedRows, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as Plus, O as Package, s as Truck } from "../_libs/lucide-react.mjs";
import { A as cn, T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons, t as Badge, y as Pager } from "./kit-BmCdZVQb.mjs";
import { n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-ChVCEi1n.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { a as formatDate, s as money } from "./medical-CD1sc5il.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-D0CoeBa_.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-vwCASk5X.mjs";
import { r as expiryStatus, t as EXPIRY_TONE } from "./pharmacy-Co3jb7c8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory-od3UNVEy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 25;
/** Keeps free-text search safe to embed in a PostgREST `.ilike()` filter. */
function sanitizeSearch(term) {
	return term.replace(/[,()%]/g, "").trim();
}
function ExpiryBadge({ status }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "outline",
		className: cn("font-medium", EXPIRY_TONE[status]),
		children: t(status)
	});
}
function InventoryPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "pharmacy.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InventoryPageInner, {})
	});
}
function InventoryPageInner() {
	const { t } = useLang();
	const { currency, settings } = useSettings();
	const thresholdDays = Number(settings["pharmacy_expiry_threshold_days"]) || 90;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: t("inventory"),
		subtitle: t("stock_overview")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		defaultValue: "medicines",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
				className: "mb-4 flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "medicines",
						children: t("medicines")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "batches",
						children: t("batches")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "suppliers",
						children: t("suppliers")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "medicines",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MedicinesTab, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "batches",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatchesTab, {
					thresholdDays,
					currency
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "suppliers",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuppliersTab, { currency })
			})
		]
	})] });
}
function MedicinesTab() {
	const { t } = useLang();
	const { can, user } = useAuth();
	const { currency } = useSettings();
	const [page, setPage] = (0, import_react.useState)(1);
	const [search, setSearch] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		unit: "",
		cost_price: "0",
		selling_price: "0",
		stock_quantity: "0",
		reorder_level: "10",
		expiry_date: "",
		batch_number: ""
	});
	const [receive, setReceive] = (0, import_react.useState)(null);
	const list = usePagedRows(["inventory", search], ({ from, to }) => {
		let q = supabase.from("medicines").select("id, name, unit, stock_quantity, reorder_level, selling_price, cost_price, expiry_date", { count: "exact" }).is("deleted_at", null);
		const term = sanitizeSearch(search);
		if (term) q = q.ilike("name", `%${term}%`);
		return q.order("name", { ascending: true }).range(from, to);
	}, page, PAGE_SIZE);
	const statRows = useRows(["inventory-stats"], () => supabase.from("medicines").select("stock_quantity, reorder_level, cost_price").is("deleted_at", null)).data ?? [];
	const lowStock = statRows.filter((m) => n(m, "stock_quantity") <= n(m, "reorder_level")).length;
	const stockValue = statRows.reduce((sum, m) => sum + n(m, "stock_quantity") * n(m, "cost_price"), 0);
	const create = useSave(async () => {
		const { error } = await supabase.from("medicines").insert({
			name: form.name,
			unit: form.unit || null,
			cost_price: Number(form.cost_price) || 0,
			selling_price: Number(form.selling_price) || 0,
			stock_quantity: Number(form.stock_quantity) || 0,
			reorder_level: Number(form.reorder_level) || 0,
			expiry_date: form.expiry_date || null,
			batch_number: form.batch_number || null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [
			["inventory"],
			["inventory-stats"],
			["medicines"]
		],
		successMessage: t("saved"),
		onDone: () => setOpen(false)
	});
	const addStock = useSave(async () => {
		if (!receive) return null;
		const row = list.rows.find((m) => s(m, "id") === receive.id);
		const qty = Number(receive.qty) || 0;
		const { error } = await supabase.from("medicines").update({ stock_quantity: n(row, "stock_quantity") + qty }).eq("id", receive.id);
		if (error) throw new Error(error.message);
		const { error: mErr } = await supabase.from("stock_movements").insert({
			medicine_id: receive.id,
			movement_type: "purchase",
			quantity: qty,
			created_by: user?.id ?? null
		});
		if (mErr) throw new Error(mErr.message);
		return null;
	}, {
		invalidate: [["inventory"], ["inventory-stats"]],
		successMessage: t("saved"),
		onDone: () => setReceive(null)
	});
	const rows = list.rows;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex flex-wrap items-center justify-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: t("search"),
					value: search,
					onChange: (e) => {
						setSearch(e.target.value);
						setPage(1);
					},
					className: "w-full sm:w-48"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: "roshan-inventory"
				}),
				can("pharmacy.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
								" ",
								t("add")
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-h-[90vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("medicines") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: `${t("name")} *`,
										className: "sm:col-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.name,
											onChange: (e) => setForm({
												...form,
												name: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("unit"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.unit,
											onChange: (e) => setForm({
												...form,
												unit: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("batch_number"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											dir: "ltr",
											value: form.batch_number,
											onChange: (e) => setForm({
												...form,
												batch_number: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("cost_price"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.cost_price,
											onChange: (e) => setForm({
												...form,
												cost_price: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("selling_price"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.selling_price,
											onChange: (e) => setForm({
												...form,
												selling_price: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("stock"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.stock_quantity,
											onChange: (e) => setForm({
												...form,
												stock_quantity: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("reorder_level"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											dir: "ltr",
											value: form.reorder_level,
											onChange: (e) => setForm({
												...form,
												reorder_level: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("expiry_date"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "date",
											dir: "ltr",
											value: form.expiry_date,
											onChange: (e) => setForm({
												...form,
												expiry_date: e.target.value
											})
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setOpen(false),
								children: t("cancel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: !form.name || create.isPending,
								onClick: () => create.mutate(void 0),
								children: create.isPending ? t("saving") : t("save")
							})] })
						]
					})]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("medicines"),
					value: String(list.count ?? rows.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("low_stock"),
					value: String(lowStock)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("stock_value"),
					value: money(stockValue, currency)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "p-0",
			children: [list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("medicines"),
				children: rows.map((m) => {
					const low = n(m, "stock_quantity") <= n(m, "reorder_level");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("space-y-1.5 p-3", low && "bg-destructive/5"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: s(m, "name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: s(m, "unit") || "—"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									className: cn("shrink-0 font-semibold", low && "text-destructive"),
									children: n(m, "stock_quantity")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(m, "selling_price"), currency) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: s(m, "expiry_date") ? formatDate(s(m, "expiry_date")) : "—"
								})]
							}),
							can("pharmacy.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								className: "w-full",
								onClick: () => setReceive({
									id: s(m, "id"),
									qty: "0"
								}),
								children: t("receive_stock")
							}) : null
						]
					}, s(m, "id"));
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("unit") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("stock") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("selling_price") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((m) => {
						const low = n(m, "stock_quantity") <= n(m, "reorder_level");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: low ? "bg-destructive/5" : void 0,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: s(m, "name")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(m, "unit") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									className: low ? "font-semibold text-destructive" : void 0,
									children: n(m, "stock_quantity")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(m, "selling_price"), currency) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: s(m, "expiry_date") ? formatDate(s(m, "expiry_date")) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "no-print text-end",
									children: can("pharmacy.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										size: "sm",
										onClick: () => setReceive({
											id: s(m, "id"),
											qty: "0"
										}),
										children: t("receive_stock")
									}) : null
								})
							]
						}, s(m, "id"));
					}) })]
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				page: list.page,
				pageCount: list.pageCount,
				count: list.count,
				pageSize: PAGE_SIZE,
				hasPrev: list.hasPrev,
				hasNext: list.hasNext,
				isFetching: list.isFetching,
				onPrev: () => setPage((p) => Math.max(1, p - 1)),
				onNext: () => setPage((p) => p + 1)
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(receive),
			onOpenChange: (o) => o ? null : setReceive(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("receive_stock") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("quantity"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						dir: "ltr",
						value: receive?.qty ?? "",
						onChange: (e) => setReceive(receive ? {
							...receive,
							qty: e.target.value
						} : receive)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: t("legacy_receive_hint")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setReceive(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: addStock.isPending,
					onClick: () => addStock.mutate(void 0),
					children: addStock.isPending ? t("saving") : t("save")
				})] })
			] })
		})
	] });
}
var EMPTY_BATCH_FORM = {
	medicine_id: "",
	supplier_id: "",
	batch_number: "",
	quantity_received: "0",
	purchase_price: "0",
	selling_price: "0",
	manufacture_date: "",
	expiry_date: "",
	invoice_reference: ""
};
function BatchesTab({ thresholdDays, currency }) {
	const { t } = useLang();
	const { can, user } = useAuth();
	const [search, setSearch] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [receiveOpen, setReceiveOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(EMPTY_BATCH_FORM);
	const [detail, setDetail] = (0, import_react.useState)(null);
	const batches = useRows(["pharmacy-batches"], () => supabase.from("pharmacy_inventory").select("id, medicine_id, batch_number, supplier_id, purchase_price, selling_price, quantity_received, quantity_remaining, manufacture_date, expiry_date, invoice_reference, created_at, updated_at, medicines(id, name, unit), suppliers(id, name, phone)").is("deleted_at", null).order("expiry_date", {
		ascending: true,
		nullsFirst: false
	}).limit(500));
	const medicines = useRows(["medicines-picker"], () => supabase.from("medicines").select("id, name, unit").is("deleted_at", null).order("name", { ascending: true }));
	const suppliers = useRows(["suppliers-picker"], () => supabase.from("suppliers").select("id, name").is("deleted_at", null).eq("active", true).order("name", { ascending: true }));
	const movements = useRows(["batch-movements", s(detail, "id")], () => supabase.from("stock_movements").select("id, movement_type, quantity, created_at, reference_table").eq("batch_id", s(detail, "id")).order("created_at", { ascending: false }), { enabled: Boolean(detail) });
	const rows = (0, import_react.useMemo)(() => {
		const term = search.trim().toLowerCase();
		return (batches.data ?? []).filter((b) => {
			const status = expiryStatus(s(b, "expiry_date") || null, thresholdDays);
			if (statusFilter !== "all" && status !== statusFilter) return false;
			if (!term) return true;
			return `${s(b, "batch_number")} ${s(rel(b, "medicines"), "name")} ${s(rel(b, "suppliers"), "name")} ${s(b, "invoice_reference")}`.toLowerCase().includes(term);
		});
	}, [
		batches.data,
		search,
		statusFilter,
		thresholdDays
	]);
	const expiringCount = (batches.data ?? []).filter((b) => expiryStatus(s(b, "expiry_date") || null, thresholdDays) === "expiring_soon").length;
	const expiredCount = (batches.data ?? []).filter((b) => expiryStatus(s(b, "expiry_date") || null, thresholdDays) === "expired").length;
	const lowStockBatches = (batches.data ?? []).filter((b) => n(b, "quantity_remaining") > 0 && n(b, "quantity_remaining") <= 10).length;
	const receive = useSave(async () => {
		if (!form.medicine_id) throw new Error(t("select_medicine"));
		const qty = Number(form.quantity_received) || 0;
		if (qty <= 0) throw new Error(t("invalid_quantity"));
		const { data: batch, error } = await supabase.from("pharmacy_inventory").insert({
			medicine_id: form.medicine_id,
			supplier_id: form.supplier_id || null,
			batch_number: form.batch_number || null,
			quantity_received: qty,
			quantity_remaining: qty,
			purchase_price: Number(form.purchase_price) || 0,
			selling_price: Number(form.selling_price) || 0,
			manufacture_date: form.manufacture_date || null,
			expiry_date: form.expiry_date || null,
			invoice_reference: form.invoice_reference || null,
			branch_id: user?.["branch_id"] ?? null
		}).select("id").single();
		if (error) throw new Error(error.message);
		const { data: current, error: readErr } = await supabase.from("medicines").select("stock_quantity").eq("id", form.medicine_id).single();
		if (readErr) throw new Error(readErr.message);
		const { error: medErr } = await supabase.from("medicines").update({ stock_quantity: n(current, "stock_quantity") + qty }).eq("id", form.medicine_id);
		if (medErr) throw new Error(medErr.message);
		const { error: movErr } = await supabase.from("stock_movements").insert({
			medicine_id: form.medicine_id,
			batch_id: batch?.id ?? null,
			movement_type: "purchase",
			quantity: qty,
			reference_id: batch?.id ?? null,
			reference_table: "pharmacy_inventory",
			created_by: user?.id ?? null
		});
		if (movErr) throw new Error(movErr.message);
		return null;
	}, {
		invalidate: [
			["pharmacy-batches"],
			["inventory"],
			["inventory-stats"],
			["medicines"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setReceiveOpen(false);
			setForm(EMPTY_BATCH_FORM);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex flex-wrap items-center justify-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: t("search"),
					value: search,
					onChange: (e) => setSearch(e.target.value),
					className: "w-full sm:w-52"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: statusFilter,
					onValueChange: (v) => setStatusFilter(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-full sm:w-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: t("all")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "healthy",
							children: t("healthy")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "expiring_soon",
							children: t("expiring_soon")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "expired",
							children: t("expired")
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: "roshan-batches"
				}),
				can("pharmacy.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setReceiveOpen(true),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
						" ",
						t("receive_stock")
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: batches.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("expiring_medicines"),
					value: String(expiringCount),
					tone: "warning"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("expired_medicines"),
					value: String(expiredCount),
					tone: "destructive"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("low_stock_batches"),
					value: String(lowStockBatches),
					tone: "warning"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: batches.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("batches"),
				children: rows.map((b) => {
					const status = expiryStatus(s(b, "expiry_date") || null, thresholdDays);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "block w-full space-y-1 px-4 py-3 text-start hover:bg-accent/40",
						onClick: () => setDetail(b),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 break-words font-medium",
									children: s(rel(b, "medicines"), "name") || "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpiryBadge, { status })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "ltr",
										children: s(b, "batch_number") || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s(rel(b, "suppliers"), "name") || "—" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "ltr",
										children: s(b, "expiry_date") ? formatDate(s(b, "expiry_date")) : "—"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("purchase_price"),
									": ",
									money(n(b, "purchase_price"), currency)
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("selling_price"),
									": ",
									money(n(b, "selling_price"), currency)
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("text-sm", n(b, "quantity_remaining") <= 10 && "font-semibold text-destructive"),
								children: [
									t("remaining_quantity"),
									":",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "ltr",
										children: n(b, "quantity_remaining")
									})
								]
							})
						]
					}) }, s(b, "id"));
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("batch_number") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("supplier") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("purchase_price") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("selling_price") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("remaining_quantity") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((b) => {
						const status = expiryStatus(s(b, "expiry_date") || null, thresholdDays);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "cursor-pointer hover:bg-accent/40",
							onClick: () => setDetail(b),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: s(rel(b, "medicines"), "name") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: s(b, "batch_number") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(b, "suppliers"), "name") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: s(b, "expiry_date") ? formatDate(s(b, "expiry_date")) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(b, "purchase_price"), currency) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(b, "selling_price"), currency) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									className: n(b, "quantity_remaining") <= 10 ? "font-semibold text-destructive" : void 0,
									children: n(b, "quantity_remaining")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpiryBadge, { status }) })
							]
						}, s(b, "id"));
					}) })]
				})
			})] })
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: receiveOpen,
			onOpenChange: setReceiveOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-h-[90vh] overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("receive_stock") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("medicines")} *`,
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									...form.medicine_id ? { value: form.medicine_id } : {},
									onValueChange: (v) => setForm({
										...form,
										medicine_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("select_medicine") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (medicines.data ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s(m, "id"),
										children: s(m, "name")
									}, s(m, "id"))) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("supplier"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									...form.supplier_id ? { value: form.supplier_id } : {},
									onValueChange: (v) => setForm({
										...form,
										supplier_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (suppliers.data ?? []).map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s(sp, "id"),
										children: s(sp, "name")
									}, s(sp, "id"))) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("batch_number"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.batch_number,
									onChange: (e) => setForm({
										...form,
										batch_number: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("quantity_received")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									dir: "ltr",
									value: form.quantity_received,
									onChange: (e) => setForm({
										...form,
										quantity_received: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("purchase_price"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									dir: "ltr",
									value: form.purchase_price,
									onChange: (e) => setForm({
										...form,
										purchase_price: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("selling_price"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									dir: "ltr",
									value: form.selling_price,
									onChange: (e) => setForm({
										...form,
										selling_price: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("manufacture_date"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									dir: "ltr",
									value: form.manufacture_date,
									onChange: (e) => setForm({
										...form,
										manufacture_date: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("expiry_date"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									dir: "ltr",
									value: form.expiry_date,
									onChange: (e) => setForm({
										...form,
										expiry_date: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("invoice_reference"),
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.invoice_reference,
									onChange: (e) => setForm({
										...form,
										invoice_reference: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setReceiveOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.medicine_id || !form.quantity_received || receive.isPending,
						onClick: () => receive.mutate(void 0),
						children: receive.isPending ? t("saving") : t("save")
					})] })
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(detail),
			onOpenChange: (o) => o ? null : setDetail(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-h-[90vh] overflow-y-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
					s(rel(detail, "medicines"), "name"),
					" · ",
					s(detail, "batch_number") || "—"
				] }) }), detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("supplier")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: s(rel(detail, "suppliers"), "name") || "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("status")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpiryBadge, { status: expiryStatus(s(detail, "expiry_date") || null, thresholdDays) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("manufacture_date")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								children: s(detail, "manufacture_date") ? formatDate(s(detail, "manufacture_date")) : "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("expiry_date")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								children: s(detail, "expiry_date") ? formatDate(s(detail, "expiry_date")) : "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("quantity_received")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								children: n(detail, "quantity_received")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("remaining_quantity")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								children: n(detail, "quantity_remaining")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("purchase_price")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								children: money(n(detail, "purchase_price"), currency)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("selling_price")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								children: money(n(detail, "selling_price"), currency)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: t("invoice_reference")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									dir: "ltr",
									children: s(detail, "invoice_reference") || "—"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground",
						children: t("movement_history")
					}), movements.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : (movements.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("type") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (movements.data ?? []).map((mv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDate(s(mv, "created_at"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: t(s(mv, "movement_type")) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: n(mv, "quantity") < 0 ? "text-destructive" : "text-success",
								children: n(mv, "quantity") > 0 ? `+${n(mv, "quantity")}` : n(mv, "quantity")
							})
						] }, s(mv, "id"))) })]
					})] })]
				}) : null]
			})
		})
	] });
}
function SuppliersTab({ currency }) {
	const { t } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		address: ""
	});
	const [history, setHistory] = (0, import_react.useState)(null);
	const suppliers = useRows(["suppliers"], () => supabase.from("suppliers").select("id, name, phone, address, active").is("deleted_at", null).order("name", { ascending: true }));
	const supplierBatches = useRows(["supplier-batches", s(history, "id")], () => supabase.from("pharmacy_inventory").select("id, batch_number, expiry_date, quantity_received, purchase_price, invoice_reference, created_at, medicines(name)").eq("supplier_id", s(history, "id")).is("deleted_at", null).order("created_at", { ascending: false }), { enabled: Boolean(history) });
	const create = useSave(async () => {
		if (!form.name.trim()) throw new Error(t("name_required"));
		const { error } = await supabase.from("suppliers").insert({
			name: form.name.trim(),
			phone: form.phone || null,
			address: form.address || null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["suppliers"], ["suppliers-picker"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm({
				name: "",
				phone: "",
				address: ""
			});
		}
	});
	const rows = suppliers.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex flex-wrap items-center justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-suppliers"
			}), can("pharmacy.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t("add_supplier")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("add_supplier") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("name")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("phone"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.phone,
									onChange: (e) => setForm({
										...form,
										phone: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("address"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.address,
									onChange: (e) => setForm({
										...form,
										address: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.name || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				] })]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: suppliers.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: suppliers.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("suppliers"),
				children: rows.map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "space-y-1 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 font-medium",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-3.5 text-muted-foreground" }),
								" ",
								s(sp, "name")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-muted-foreground",
							dir: "ltr",
							children: s(sp, "phone") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "break-words text-sm text-muted-foreground",
							children: s(sp, "address") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "no-print w-full",
							onClick: () => setHistory(sp),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-3.5" }),
								" ",
								t("purchase_history")
							]
						})
					]
				}, s(sp, "id")))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("phone") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("address") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-3.5 text-muted-foreground" }),
									" ",
									s(sp, "name")
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(sp, "phone") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(sp, "address") || "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "no-print text-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setHistory(sp),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-3.5" }),
									" ",
									t("purchase_history")
								]
							})
						})
					] }, s(sp, "id"))) })]
				})
			})] })
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(history),
			onOpenChange: (o) => o ? null : setHistory(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-h-[90vh] max-w-2xl overflow-y-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
					t("purchase_history"),
					" — ",
					s(history, "name")
				] }) }), supplierBatches.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : (supplierBatches.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("batch_number") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity_received") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("purchase_price") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (supplierBatches.data ?? []).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: formatDate(s(b, "created_at"))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: s(rel(b, "medicines"), "name") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(b, "batch_number") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: n(b, "quantity_received")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(b, "purchase_price"), currency) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(b, "expiry_date") ? formatDate(s(b, "expiry_date")) : "—"
						})
					] }, s(b, "id"))) })]
				})]
			})
		})
	] });
}
//#endregion
export { InventoryPage as component };
