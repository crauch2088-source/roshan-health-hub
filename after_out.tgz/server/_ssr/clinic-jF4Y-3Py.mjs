import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, o as s } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as SearchField, E as StatusBadge, O as Toolbar, S as RecordRow, _ as PageHeader, a as Empty, b as PermissionGate, d as Input, g as NoResults, h as MetricStrip, m as Metric, n as Button, o as ErrorBox, r as DataPanel, s as ExportButtons, u as InitialAvatar, v as PageSkeleton } from "./kit-BmCdZVQb.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { a as formatDate, c as todayISO, i as calcAge } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-vwCASk5X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/clinic-jF4Y-3Py.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClinicPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "visits.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClinicPageInner, {})
	});
}
function ClinicPageInner() {
	const { lang } = useLang();
	const { user } = useAuth();
	const [search, setSearch] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [filterMyPatients, setFilterMyPatients] = (0, import_react.useState)(false);
	const nextDate = (() => {
		const d = /* @__PURE__ */ new Date(`${date}T00:00:00+02:00`);
		d.setDate(d.getDate() + 1);
		return d.toISOString();
	})();
	const visits = useRows([
		"clinic-visits",
		date,
		filterMyPatients,
		user?.id ?? ""
	], () => supabase.from("visits").select(`
            id,
            visit_number,
            status,
            created_at,
            visit_date,
            patient_id,
            doctor_id,
            patients(
              id,
              full_name,
              mrn,
              phone,
              date_of_birth,
              gender
            ),
            departments(
              name,
              name_ar
            ),
            users(
              full_name
            )
          `).gte("visit_date", (/* @__PURE__ */ new Date(`${date}T00:00:00+02:00`)).toISOString()).lt("visit_date", nextDate).is("deleted_at", null).order("visit_date", { ascending: true }));
	const rows = (visits.data ?? []).filter((visit) => {
		if (filterMyPatients && user?.id && s(visit, "doctor_id") !== user.id) return false;
		if (status !== "all" && s(visit, "status") !== status) return false;
		const term = search.trim().toLowerCase();
		if (!term) return true;
		const patient = rel(visit, "patients");
		const dept = rel(visit, "departments");
		return `${s(patient, "full_name")} ${s(patient, "mrn")} ${s(patient, "phone")} ${s(visit, "visit_number")} ${s(dept, "name")} ${s(dept, "name_ar")}`.toLowerCase().includes(term);
	});
	if (visits.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	const dayRows = visits.data ?? [];
	const countOf = (st) => dayRows.filter((v) => s(v, "status") === st).length;
	const filtered = search.trim() !== "" || status !== "all" || filterMyPatients;
	const clearFilters = () => {
		setSearch("");
		setStatus("all");
		setFilterMyPatients(false);
	};
	const deptName = (visit) => {
		const department = rel(visit, "departments");
		return lang === "ar" ? s(department, "name_ar") || s(department, "name") || "—" : s(department, "name") || "—";
	};
	const openLabel = lang === "ar" ? "فتح" : "Open";
	const openTitle = (visit) => lang === "ar" ? `فتح زيارة ${s(visit, "visit_number")}` : `Open visit ${s(visit, "visit_number")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
				title: lang === "ar" ? "العيادة" : "Clinic",
				subtitle: formatDate(date),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					"aria-label": lang === "ar" ? "التاريخ" : "Date",
					value: date,
					onChange: (e) => setDate(e.target.value),
					className: "h-11 w-full sm:w-40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: `roshan-clinic-${date}`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MetricStrip, {
				label: lang === "ar" ? "ملخص اليوم" : "Day summary",
				cols: "sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "الزيارات" : "Visits",
						value: dayRows.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "بانتظار" : "Waiting",
						value: countOf("waiting"),
						tone: countOf("waiting") > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "قيد المعالجة" : "In progress",
						value: countOf("in_progress"),
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "مكتملة" : "Completed",
						value: countOf("completed"),
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Toolbar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchField, {
					value: search,
					onChange: setSearch,
					placeholder: lang === "ar" ? "ابحث عن المريض" : "Search patient"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: status,
					onValueChange: setStatus,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-11 w-full sm:w-44",
						"aria-label": lang === "ar" ? "الحالة" : "Status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: lang === "ar" ? "كل الحالات" : "All statuses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "waiting",
							children: lang === "ar" ? "بانتظار" : "Waiting"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "in_progress",
							children: lang === "ar" ? "قيد المعالجة" : "In progress"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "completed",
							children: lang === "ar" ? "مكتملة" : "Completed"
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: filterMyPatients ? "default" : "outline",
					className: "h-11",
					type: "button",
					"aria-pressed": filterMyPatients,
					onClick: () => setFilterMyPatients((current) => !current),
					children: lang === "ar" ? "مرضاي فقط" : "My Patients"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, {
				error: visits.error,
				onRetry: () => void visits.refetch()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: rows.length === 0 && filtered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoResults, { onClear: clearFilters }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border md:hidden",
				children: rows.map((visit) => {
					const patient = rel(visit, "patients");
					const visitId = s(visit, "id");
					const ageVal = calcAge(s(patient, "date_of_birth"));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordRow, {
						main: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InitialAvatar, { name: s(patient, "full_name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-semibold",
										children: s(patient, "full_name") || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												dir: "ltr",
												children: s(patient, "mrn") || "—"
											}),
											" · ",
											deptName(visit),
											ageVal !== null ? ` · ${ageVal} yrs` : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(visit, "status") })
									})
								]
							})]
						}),
						trailing: visitId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/clinic/$visitId",
							params: { visitId },
							title: openTitle(visit),
							className: "inline-flex h-11 min-w-16 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
							children: openLabel
						}) : null
					}) }, visitId || `${s(patient, "id")}-${s(visit, "created_at")}`);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "المريض" : "Patient" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "العمر / الجنس" : "Age / Gender" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "القسم" : "Department" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الحالة" : "Status" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-end",
							children: lang === "ar" ? "الإجراء" : "Action"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((visit) => {
						const patient = rel(visit, "patients");
						const patientId = s(patient, "id");
						const visitId = s(visit, "id");
						const ageVal = calcAge(s(patient, "date_of_birth"));
						const ageStr = ageVal !== null ? `${ageVal} yrs` : "—";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "whitespace-nowrap font-medium",
								children: [s(patient, "full_name") || "—", s(patient, "mrn") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ms-2 text-xs text-muted-foreground",
									dir: "ltr",
									children: s(patient, "mrn")
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "whitespace-nowrap text-xs text-muted-foreground",
								children: [ageStr, s(patient, "gender") ? ` (${s(patient, "gender")})` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap",
								children: deptName(visit)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(visit, "status") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap text-end",
								children: visitId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/clinic/$visitId",
									params: { visitId },
									className: "inline-flex h-8 items-center justify-center gap-2 whitespace-nowrap rounded-md bg-primary px-3 text-xs font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
									title: openTitle(visit),
									children: openLabel
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									disabled: true,
									title: lang === "ar" ? "معرّف الزيارة غير موجود" : "Visit ID is missing",
									children: openLabel
								})
							})
						] }, visitId || `${patientId}-${s(visit, "created_at")}`);
					}) })]
				})
			})] }) })
		]
	});
}
//#endregion
export { ClinicPage as component };
