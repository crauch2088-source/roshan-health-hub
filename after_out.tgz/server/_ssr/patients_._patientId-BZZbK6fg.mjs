import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useParams, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { B as FlaskConical, C as Plus, G as ClipboardList, m as ShieldCheck, rt as CalendarDays, st as ArrowLeft, u as Stethoscope, x as Receipt } from "../_libs/lucide-react.mjs";
import { D as Textarea, E as StatusBadge, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, i as DetailHeader, n as Button, o as ErrorBox, r as DataPanel, w as SectionTitle } from "./kit-asLB5pSR.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, i as calcAge, o as formatDateTime, r as MARITAL, s as money, t as BLOOD_GROUPS } from "./medical-CD1sc5il.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-Cz_DZk-6.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DcyYd86X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/patients_._patientId-BZZbK6fg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ChartErrorBoundary = class extends import_react.Component {
	state = { error: null };
	static getDerivedStateFromError(error) {
		return { error };
	}
	render() {
		if (!this.state.error) return this.props.children;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: this.state.error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { label: "تعذر تحميل ملف المريض / Unable to load patient chart" })]
		});
	}
};
function PatientChartWithBoundary() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "patients.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartErrorBoundary, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientChart, {}) })
	});
}
function PatientChart() {
	const { patientId } = useParams({ from: "/_authenticated/patients_/$patientId" });
	const { t, lang } = useLang();
	const { can } = useAuth();
	const { currency } = useSettings();
	const [form, setForm] = (0, import_react.useState)({});
	const patient = useRows(["patient", patientId], () => supabase.from("patients").select("*").eq("id", patientId).limit(1));
	const record = (patient.data ?? [])[0];
	(0, import_react.useEffect)(() => {
		if (record) setForm(record);
	}, [record]);
	const visits = useRows(["patient-visits", patientId], () => supabase.from("visits").select("id, visit_date, status, consultation_fee, departments(name, name_ar), users(full_name)").eq("patient_id", patientId).is("deleted_at", null).order("visit_date", { ascending: false }));
	const labs = useRows(["patient-labs", patientId], () => supabase.from("lab_orders").select("id, status, created_at, lab_order_items(id, lab_tests(name, name_ar))").eq("patient_id", patientId).is("deleted_at", null).order("created_at", { ascending: false }));
	const invoices = useRows(["patient-invoices", patientId], () => supabase.from("invoices").select("id, invoice_number, invoice_date, status, net_amount, paid_amount").eq("patient_id", patientId).is("deleted_at", null).order("invoice_date", { ascending: false }));
	const appointments = useRows(["patient-appointments", patientId], () => supabase.from("appointments").select("id, appointment_date, appointment_time, status, notes, departments(name, name_ar), users(full_name)").eq("patient_id", patientId).is("deleted_at", null).order("appointment_date", { ascending: false }).limit(50));
	const followups = useRows(["patient-followups", patientId], () => supabase.from("followups").select("id, followup_date, reason, status").eq("patient_id", patientId).is("deleted_at", null).order("followup_date", { ascending: false }).limit(50));
	const claims = useRows(["patient-claims", patientId], () => supabase.from("insurance_claims").select("id, claim_number, status, submitted_amount, submitted_at, created_at, patient_insurance!inner(patient_id, insurance_companies(name))").eq("patient_insurance.patient_id", patientId).is("deleted_at", null).order("created_at", { ascending: false }).limit(50));
	const timeline = (0, import_react.useMemo)(() => {
		const items = [];
		for (const v of visits.data ?? []) {
			const dept = rel(v, "departments");
			items.push({
				id: `visit-${s(v, "id")}`,
				kind: "visit",
				date: s(v, "visit_date") || "",
				title: lang === "ar" ? "زيارة" : "Visit",
				subtitle: (lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name")) || s(rel(v, "users"), "full_name"),
				status: s(v, "status"),
				href: `/clinic/${s(v, "id")}`
			});
		}
		for (const a of appointments.data ?? []) {
			const dept = rel(a, "departments");
			items.push({
				id: `appt-${s(a, "id")}`,
				kind: "appointment",
				date: (s(a, "appointment_date") || "").slice(0, 10),
				title: lang === "ar" ? "موعد" : "Appointment",
				subtitle: (lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name")) || s(rel(a, "users"), "full_name"),
				status: s(a, "status")
			});
		}
		for (const f of followups.data ?? []) items.push({
			id: `fu-${s(f, "id")}`,
			kind: "followup",
			date: s(f, "followup_date") || "",
			title: lang === "ar" ? "متابعة" : "Follow-up",
			subtitle: s(f, "reason") || void 0,
			status: s(f, "status")
		});
		for (const o of labs.data ?? []) {
			const names = (o["lab_order_items"] ?? []).map((i) => {
				const test = rel(i, "lab_tests");
				return lang === "ar" ? s(test, "name_ar") || s(test, "name") : s(test, "name");
			}).filter(Boolean).join(", ");
			items.push({
				id: `lab-${s(o, "id")}`,
				kind: "lab",
				date: (s(o, "created_at") || "").slice(0, 10),
				title: lang === "ar" ? "تحاليل" : "Lab order",
				subtitle: names || void 0,
				status: s(o, "status"),
				href: `/lab/${s(o, "id")}`
			});
		}
		for (const inv of invoices.data ?? []) items.push({
			id: `inv-${s(inv, "id")}`,
			kind: "invoice",
			date: s(inv, "invoice_date") || "",
			title: s(inv, "invoice_number") || (lang === "ar" ? "فاتورة" : "Invoice"),
			subtitle: money(n(inv, "net_amount"), currency),
			status: s(inv, "status"),
			href: `/billing/${s(inv, "id")}`
		});
		for (const c of claims.data ?? []) {
			const pi = rel(c, "patient_insurance");
			const company = rel(pi, "insurance_companies");
			items.push({
				id: `claim-${s(c, "id")}`,
				kind: "claim",
				date: (s(c, "submitted_at") || s(c, "created_at") || "").slice(0, 10),
				title: s(c, "claim_number") || (lang === "ar" ? "مطالبة تأمين" : "Insurance claim"),
				subtitle: s(company, "name") || void 0,
				status: s(c, "status"),
				href: "/insurance"
			});
		}
		items.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
		return items;
	}, [
		visits.data,
		appointments.data,
		followups.data,
		labs.data,
		invoices.data,
		claims.data,
		lang,
		currency
	]);
	const prescriptions = useRows(["patient-rx", patientId], () => supabase.from("prescriptions").select("id, created_at, status, is_external, prescription_items(id, dosage, medicines(name))").eq("patient_id", patientId).is("deleted_at", null).order("created_at", { ascending: false }));
	const save = useSave(async () => {
		const payload = {
			full_name: s(form, "full_name"),
			gender: s(form, "gender"),
			date_of_birth: s(form, "date_of_birth") || null,
			phone: s(form, "phone"),
			address: s(form, "address"),
			occupation: s(form, "occupation"),
			marital_status: s(form, "marital_status") || null,
			blood_group: s(form, "blood_group") || null,
			national_id: s(form, "national_id"),
			emergency_contact: s(form, "emergency_contact"),
			notes: s(form, "notes")
		};
		const { error } = await supabase.from("patients").update(payload).eq("id", patientId);
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["patient", patientId], ["patients"]],
		successMessage: t("saved")
	});
	if (patient.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	if (patient.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: patient.error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { label: t("no_data") })] });
	if (!record) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { label: t("no_data") });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailHeader, {
			eyebrow: t("patients"),
			name: s(record, "full_name"),
			facts: [
				{
					label: t("mrn"),
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						dir: "ltr",
						children: s(record, "mrn") || "—"
					})
				},
				{
					label: t("age"),
					value: calcAge(s(record, "date_of_birth")) ?? "—"
				},
				{
					label: t("gender"),
					value: s(record, "gender") ? t(s(record, "gender")) : "—"
				},
				{
					label: t("phone"),
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						dir: "ltr",
						children: s(record, "phone") || "—"
					})
				},
				{
					label: t("blood_group"),
					value: s(record, "blood_group") || "—"
				}
			],
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/patients",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4 rtl:rotate-180" }),
						" ",
						t("back")
					]
				})
			}), can("visits.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/visits",
					search: { patient: s(record, "id") },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
						" ",
						t("new_visit")
					]
				})
			}) : null] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: patient.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "profile",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "mb-4 flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "timeline",
							children: lang === "ar" ? "الخط الزمني" : "Timeline"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "profile",
							children: t("patient")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "visits",
							children: t("visits")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "labs",
							children: t("laboratory")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "rx",
							children: t("prescription")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "invoices",
							children: t("invoices")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "timeline",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: timeline.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						title: lang === "ar" ? "لا أحداث بعد" : "No events yet",
						description: lang === "ar" ? "ستظهر هنا الزيارات والمواعيد والتحاليل والفواتير." : "Visits, appointments, labs and invoices will appear here."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y",
						children: timeline.map((item) => {
							const Icon = item.kind === "visit" ? ClipboardList : item.kind === "appointment" ? CalendarDays : item.kind === "followup" ? Stethoscope : item.kind === "lab" ? FlaskConical : item.kind === "claim" ? ShieldCheck : Receipt;
							const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3 px-4 py-3 transition-colors hover:bg-muted/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4",
											"aria-hidden": true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: item.title
											}), item.status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: item.status }) : null]
										}), item.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 truncate text-sm text-muted-foreground",
											children: item.subtitle
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
										className: "shrink-0 text-xs tabular-nums text-muted-foreground",
										dir: "ltr",
										children: item.date ? formatDate(item.date) : "—"
									})
								]
							});
							if (item.href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: item.href,
								className: "block",
								children: body
							}) }, item.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: body }, item.id);
						})
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "profile",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("patient") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("full_name"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: s(form, "full_name"),
											onChange: (e) => setForm({
												...form,
												full_name: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("gender"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: s(form, "gender") || "male",
											onValueChange: (v) => setForm({
												...form,
												gender: v
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "male",
												children: t("male")
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "female",
												children: t("female")
											})] })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("dob"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "date",
											dir: "ltr",
											value: s(form, "date_of_birth").slice(0, 10),
											onChange: (e) => setForm({
												...form,
												date_of_birth: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("phone"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											dir: "ltr",
											value: s(form, "phone"),
											onChange: (e) => setForm({
												...form,
												phone: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("blood_group"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: s(form, "blood_group"),
											onValueChange: (v) => setForm({
												...form,
												blood_group: v
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: BLOOD_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: g,
												children: g
											}, g)) })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("marital_status"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: s(form, "marital_status"),
											onValueChange: (v) => setForm({
												...form,
												marital_status: v
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: MARITAL.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: m,
												children: m
											}, m)) })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("occupation"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: s(form, "occupation"),
											onChange: (e) => setForm({
												...form,
												occupation: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("address"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: s(form, "address"),
											onChange: (e) => setForm({
												...form,
												address: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "ID / National no.",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											dir: "ltr",
											value: s(form, "national_id"),
											onChange: (e) => setForm({
												...form,
												national_id: e.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("notes"),
										className: "sm:col-span-2 lg:col-span-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 2,
											value: s(form, "notes"),
											onChange: (e) => setForm({
												...form,
												notes: e.target.value
											})
										})
									})
								]
							}),
							can("patients.update") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									disabled: save.isPending,
									onClick: () => save.mutate(void 0),
									children: save.isPending ? t("saving") : t("save")
								})
							}) : null
						]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "visits",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
						title: t("visits"),
						children: (visits.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("department") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("doctor") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (visits.data ?? []).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: formatDate(s(v, "visit_date"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: lang === "ar" ? s(rel(v, "departments"), "name_ar") || s(rel(v, "departments"), "name") : s(rel(v, "departments"), "name") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(v, "users"), "full_name") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(v, "status") }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "no-print text-end",
									children: can("emr.read") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "ghost",
										size: "sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/clinic/$visitId",
											params: { visitId: s(v, "id") },
											children: t("clinical_notes")
										})
									}) : null
								})
							] }, s(v, "id"))) })]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "labs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: (labs.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("test") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (labs.data ?? []).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDateTime(s(o, "created_at"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: (o["lab_order_items"] ?? []).map((i) => lang === "ar" ? s(rel(i, "lab_tests"), "name_ar") || s(rel(i, "lab_tests"), "name") : s(rel(i, "lab_tests"), "name")).join(", ") || "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(o, "status") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "no-print text-end",
								children: can("lab.read") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/lab/$orderId",
										params: { orderId: s(o, "id") },
										children: t("result")
									})
								}) : null
							})
						] }, s(o, "id"))) })]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "rx",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: (prescriptions.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (prescriptions.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDateTime(s(p, "created_at"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: (p["prescription_items"] ?? []).map((i) => s(rel(i, "medicines"), "name")).filter(Boolean).join(", ") || "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(p, "status") }) })
						] }, s(p, "id"))) })]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "invoices",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: (invoices.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("invoice_number") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("paid") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (invoices.data ?? []).map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: "font-mono text-xs",
								children: s(inv, "invoice_number")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDate(s(inv, "invoice_date"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(inv, "net_amount"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(inv, "paid_amount"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(inv, "status") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "no-print text-end",
								children: can("billing.read") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/billing/$invoiceId",
										params: { invoiceId: s(inv, "id") },
										children: t("invoice")
									})
								}) : null
							})
						] }, s(inv, "id"))) })]
					}) })
				})
			]
		})
	] });
}
//#endregion
export { PatientChartWithBoundary as component };
