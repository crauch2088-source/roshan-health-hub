import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { W as Clock3, tt as Check, w as Play } from "../_libs/lucide-react.mjs";
import { C as SearchField, E as StatusBadge, O as Toolbar, _ as PageHeader, a as Empty, b as PermissionGate, d as Input, g as NoResults, h as MetricStrip, k as buttonVariants, m as Metric, n as Button, o as ErrorBox, r as DataPanel, u as InitialAvatar, v as PageSkeleton } from "./kit-BmCdZVQb.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { c as todayISO } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-vwCASk5X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/queue-DuAcRaaL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"all",
	"waiting",
	"called",
	"in_progress",
	"completed",
	"cancelled"
];
function QueuePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "queue.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueuePageInner, {})
	});
}
function QueuePageInner() {
	const { lang, t } = useLang();
	const { can } = useAuth();
	const canUpdate = can("visits.update");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [status, setStatus] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const queue = useRows([
		"queue",
		date,
		status
	], () => {
		let q = supabase.from("queue_tickets").select("id,visit_id,queue_number,status,created_at,called_at,completed_at,visits(id,visit_number,patient_id,department_id,status,consultation_fee,patients(id,full_name,mrn),departments(id,name,name_ar),users!visits_doctor_id_fkey(full_name))").eq("visit_date", date).is("deleted_at", null).order("created_at", { ascending: true });
		if (status !== "all") q = q.eq("status", status);
		return q;
	}, { refetchInterval: 1e4 });
	const update = useSave(async ({ id, status }) => {
		if (!canUpdate) throw new Error("Not authorized");
		const patch = { status };
		if (status === "called") patch["called_at"] = (/* @__PURE__ */ new Date()).toISOString();
		if (status === "completed") patch["completed_at"] = (/* @__PURE__ */ new Date()).toISOString();
		const { error } = await supabase.from("queue_tickets").update(patch).eq("id", id);
		if (error) throw new Error(error.message);
		const ticket = (queue.data ?? []).find((r) => s(r, "id") === id);
		const visitId = s(ticket, "visit_id") || s(rel(ticket, "visits"), "id");
		if (visitId) {
			const visitStatus = status === "called" ? "in_progress" : status === "completed" ? "completed" : status === "cancelled" ? "cancelled" : "waiting";
			await supabase.from("visits").update({ status: visitStatus }).eq("id", visitId);
		}
		return null;
	}, {
		invalidate: [[
			"queue",
			date,
			status
		], ["visits", date]],
		successMessage: t("saved")
	});
	if (queue.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	const rows = (queue.data ?? []).filter((ticket) => {
		const patient = rel(rel(ticket, "visits"), "patients");
		const q = search.trim().toLowerCase();
		if (!q) return true;
		return [
			s(patient, "full_name"),
			s(patient, "mrn"),
			s(ticket, "queue_number")
		].some((x) => x.toLowerCase().includes(q));
	});
	const all = queue.data ?? [];
	const countOf = (...st) => all.filter((r) => st.includes(s(r, "status"))).length;
	const waiting = countOf("waiting");
	const active = countOf("called", "in_progress");
	const done = countOf("completed");
	const filtered = search.trim() !== "" || status !== "all";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: lang === "ar" ? "الطابور" : "Queue",
				subtitle: lang === "ar" ? "إدارة انتظار المرضى والنداء والانتقال للعيادة" : "Live patient queue and clinic flow",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					"aria-label": t("date"),
					className: "h-11 w-full sm:w-40",
					value: date,
					onChange: (e) => setDate(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: queue.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MetricStrip, {
				label: lang === "ar" ? "ملخص الطابور" : "Queue summary",
				cols: "sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "بانتظار النداء" : "Waiting",
						value: waiting,
						tone: waiting > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "نشط" : "Active",
						value: active,
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("completed"),
						value: done,
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: lang === "ar" ? "الإجمالي" : "Total",
						value: all.length
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Toolbar, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchField, {
				value: search,
				onChange: setSearch,
				placeholder: lang === "ar" ? "ابحث عن المريض أو رقم الطابور" : "Search patient or queue #"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: status,
				onValueChange: setStatus,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-11 w-full sm:w-44",
					"aria-label": t("status"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: STATUSES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: x,
					children: x === "all" ? lang === "ar" ? "الكل" : "All" : t(x)
				}, x)) })]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: rows.length === 0 && filtered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoResults, { onClear: () => {
				setSearch("");
				setStatus("all");
			} }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "الطابور فارغ حالياً." : "The queue is empty right now."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("queue"),
				children: rows.map((ticket) => {
					const visit = rel(ticket, "visits");
					const patient = rel(visit, "patients");
					const dept = rel(visit, "departments");
					const doctor = rel(visit, "users");
					const st = s(ticket, "status");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "space-y-2 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-12 rounded-lg bg-muted px-2 py-1 text-center font-mono text-lg font-extrabold",
									dir: "ltr",
									children: s(ticket, "queue_number")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "break-words font-semibold",
											children: s(patient, "full_name")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											dir: "ltr",
											children: s(patient, "mrn")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-xs text-muted-foreground",
											children: [
												lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name"),
												" · ",
												s(doctor, "full_name") || "—"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: st })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								canUpdate && st === "waiting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									className: "min-h-10 flex-1",
									onClick: () => update.mutate({
										id: s(ticket, "id"),
										status: "called"
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), lang === "ar" ? "نداء" : "Call"]
								}),
								canUpdate && st === "called" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									className: "min-h-10 flex-1",
									onClick: () => update.mutate({
										id: s(ticket, "id"),
										status: "in_progress"
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }), lang === "ar" ? "بدء" : "Start"]
								}),
								canUpdate && st === "in_progress" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									className: "min-h-10 flex-1",
									onClick: () => update.mutate({
										id: s(ticket, "id"),
										status: "completed"
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), lang === "ar" ? "إنهاء" : "Complete"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/clinic/$visitId",
									params: { visitId: s(visit, "id") },
									className: buttonVariants({
										variant: "outline",
										size: "sm",
										className: "min-h-10 flex-1"
									}),
									children: t("clinic")
								})
							]
						})]
					}, s(ticket, "id"));
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "#" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("department") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("doctor") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-end",
							children: t("actions")
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((ticket) => {
						const visit = rel(ticket, "visits");
						const patient = rel(visit, "patients");
						const dept = rel(visit, "departments");
						const doctor = rel(visit, "users");
						const st = s(ticket, "status");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: "font-mono font-bold",
								children: s(ticket, "queue_number")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InitialAvatar, { name: s(patient, "full_name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: s(patient, "full_name")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									dir: "ltr",
									children: s(patient, "mrn")
								})] })]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(doctor, "full_name") || "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: st }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "text-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-1",
									children: [
										canUpdate && st === "waiting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => update.mutate({
												id: s(ticket, "id"),
												status: "called"
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), lang === "ar" ? "نداء" : "Call"]
										}),
										canUpdate && st === "called" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											onClick: () => update.mutate({
												id: s(ticket, "id"),
												status: "in_progress"
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }), lang === "ar" ? "بدء" : "Start"]
										}),
										canUpdate && st === "in_progress" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											onClick: () => update.mutate({
												id: s(ticket, "id"),
												status: "completed"
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), lang === "ar" ? "إنهاء" : "Complete"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/clinic/$visitId",
											params: { visitId: s(visit, "id") },
											className: buttonVariants({
												variant: "ghost",
												size: "sm"
											}),
											children: t("clinic")
										})
									]
								})
							})
						] }, s(ticket, "id"));
					}) })]
				})
			})] }) })
		]
	});
}
//#endregion
export { QueuePage as component };
