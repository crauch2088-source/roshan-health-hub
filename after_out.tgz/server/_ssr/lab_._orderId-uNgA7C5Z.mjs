import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useParams, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s, r as n } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { B as FlaskConical, q as CircleCheck, st as ArrowLeft } from "../_libs/lucide-react.mjs";
import { E as StatusBadge, _ as PageHeader, a as Empty, b as PermissionGate, d as Input, f as Loading, n as Button, o as ErrorBox, w as SectionTitle, x as PrintButton } from "./kit-BmCdZVQb.mjs";
import { n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { i as calcAge } from "./medical-CD1sc5il.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab_._orderId-uNgA7C5Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LabOrderPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "lab.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabOrderPageInner, {})
	});
}
function LabOrderPageInner() {
	const { orderId } = useParams({ from: "/_authenticated/lab_/$orderId" });
	const { t, lang } = useLang();
	const { can, user } = useAuth();
	const [values, setValues] = (0, import_react.useState)({});
	const [comments, setComments] = (0, import_react.useState)({});
	const orderQ = useRows(["lab-order", orderId], () => supabase.from("lab_orders").select("id,status,created_at,ordered_at,patient_id,patients(id,full_name,mrn,gender,date_of_birth),users!lab_orders_ordered_by_fkey(full_name)").eq("id", orderId).limit(1));
	const itemsQ = useRows(["lab-items", orderId], () => supabase.from("lab_order_items").select("id,status,test_id,price,lab_tests(id,name,name_ar)").eq("order_id", orderId).is("deleted_at", null).order("created_at"));
	const order = (orderQ.data ?? [])[0];
	const patient = rel(order, "patients");
	const items = itemsQ.data ?? [];
	const testIds = items.map((i) => s(i, "test_id")).filter(Boolean);
	const parametersQ = useRows(["lab-parameters", ...testIds], () => testIds.length ? supabase.from("lab_parameters").select("id,test_id,name,code,unit,data_type,display_order,reference_text").in("test_id", testIds).eq("active", true).is("deleted_at", null).order("display_order") : supabase.from("lab_parameters").select("id,test_id,name,code,unit,data_type,display_order,reference_text").eq("test_id", "00000000-0000-0000-0000-000000000000"));
	const rangeQ = useRows([
		"lab-ranges",
		s(patient, "gender"),
		s(patient, "date_of_birth")
	], () => supabase.from("lab_reference_ranges").select("id,parameter_id,gender,min_age,max_age,lower_limit,upper_limit,text_reference,min_value,max_value,age_min,age_max,text_value,unit").is("deleted_at", null));
	const actualResultsQ = useRows([
		"lab-order-results",
		orderId,
		...items.map((i) => s(i, "id"))
	], () => {
		const itemIds = items.map((i) => s(i, "id")).filter(Boolean);
		return itemIds.length ? supabase.from("lab_results").select("*").in("order_item_id", itemIds) : supabase.from("lab_results").select("*").eq("order_item_id", "00000000-0000-0000-0000-000000000000");
	});
	(0, import_react.useEffect)(() => {
		const v = {};
		const c = {};
		for (const r of actualResultsQ.data ?? []) {
			const key = `${s(r, "order_item_id")}:${s(r, "parameter_id")}`;
			v[key] = s(r, "result_value");
			c[key] = s(r, "comment");
		}
		setValues(v);
		setComments(c);
	}, [actualResultsQ.data]);
	const age = calcAge(s(patient, "date_of_birth")) ?? void 0;
	const parameters = parametersQ.data ?? [];
	const ranges = rangeQ.data ?? [];
	function rangeFor(parameterId) {
		return ranges.find((r) => {
			if (s(r, "parameter_id") !== parameterId) return false;
			const gender = s(r, "gender");
			if (gender && gender !== s(patient, "gender")) return false;
			const min = n(r, "min_age") || n(r, "age_min");
			const max = n(r, "max_age") || n(r, "age_max");
			if (age !== void 0 && min !== 0 && min && age < min) return false;
			if (age !== void 0 && max !== 0 && max && age > max) return false;
			return true;
		}) ?? ranges.find((r) => s(r, "parameter_id") === parameterId);
	}
	const save = useSave(async () => {
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			const params = parameters.filter((p) => s(p, "test_id") === s(item, "test_id"));
			for (const p of params) {
				const key = `${s(item, "id")}:${s(p, "id")}`;
				const value = (values[key] ?? "").trim();
				if (!value) continue;
				const numeric = Number(value);
				const range = rangeFor(s(p, "id"));
				const low = range ? n(range, "lower_limit") || n(range, "min_value") : 0;
				const high = range ? n(range, "upper_limit") || n(range, "max_value") : 0;
				const abnormal = Number.isFinite(numeric) && (low !== 0 && numeric < low || high !== 0 && numeric > high);
				const flag = abnormal ? low !== 0 && numeric < low ? "low" : "high" : null;
				const payload = {
					order_item_id: s(item, "id"),
					parameter_id: s(p, "id"),
					result_value: value,
					numeric_value: Number.isFinite(numeric) ? numeric : null,
					flag,
					is_abnormal: abnormal,
					comment: comments[key] || null,
					entered_by: user?.id ?? null
				};
				const existing = (actualResultsQ.data ?? []).find((r) => s(r, "order_item_id") === s(item, "id") && s(r, "parameter_id") === s(p, "id"));
				const result = existing ? await supabase.from("lab_results").update(payload).eq("id", s(existing, "id")) : await supabase.from("lab_results").insert(payload);
				if (result.error) throw new Error(result.error.message);
			}
			await supabase.from("lab_order_items").update({
				status: "completed",
				completed_at: (/* @__PURE__ */ new Date()).toISOString(),
				updated_by: user?.id ?? null
			}).eq("id", s(item, "id"));
		}
		await supabase.from("lab_orders").update({
			status: "completed",
			completed_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_by: user?.id ?? null
		}).eq("id", orderId);
		return null;
	}, {
		invalidate: [
			["lab-order", orderId],
			["lab-items", orderId],
			["lab-order-results", orderId],
			["lab-orders"]
		],
		successMessage: t("saved")
	});
	const verify = useSave(async () => {
		const { error } = await supabase.from("lab_results").update({
			verified_by: user?.id ?? null,
			verified_at: (/* @__PURE__ */ new Date()).toISOString()
		}).in("order_item_id", items.map((i) => s(i, "id")));
		if (error) throw new Error(error.message);
		const { error: e } = await supabase.from("lab_orders").update({ status: "verified" }).eq("id", orderId);
		if (e) throw new Error(e.message);
		return null;
	}, {
		invalidate: [
			["lab-order", orderId],
			["lab-order-results", orderId],
			["lab-orders"]
		],
		successMessage: t("saved")
	});
	if (orderQ.isLoading || itemsQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	if (!order) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { label: t("no_data") });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
				title: lang === "ar" ? "طلب المختبر" : "Laboratory order",
				subtitle: `${s(patient, "full_name")} · ${t("mrn")}: ${s(patient, "mrn")} · ${t("age")}: ${age ?? "—"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(order, "status") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/lab",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), t("back")]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: orderQ.error ?? itemsQ.error ?? actualResultsQ.error ?? parametersQ.error ?? rangeQ.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: lang === "ar" ? "النتائج" : "Results" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-6",
						children: items.map((item) => {
							const test = rel(item, "lab_tests");
							const params = parameters.filter((p) => s(p, "test_id") === s(item, "test_id"));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-3 flex items-center gap-2 font-semibold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, { className: "size-4" }),
										lang === "ar" ? s(test, "name_ar") || s(test, "name") : s(test, "name"),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ms-auto text-xs text-muted-foreground",
											children: s(item, "status")
										})
									]
								}), params.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted-foreground",
									children: lang === "ar" ? "لا توجد معاملات لهذا الفحص" : "No parameters configured for this test."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
									density: "compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "المعامل" : "Parameter" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("result") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("unit") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "المرجع" : "Reference" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("notes") })
									] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: params.map((p) => {
										const key = `${s(item, "id")}:${s(p, "id")}`;
										const value = values[key] ?? "";
										const range = rangeFor(s(p, "id"));
										const low = range ? n(range, "lower_limit") || n(range, "min_value") : 0;
										const high = range ? n(range, "upper_limit") || n(range, "max_value") : 0;
										const num = Number(value);
										const abnormal = Number.isFinite(num) && (low !== 0 && num < low || high !== 0 && num > high);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
												className: "font-medium",
												children: [
													s(p, "name"),
													" ",
													s(p, "code") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-xs text-muted-foreground",
														children: [
															"(",
															s(p, "code"),
															")"
														]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
												className: "w-40",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													dir: "ltr",
													disabled: !can("lab.update"),
													value,
													onChange: (e) => setValues({
														...values,
														[key]: e.target.value
													})
												}), abnormal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-xs font-medium text-destructive",
													children: lang === "ar" ? "خارج المدى" : "Out of range"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												dir: "ltr",
												children: s(p, "unit") || s(range, "unit") || "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												dir: "ltr",
												children: range ? s(range, "text_reference") || `${low || "—"} – ${high || "—"}` : s(p, "reference_text") || "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: comments[key] ?? "",
												disabled: !can("lab.update"),
												onChange: (e) => setComments({
													...comments,
													[key]: e.target.value
												})
											}) })
										] }, key);
									}) })]
								})]
							}, s(item, "id"));
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "no-print mt-5 flex flex-wrap gap-2",
						children: [can("lab.update") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: save.isPending,
							onClick: () => save.mutate(void 0),
							children: save.isPending ? t("saving") : t("save_results")
						}), can("lab.verify") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							disabled: verify.isPending,
							onClick: () => verify.mutate(void 0),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), t("verify")]
						})]
					})
				]
			}) })
		]
	});
}
//#endregion
export { LabOrderPage as component };
