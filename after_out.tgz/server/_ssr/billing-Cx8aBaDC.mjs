import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as rpc, c as useRows, i as rel, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as Plus, l as Trash2 } from "../_libs/lucide-react.mjs";
import { E as StatusBadge, T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-BmCdZVQb.mjs";
import { n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-ChVCEi1n.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { a as formatDate, c as todayISO, s as money } from "./medical-CD1sc5il.mjs";
import { t as PatientPicker } from "./patient-picker-CheeOTs_.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-vwCASk5X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-Cx8aBaDC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BillingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "billing.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingPageInner, {})
	});
}
function BillingPageInner() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const { currency } = useSettings();
	const navigate = useNavigate();
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [open, setOpen] = (0, import_react.useState)(false);
	const [patientId, setPatientId] = (0, import_react.useState)("");
	const [selectedPatient, setSelectedPatient] = (0, import_react.useState)(null);
	const [partnerId, setPartnerId] = (0, import_react.useState)("");
	const [discount, setDiscount] = (0, import_react.useState)("0");
	const [lines, setLines] = (0, import_react.useState)([{
		description: "",
		quantity: "1",
		unit_price: "0",
		item_type: "consultation"
	}]);
	const invoices = useRows(["invoices", date], () => supabase.from("invoices").select("id, invoice_number, invoice_date, status, total_amount, discount_amount, net_amount, paid_amount, patients(full_name, mrn), partners(name)").eq("invoice_date", date).is("deleted_at", null).order("created_at", { ascending: false }));
	const partners = useRows(["partners"], () => supabase.from("partners").select("id, name, discount_percent").is("deleted_at", null));
	const subtotal = lines.reduce((sum, l) => sum + Number(l.quantity || 0) * Number(l.unit_price || 0), 0);
	const net = Math.max(subtotal - Number(discount || 0), 0);
	const create = useSave(async () => {
		const invoiceNumber = await rpc("next_invoice_number");
		const { data: inv, error } = await supabase.from("invoices").insert({
			invoice_number: invoiceNumber,
			patient_id: patientId,
			partner_id: partnerId || null,
			invoice_date: date,
			total_amount: subtotal,
			discount_amount: Number(discount) || 0,
			net_amount: net,
			paid_amount: 0,
			status: "unpaid"
		}).select("id").single();
		if (error) throw new Error(error.message);
		const items = lines.filter((l) => l.description).map((l) => ({
			invoice_id: inv.id,
			item_name: l.description,
			item_type: l.item_type,
			quantity: Number(l.quantity) || 1,
			unit_price: Number(l.unit_price) || 0,
			total_price: (Number(l.quantity) || 1) * (Number(l.unit_price) || 0)
		}));
		if (items.length) {
			const { error: iErr } = await supabase.from("invoice_items").insert(items);
			if (iErr) throw new Error(iErr.message);
		}
		return inv.id;
	}, {
		invalidate: [["invoices", date]],
		successMessage: t("saved"),
		onDone: (id) => {
			setOpen(false);
			setSelectedPatient(null);
			setPatientId("");
			setLines([{
				description: "",
				quantity: "1",
				unit_price: "0",
				item_type: "consultation"
			}]);
			setDiscount("0");
			if (typeof id === "string") navigate({
				to: "/billing/$invoiceId",
				params: { invoiceId: id }
			});
		}
	});
	const rows = invoices.data ?? [];
	const totalNet = rows.reduce((sum, r) => sum + n(r, "net_amount"), 0);
	const totalPaid = rows.reduce((sum, r) => sum + n(r, "paid_amount"), 0);
	if (invoices.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("billing"),
			subtitle: formatDate(date),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: date,
					onChange: (e) => setDate(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: `roshan-invoices-${date}`
				}),
				can("billing.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
								" ",
								t("new_invoice") || "فاتورة جديدة"
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-h-[90vh] max-w-3xl overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("new_invoice") || "فاتورة جديدة" }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: `${t("patient")} *`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPicker, {
												value: selectedPatient,
												onSelect: (p) => {
													setSelectedPatient(p);
													setPatientId(p?.id ?? "");
												}
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: t("partners"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: partnerId,
												onValueChange: setPartnerId,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("cash") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (partners.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: s(p, "id"),
													children: s(p, "name")
												}, s(p, "id"))) })]
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [lines.map((l, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-2 rounded-md border p-2 sm:grid-cols-5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													className: "sm:col-span-2",
													placeholder: t("description"),
													value: l.description,
													onChange: (e) => setLines(lines.map((x, i) => i === idx ? {
														...x,
														description: e.target.value
													} : x))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: l.item_type,
													onValueChange: (v) => setLines(lines.map((x, i) => i === idx ? {
														...x,
														item_type: v
													} : x)),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "consultation",
															children: t("consultation_fee")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "lab",
															children: t("laboratory")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "pharmacy",
															children: t("pharmacy")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "procedure",
															children: t("procedure")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "other",
															children: t("other")
														})
													] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													dir: "ltr",
													min: 1,
													placeholder: t("quantity"),
													value: l.quantity,
													onChange: (e) => setLines(lines.map((x, i) => i === idx ? {
														...x,
														quantity: e.target.value
													} : x))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														type: "number",
														dir: "ltr",
														min: 0,
														placeholder: t("unit_price"),
														value: l.unit_price,
														onChange: (e) => setLines(lines.map((x, i) => i === idx ? {
															...x,
															unit_price: e.target.value
														} : x))
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														variant: "ghost",
														size: "icon",
														onClick: () => setLines(lines.filter((_, i) => i !== idx)),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})]
												})
											]
										}, idx)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "outline",
											size: "sm",
											onClick: () => setLines([...lines, {
												description: "",
												quantity: "1",
												unit_price: "0",
												item_type: "other"
											}]),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
												" ",
												t("add")
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: t("subtotal"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													readOnly: true,
													dir: "ltr",
													value: money(subtotal, currency)
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: t("discount"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													dir: "ltr",
													min: 0,
													value: discount,
													onChange: (e) => setDiscount(e.target.value)
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: t("net"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													readOnly: true,
													dir: "ltr",
													value: money(net, currency)
												})
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setOpen(false),
								children: t("cancel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: !patientId || create.isPending,
								onClick: () => create.mutate(void 0),
								children: create.isPending ? t("saving") : t("save")
							})] })
						]
					})]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: invoices.error ?? partners.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("invoices"),
					value: String(rows.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("net"),
					value: money(totalNet, currency)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("outstanding"),
					value: money(totalNet - totalPaid, currency)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "لا فواتير في هذا النطاق." : "No invoices in this range."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("invoice_number") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("paid") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("balance") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						className: "font-mono text-xs",
						children: s(inv, "invoice_number")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: s(rel(inv, "patients"), "full_name")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(inv, "net_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(inv, "paid_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(inv, "net_amount") - n(inv, "paid_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(inv, "status") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "no-print text-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/billing/$invoiceId",
								params: { invoiceId: s(inv, "id") },
								children: t("open")
							})
						})
					})
				] }, s(inv, "id"))) })]
			})
		}) })
	] });
}
//#endregion
export { BillingPage as component };
