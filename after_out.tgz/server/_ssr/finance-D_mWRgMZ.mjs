import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as rpc, c as useRows, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { C as Plus, v as RotateCcw } from "../_libs/lucide-react.mjs";
import { A as cn, D as Textarea, T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons, t as Badge } from "./kit-asLB5pSR.mjs";
import { n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-WDSquJSC.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, o as formatDateTime, s as money } from "./medical-CD1sc5il.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-Cz_DZk-6.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DcyYd86X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance-D_mWRgMZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FinancePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "cashbox.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinancePageInner, {})
	});
}
function FinancePageInner() {
	const { t, lang } = useLang();
	const { currency } = useSettings();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: t("finance_hub"),
		subtitle: t("finance_hub_subtitle")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		defaultValue: "cashbox",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
				className: "mb-4 flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "cashbox",
						children: t("cashbox")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "receivables",
						children: t("receivables")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "suppliers_debt",
						children: t("supplier_debt")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "cashbox",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CashboxTab, { currency })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "receivables",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceivablesTab, { currency })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "suppliers_debt",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupplierDebtTab, { currency })
			})
		]
	})] });
}
function CashboxTab({ currency }) {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [entryOpen, setEntryOpen] = (0, import_react.useState)(false);
	const [direction, setDirection] = (0, import_react.useState)("deposit");
	const [amount, setAmount] = (0, import_react.useState)("0");
	const [method, setMethod] = (0, import_react.useState)("cash");
	const [description, setDescription] = (0, import_react.useState)("");
	const [reverseTarget, setReverseTarget] = (0, import_react.useState)(null);
	const [reverseReason, setReverseReason] = (0, import_react.useState)("");
	const balance = useRows(["cashbox-balance"], () => supabase.from("cashbox_balance").select("*"));
	const txns = useRows(["cashbox-transactions"], () => supabase.from("cashbox_transactions").select("id, transaction_type, amount, payment_method, category, description, transaction_date, is_reversed, reversal_of").is("deleted_at", null).order("transaction_date", { ascending: false }).limit(200));
	const post = useSave(async () => {
		const amt = Number(amount);
		if (!amt || amt <= 0) throw new Error(t("invalid_quantity"));
		await rpc("post_cashbox_entry", {
			_direction: direction,
			_amount: amt,
			_method: method,
			_category: "manual",
			_description: description || null
		});
		return null;
	}, {
		invalidate: [["cashbox-balance"], ["cashbox-transactions"]],
		successMessage: t("saved"),
		onDone: () => {
			setEntryOpen(false);
			setAmount("0");
			setDescription("");
		}
	});
	const reverse = useSave(async () => {
		if (!reverseTarget) return null;
		if (!reverseReason.trim()) throw new Error(t("reversal_reason_required"));
		await rpc("reverse_cashbox_entry", {
			_transaction_id: s(reverseTarget, "id"),
			_reason: reverseReason.trim()
		});
		return null;
	}, {
		invalidate: [["cashbox-balance"], ["cashbox-transactions"]],
		successMessage: t("saved"),
		onDone: () => {
			setReverseTarget(null);
			setReverseReason("");
		}
	});
	const bal = (balance.data ?? [])[0];
	const rows = txns.data ?? [];
	if (balance.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex flex-wrap items-center justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-cashbox"
			}), can("cashbox.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => setEntryOpen(true),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
					" ",
					t("cashbox_entry")
				]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: balance.error ?? txns.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("cashbox_balance"),
					value: money(n(bal, "balance"), currency)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("cash_in"),
					value: money(n(bal, "total_in"), currency),
					tone: "success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("cash_out"),
					value: money(n(bal, "total_out"), currency),
					tone: "destructive"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "لا حركات لعرضها." : "No transactions to show."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("cashbox"),
				children: rows.map((tx) => {
					const amt = n(tx, "amount");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "space-y-1.5 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-medium",
										children: [t(s(tx, "transaction_type")), s(tx, "category") ? ` · ${s(tx, "category")}` : ""]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										dir: "ltr",
										children: formatDateTime(s(tx, "transaction_date"))
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									className: cn("shrink-0 font-semibold", amt < 0 ? "text-destructive" : "text-success"),
									children: amt > 0 ? `+${money(amt, currency)}` : money(amt, currency)
								})]
							}),
							s(tx, "description") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: s(tx, "description")
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									tx["is_reversed"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px]",
										children: t("reversed")
									}) : null,
									tx["reversal_of"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px]",
										children: t("reversal")
									}) : null,
									can("cashbox.update") && !tx["is_reversed"] && !tx["reversal_of"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "sm",
										className: "ms-auto",
										onClick: () => setReverseTarget(tx),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }),
											" ",
											t("reverse")
										]
									}) : null
								]
							})
						]
					}, s(tx, "id"));
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("type") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("category") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("description") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((tx) => {
						const amt = n(tx, "amount");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDateTime(s(tx, "transaction_date"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: t(s(tx, "transaction_type")) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(tx, "category") || "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "max-w-64 truncate",
								children: [
									s(tx, "description") || "—",
									tx["is_reversed"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "ms-2 text-[10px]",
										children: t("reversed")
									}) : null,
									tx["reversal_of"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "ms-2 text-[10px]",
										children: t("reversal")
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: amt < 0 ? "font-semibold text-destructive" : "font-semibold text-success",
								children: amt > 0 ? `+${money(amt, currency)}` : money(amt, currency)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "no-print text-end",
								children: can("cashbox.update") && !tx["is_reversed"] && !tx["reversal_of"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => setReverseTarget(tx),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }),
										" ",
										t("reverse")
									]
								}) : null
							})
						] }, s(tx, "id"));
					}) })]
				})
			})] })
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: entryOpen,
			onOpenChange: setEntryOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("cashbox_entry") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("type"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: direction,
								onValueChange: (v) => setDirection(v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "deposit",
									children: t("deposit")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "withdrawal",
									children: t("withdrawal")
								})] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `${t("amount")} *`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								dir: "ltr",
								value: amount,
								onChange: (e) => setAmount(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("payment_method"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: method,
								onValueChange: setMethod,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "cash",
									children: t("cash")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "bank",
									children: t("bank")
								})] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("description"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 2,
								value: description,
								onChange: (e) => setDescription(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setEntryOpen(false),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: post.isPending,
					onClick: () => post.mutate(void 0),
					children: post.isPending ? t("saving") : t("save")
				})] })
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(reverseTarget),
			onOpenChange: (o) => o ? null : setReverseTarget(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("reverse") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `${t("reversal_reason")} *`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 2,
						value: reverseReason,
						onChange: (e) => setReverseReason(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setReverseTarget(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !reverseReason.trim() || reverse.isPending,
					onClick: () => reverse.mutate(void 0),
					children: reverse.isPending ? t("saving") : t("save")
				})] })
			] })
		})
	] });
}
function ReceivablesTab({ currency }) {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [payTarget, setPayTarget] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("0");
	const [method, setMethod] = (0, import_react.useState)("cash");
	const [reference, setReference] = (0, import_react.useState)("");
	const list = useRows(["patient-receivables"], () => supabase.from("v_patient_receivables").select("*").order("outstanding", { ascending: false }).limit(300));
	const pay = useSave(async () => {
		if (!payTarget) return null;
		const amt = Number(amount);
		if (!amt || amt <= 0) throw new Error(t("invalid_quantity"));
		await rpc("post_invoice_payment", {
			_invoice_id: s(payTarget, "invoice_id"),
			_amount: amt,
			_method: method,
			_reference: reference || null
		});
		return null;
	}, {
		invalidate: [
			["patient-receivables"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setPayTarget(null);
			setAmount("0");
			setReference("");
		}
	});
	const rows = list.data ?? [];
	const totalOutstanding = rows.reduce((sum, r) => sum + n(r, "outstanding"), 0);
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "no-print mb-4 flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-receivables"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: t("outstanding_balance"),
				value: money(totalOutstanding, currency),
				tone: "warning"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("receivables"),
				children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "space-y-1 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 break-words font-medium",
								children: [s(r, "patient_name"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ms-1 text-xs text-muted-foreground",
									dir: "ltr",
									children: [
										"(",
										s(r, "mrn"),
										")"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 font-semibold text-destructive",
								children: money(n(r, "outstanding"), currency)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								children: s(r, "invoice_number") || "—"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								children: s(r, "invoice_date") ? formatDate(s(r, "invoice_date")) : "—"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								t("net"),
								": ",
								money(n(r, "net_amount"), currency)
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								t("paid_amount"),
								": ",
								money(n(r, "paid_amount"), currency)
							] })]
						}),
						can("payments.create") || can("billing.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "no-print w-full",
							onClick: () => {
								setPayTarget(r);
								setAmount(String(n(r, "outstanding")));
							},
							children: t("record_payment")
						}) : null
					]
				}, s(r, "invoice_id")))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("invoice_number") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("paid_amount") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("outstanding_balance") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
							className: "font-medium",
							children: [s(r, "patient_name"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ms-1 text-xs text-muted-foreground",
								dir: "ltr",
								children: [
									"(",
									s(r, "mrn"),
									")"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(r, "invoice_number") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(r, "invoice_date") ? formatDate(s(r, "invoice_date")) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "net_amount"), currency) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "paid_amount"), currency) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-semibold text-destructive",
							children: money(n(r, "outstanding"), currency)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "no-print text-end",
							children: can("payments.create") || can("billing.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => {
									setPayTarget(r);
									setAmount(String(n(r, "outstanding")));
								},
								children: t("record_payment")
							}) : null
						})
					] }, s(r, "invoice_id"))) })]
				})
			})] })
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(payTarget),
			onOpenChange: (o) => o ? null : setPayTarget(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("record_payment") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `${t("amount")} *`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								dir: "ltr",
								value: amount,
								onChange: (e) => setAmount(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("payment_method"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: method,
								onValueChange: setMethod,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "cash",
									children: t("cash")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "bank",
									children: t("bank")
								})] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("reference"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								dir: "ltr",
								value: reference,
								onChange: (e) => setReference(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setPayTarget(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: pay.isPending,
					onClick: () => pay.mutate(void 0),
					children: pay.isPending ? t("saving") : t("save")
				})] })
			] })
		})
	] });
}
function SupplierDebtTab({ currency }) {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [billOpen, setBillOpen] = (0, import_react.useState)(false);
	const [supplierId, setSupplierId] = (0, import_react.useState)("");
	const [invoiceNumber, setInvoiceNumber] = (0, import_react.useState)("");
	const [subtotal, setSubtotal] = (0, import_react.useState)("0");
	const [discount, setDiscount] = (0, import_react.useState)("0");
	const [payTarget, setPayTarget] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("0");
	const [method, setMethod] = (0, import_react.useState)("cash");
	const outstanding = useRows(["supplier-outstanding"], () => supabase.from("v_supplier_outstanding").select("*").order("outstanding", { ascending: false }));
	const suppliers = useRows(["suppliers-picker-finance"], () => supabase.from("suppliers").select("id, name").is("deleted_at", null).eq("active", true).order("name", { ascending: true }));
	const bills = useRows(["supplier-bills"], () => supabase.from("supplier_bills").select("id, supplier_id, invoice_number, bill_date, total_amount, paid_amount, status, suppliers(name)").is("deleted_at", null).order("bill_date", { ascending: false }).limit(200));
	const createBill = useSave(async () => {
		if (!supplierId) throw new Error(t("select_medicine"));
		const sub = Number(subtotal);
		if (!sub || sub <= 0) throw new Error(t("invalid_quantity"));
		await rpc("post_supplier_bill", {
			_supplier_id: supplierId,
			_invoice_number: invoiceNumber || null,
			_bill_date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
			_due_date: null,
			_subtotal: sub,
			_discount: Number(discount) || 0
		});
		return null;
	}, {
		invalidate: [["supplier-bills"], ["supplier-outstanding"]],
		successMessage: t("saved"),
		onDone: () => {
			setBillOpen(false);
			setSupplierId("");
			setInvoiceNumber("");
			setSubtotal("0");
			setDiscount("0");
		}
	});
	const pay = useSave(async () => {
		if (!payTarget) return null;
		const amt = Number(amount);
		if (!amt || amt <= 0) throw new Error(t("invalid_quantity"));
		await rpc("post_supplier_payment", {
			_bill_id: s(payTarget, "id"),
			_amount: amt,
			_method: method
		});
		return null;
	}, {
		invalidate: [
			["supplier-bills"],
			["supplier-outstanding"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setPayTarget(null);
			setAmount("0");
		}
	});
	const outstandingRows = outstanding.data ?? [];
	const billRows = bills.data ?? [];
	const totalOutstanding = outstandingRows.reduce((sum, r) => sum + n(r, "outstanding"), 0);
	if (outstanding.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex flex-wrap items-center justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows: billRows,
				filename: "roshan-supplier-bills"
			}), can("debts.create") || can("pharmacy.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => setBillOpen(true),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
					" ",
					t("new_supplier_bill")
				]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: outstanding.error ?? bills.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: t("supplier_debt"),
				value: money(totalOutstanding, currency),
				tone: "warning"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0",
				children: outstandingRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y md:hidden",
					"aria-label": t("outstanding_balance"),
					children: outstandingRows.filter((r) => n(r, "bills_count") > 0).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "space-y-1 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "break-words font-medium",
								children: s(r, "name")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("total_billed"),
									": ",
									money(n(r, "total_billed"), currency)
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("total_paid"),
									": ",
									money(n(r, "total_paid"), currency)
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("text-sm", n(r, "outstanding") > 0 && "font-semibold text-destructive"),
								children: [
									t("outstanding_balance"),
									": ",
									money(n(r, "outstanding"), currency)
								]
							})
						]
					}, s(r, "supplier_id")))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("supplier") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("total_billed") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("total_paid") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("outstanding_balance") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: outstandingRows.filter((r) => n(r, "bills_count") > 0).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(r, "name")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "total_billed"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "total_paid"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: n(r, "outstanding") > 0 ? "font-semibold text-destructive" : void 0,
								children: money(n(r, "outstanding"), currency)
							})
						] }, s(r, "supplier_id"))) })]
					})
				})] })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: billRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("supplier"),
				children: billRows.map((b) => {
					const outstandingAmt = n(b, "total_amount") - n(b, "paid_amount");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "space-y-1 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 break-words font-medium",
									children: s(b, "suppliers") ? b["suppliers"]["name"] : "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-xs text-muted-foreground",
									children: t(s(b, "status"))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: formatDate(s(b, "bill_date"))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: s(b, "invoice_number") || "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("net"),
									": ",
									money(n(b, "total_amount"), currency)
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("paid_amount"),
									": ",
									money(n(b, "paid_amount"), currency)
								] })]
							}),
							(can("debts.create") || can("accounting.create")) && outstandingAmt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								className: "no-print w-full",
								onClick: () => {
									setPayTarget(b);
									setAmount(String(outstandingAmt));
								},
								children: t("record_payment")
							}) : null
						]
					}, s(b, "id"));
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("supplier") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("invoice_number") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("paid_amount") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: billRows.map((b) => {
						const outstandingAmt = n(b, "total_amount") - n(b, "paid_amount");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDate(s(b, "bill_date"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(b, "suppliers") ? b["suppliers"]["name"] : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: s(b, "invoice_number") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(b, "total_amount"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(b, "paid_amount"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: t(s(b, "status")) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "no-print text-end",
								children: (can("debts.create") || can("accounting.create")) && outstandingAmt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => {
										setPayTarget(b);
										setAmount(String(outstandingAmt));
									},
									children: t("record_payment")
								}) : null
							})
						] }, s(b, "id"));
					}) })]
				})
			})] })
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: billOpen,
			onOpenChange: setBillOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("new_supplier_bill") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `${t("supplier")} *`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: supplierId,
								onValueChange: setSupplierId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("select_medicine") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (suppliers.data ?? []).map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s(sp, "id"),
									children: s(sp, "name")
								}, s(sp, "id"))) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("invoice_number"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								dir: "ltr",
								value: invoiceNumber,
								onChange: (e) => setInvoiceNumber(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `${t("subtotal")} *`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								dir: "ltr",
								value: subtotal,
								onChange: (e) => setSubtotal(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("discount"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								dir: "ltr",
								value: discount,
								onChange: (e) => setDiscount(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setBillOpen(false),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !supplierId || !subtotal || createBill.isPending,
					onClick: () => createBill.mutate(void 0),
					children: createBill.isPending ? t("saving") : t("save")
				})] })
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(payTarget),
			onOpenChange: (o) => o ? null : setPayTarget(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("record_payment") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `${t("amount")} *`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							dir: "ltr",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("payment_method"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: method,
							onValueChange: setMethod,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "cash",
								children: t("cash")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "bank",
								children: t("bank")
							})] })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setPayTarget(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: pay.isPending,
					onClick: () => pay.mutate(void 0),
					children: pay.isPending ? t("saving") : t("save")
				})] })
			] })
		})
	] });
}
//#endregion
export { FinancePage as component };
