import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { $ as ChevronLeft, B as FlaskConical, Q as ChevronRight, T as Pill, a as UserRound, c as TriangleAlert, i as Users, it as Banknote, r as Wallet, x as Receipt } from "../_libs/lucide-react.mjs";
import { A as cn, E as StatusBadge, _ as PageHeader, a as Empty, b as PermissionGate, f as Loading, h as MetricStrip, m as Metric, o as ErrorBox, r as DataPanel, t as Badge, v as PageSkeleton, w as SectionTitle } from "./kit-asLB5pSR.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, c as todayISO, s as money } from "./medical-CD1sc5il.mjs";
import { r as expiryStatus, t as EXPIRY_TONE } from "./pharmacy-Co3jb7c8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-w_Ea8Nq7.js
var import_jsx_runtime = require_jsx_runtime();
/** "View all" link in a panel header; hidden when the user may not open the destination. */
function ViewAll({ to, perm }) {
	const { t, lang } = useLang();
	const { can } = useAuth();
	if (!can(perm)) return null;
	const Chevron = lang === "ar" ? ChevronLeft : ChevronRight;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "inline-flex min-h-9 items-center gap-0.5 rounded-md px-1.5 text-xs font-semibold text-primary outline-none hover:underline focus-visible:ring-2 focus-visible:ring-ring",
		children: [
			t("view_all"),
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, {
				className: "size-3.5",
				"aria-hidden": true
			})
		]
	});
}
function DashboardPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "dashboard.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardPageInner, {})
	});
}
function DashboardPageInner() {
	const { t, lang } = useLang();
	const { user } = useAuth();
	const { currency, settings } = useSettings();
	const today = todayISO();
	const monthStart = `${today.slice(0, 7)}-01`;
	const visits = useRows(["dash-visits", today], () => supabase.from("visits").select("id, status, visit_date, consultation_fee, patients(full_name, mrn), departments(name, name_ar)").eq("visit_date", today).is("deleted_at", null).order("created_at", { ascending: false }));
	const patientsToday = useRows(["dash-patients", today], () => supabase.from("patients").select("id").gte("created_at", `${today}T00:00:00`).is("deleted_at", null));
	const appointments = useRows(["dash-appts", today], () => supabase.from("appointments").select("id, status, appointment_date, appointment_time, patients(full_name)").eq("appointment_date", today).is("deleted_at", null).order("appointment_time", { ascending: true }));
	const payments = useRows(["dash-payments", monthStart], () => supabase.from("payments").select("amount, payment_date, method").gte("payment_date", monthStart).is("deleted_at", null));
	const expenses = useRows(["dash-expenses", monthStart], () => supabase.from("expenses").select("amount, expense_date, category").gte("expense_date", monthStart).is("deleted_at", null));
	const labPending = useRows(["dash-lab"], () => supabase.from("lab_orders").select("id, status, created_at, patients(full_name)").in("status", [
		"pending",
		"collected",
		"in_progress"
	]).is("deleted_at", null).order("created_at", { ascending: false }).limit(10));
	const rxPending = useRows(["dash-rx"], () => supabase.from("prescriptions").select("id, status, created_at, patients(full_name)").eq("status", "pending").eq("is_external", false).is("deleted_at", null).order("created_at", { ascending: false }).limit(10));
	const followups = useRows(["dash-followups"], () => supabase.from("followups").select("id, followup_date, status, reason, patients(full_name)").gte("followup_date", today).is("deleted_at", null).order("followup_date", { ascending: true }).limit(8));
	const thresholdDays = Number(settings["pharmacy_expiry_threshold_days"]) || 90;
	const lowStockMeds = useRows(["dash-low-stock"], () => supabase.from("medicines").select("id, name, stock_quantity, reorder_level").is("deleted_at", null).order("stock_quantity", { ascending: true }).limit(200));
	const batchesForAlerts = useRows(["dash-batches"], () => supabase.from("pharmacy_inventory").select("id, expiry_date, quantity_remaining, medicines(name)").is("deleted_at", null).gt("quantity_remaining", 0).order("expiry_date", {
		ascending: true,
		nullsFirst: false
	}).limit(300));
	const insurance = useRows(["dash-insurance-claims"], () => supabase.from("insurance_claims").select("id, claim_number, status, submitted_amount").is("deleted_at", null).in("status", ["submitted", "under_review"]).order("created_at", { ascending: false }).limit(8));
	const insurancePendingRows = insurance.data ?? [];
	const anyError = visits.error ?? payments.error ?? expenses.error ?? labPending.error ?? rxPending.error;
	const visitRows = visits.data ?? [];
	const paymentRows = payments.data ?? [];
	const expenseRows = expenses.data ?? [];
	const revenueToday = paymentRows.filter((p) => s(p, "payment_date").startsWith(today)).reduce((sum, p) => sum + n(p, "amount"), 0);
	const revenueMonth = paymentRows.reduce((sum, p) => sum + n(p, "amount"), 0);
	const expensesToday = expenseRows.filter((p) => s(p, "expense_date").startsWith(today)).reduce((sum, p) => sum + n(p, "amount"), 0);
	const expensesMonth = expenseRows.reduce((sum, p) => sum + n(p, "amount"), 0);
	const waiting = visitRows.filter((v) => s(v, "status") === "waiting").length;
	const lowStockRows = (lowStockMeds.data ?? []).filter((m) => n(m, "stock_quantity") <= n(m, "reorder_level")).slice(0, 8);
	const batchRows = batchesForAlerts.data ?? [];
	const expiringRows = batchRows.filter((b) => expiryStatus(s(b, "expiry_date") || null, thresholdDays) === "expiring_soon").slice(0, 8);
	const expiredRows = batchRows.filter((b) => expiryStatus(s(b, "expiry_date") || null, thresholdDays) === "expired").slice(0, 8);
	if (visits.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: t("app_name"),
			title: t("dashboard"),
			subtitle: `${user?.full_name ?? ""} · ${user?.role_name ?? ""} · ${formatDate(today)}`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: anyError }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("executive_summary") }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MetricStrip, {
				label: t("clinical_summary"),
				cols: "sm:grid-cols-3 xl:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("visits_today"),
						value: visitRows.length,
						hint: `${t("waiting_patients")}: ${waiting}`,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("patients_today"),
						value: (patientsToday.data ?? []).length,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {}),
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("appointments_today"),
						value: (appointments.data ?? []).length,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("pending_lab"),
						value: (labPending.data ?? []).length,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, {}),
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("pending_pharmacy"),
						value: (rxPending.data ?? []).length,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {}),
						tone: "warning"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MetricStrip, {
				label: t("revenue_today"),
				cols: "sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("revenue_today"),
						value: money(revenueToday, currency),
						hint: `${t("monthly_revenue")}: ${money(revenueMonth, currency)}`,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, {}),
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("expenses_today"),
						value: money(expensesToday, currency),
						hint: `${t("net_profit")}: ${money(revenueMonth - expensesMonth, currency)}`,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {}),
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: t("net_profit"),
						value: money(revenueMonth - expensesMonth, currency),
						hint: t("monthly_revenue"),
						tone: revenueMonth - expensesMonth >= 0 ? "success" : "destructive"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("clinical_summary") })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("visits_today"),
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAll, {
						to: "/visits",
						perm: "visits.read"
					}),
					children: visitRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("department") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: visitRows.slice(0, 8).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(rel(v, "patients"), "full_name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: lang === "ar" ? s(rel(v, "departments"), "name_ar") || s(rel(v, "departments"), "name") : s(rel(v, "departments"), "name") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(v, "status") }) })
						] }, s(v, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("upcoming_appointments"),
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAll, {
						to: "/appointments",
						perm: "appointments.read"
					}),
					children: (appointments.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (appointments.data ?? []).slice(0, 8).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(rel(a, "patients"), "full_name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: s(a, "appointment_time").slice(0, 5) || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(a, "status") }) })
						] }, s(a, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("pending_tasks") })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("pending_lab"),
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAll, {
						to: "/lab",
						perm: "lab.read"
					}),
					children: (labPending.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (labPending.data ?? []).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: s(rel(o, "patients"), "full_name") || "—"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(o, "status") }) })] }, s(o, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("upcoming_followups"),
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAll, {
						to: "/followups",
						perm: "followups.read"
					}),
					children: (followups.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("due_date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("reason") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (followups.data ?? []).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(rel(f, "patients"), "full_name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: formatDate(s(f, "followup_date"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "max-w-40 truncate",
								children: s(f, "reason") || "—"
							})
						] }, s(f, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("pharmacy_summary") })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("low_stock_medicines"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "text-warning",
						"aria-hidden": true
					}),
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAll, {
						to: "/inventory",
						perm: "pharmacy.read"
					}),
					children: lowStockRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("stock") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("reorder_level") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: lowStockRows.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(m, "name")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: "font-semibold text-destructive",
								children: n(m, "stock_quantity")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: n(m, "reorder_level")
							})
						] }, s(m, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("expiring_medicines"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "text-warning",
						"aria-hidden": true
					}),
					children: expiringRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("remaining_quantity") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: expiringRows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(rel(b, "medicines"), "name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: cn("font-medium", EXPIRY_TONE.expiring_soon),
									children: formatDate(s(b, "expiry_date"))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: n(b, "quantity_remaining")
							})
						] }, s(b, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("expired_medicines"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "text-destructive",
						"aria-hidden": true
					}),
					children: expiredRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("remaining_quantity") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: expiredRows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(rel(b, "medicines"), "name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: cn("font-medium", EXPIRY_TONE.expired),
									children: formatDate(s(b, "expiry_date"))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: n(b, "quantity_remaining")
							})
						] }, s(b, "id"))) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("insurance_summary") })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {
					title: t("insurance_claims"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, {
						className: "text-warning",
						"aria-hidden": true
					}),
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAll, {
						to: "/insurance",
						perm: "insurance.read"
					}),
					children: insurance.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : insurancePendingRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("claim_number") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: insurancePendingRows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: "font-mono text-xs",
								children: s(c, "claim_number")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(c, "submitted_amount"), currency) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(c, "status") }) })
						] }, s(c, "id"))) })]
					})
				})
			]
		})
	] });
}
//#endregion
export { DashboardPage as component };
