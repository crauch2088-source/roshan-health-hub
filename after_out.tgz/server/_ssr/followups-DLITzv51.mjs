import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { D as Textarea, E as StatusBadge, _ as PageHeader, a as Empty, b as PermissionGate, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-BmCdZVQb.mjs";
import { n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-ChVCEi1n.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { a as formatDate, c as todayISO } from "./medical-CD1sc5il.mjs";
import { t as PatientPicker } from "./patient-picker-CheeOTs_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/followups-DLITzv51.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FollowupsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "followups.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FollowupsPageInner, {})
	});
}
function FollowupsPageInner() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [from, setFrom] = (0, import_react.useState)(todayISO());
	const [to, setTo] = (0, import_react.useState)(todayISO());
	const [open, setOpen] = (0, import_react.useState)(false);
	const [selectedPatient, setSelectedPatient] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		patient_id: "",
		patient_name: "",
		followup_date: todayISO(),
		reason: ""
	});
	const list = useRows([
		"followups",
		from,
		to
	], () => supabase.from("followups").select("*, patients(id, full_name, phone, mrn), users!followups_created_by_fkey(full_name)").gte("followup_date", from).lte("followup_date", to).is("deleted_at", null).order("followup_date", { ascending: true }));
	const create = useSave(async () => {
		if (!form.patient_id) throw new Error(t("patient"));
		const { error } = await supabase.from("followups").insert({
			patient_id: form.patient_id,
			followup_date: form.followup_date,
			reason: form.reason.trim() || null,
			status: "pending"
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [[
			"followups",
			from,
			to
		]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm({
				patient_id: "",
				patient_name: "",
				followup_date: todayISO(),
				reason: ""
			});
			setSelectedPatient(null);
		}
	});
	const mark = useSave(async ({ id, status }) => {
		const { error } = await supabase.from("followups").update({ status }).eq("id", id);
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [[
			"followups",
			from,
			to
		]],
		successMessage: t("saved")
	});
	const rows = list.data ?? [];
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("followups"),
			subtitle: `${formatDate(from)} — ${formatDate(to)}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: from,
					onChange: (e) => setFrom(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: to,
					onChange: (e) => setTo(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: `roshan-followups-${from}`
				}),
				can("followups.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setOpen(true),
					children: [
						t("add"),
						" ",
						t("followups")
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "لا متابعات في هذه الفترة." : "No follow-ups in this period."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("phone") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("doctor") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("notes") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((f) => {
					const p = rel(f, "patients");
					const creator = rel(f, "users");
					const status = s(f, "status") || "pending";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: formatDate(s(f, "followup_date"))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: s(p, "id") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/patients/$patientId",
								params: { patientId: s(p, "id") },
								className: "hover:underline",
								children: s(p, "full_name")
							}) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(p, "phone") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(creator, "full_name") || "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "max-w-[16rem] truncate",
							children: s(f, "reason") || s(f, "notes") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "no-print text-end",
							children: can("visits.update") && status !== "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => mark.mutate({
									id: s(f, "id"),
									status: "completed"
								}),
								children: t("mark_done")
							}) : null
						})
					] }, s(f, "id"));
				}) })]
			})
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: (value) => {
				setOpen(value);
				if (!value) {
					setForm({
						patient_id: "",
						patient_name: "",
						followup_date: todayISO(),
						reason: ""
					});
					setSelectedPatient(null);
				}
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-h-[90vh] overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
						t("add"),
						" ",
						t("followups")
					] }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-sm font-medium",
									children: t("patient")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPicker, {
									value: selectedPatient,
									onSelect: (patient) => {
										setSelectedPatient(patient);
										setForm({
											...form,
											patient_id: patient?.id ?? "",
											patient_name: patient?.full_name ?? ""
										});
									}
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-sm font-medium",
									children: t("due_date")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									dir: "ltr",
									value: form.followup_date,
									onChange: (e) => setForm({
										...form,
										followup_date: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-sm font-medium",
									children: t("reason")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: form.reason,
									onChange: (e) => setForm({
										...form,
										reason: e.target.value
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.patient_id || !form.followup_date || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				]
			})
		})
	] });
}
//#endregion
export { FollowupsPage as component };
