import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as rpc } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { c as Field, d as Input, n as Button, o as ErrorBox } from "./kit-asLB5pSR.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-BYYnhUtQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BcZup1x7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const { t, lang, toggle } = useLang();
	const { signIn, session, user } = useAuth();
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("signin");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [setupNeeded, setSetupNeeded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (window.location.hash.includes("type=recovery")) setMode("recover");
		rpc("setup_required").then((need) => setSetupNeeded(Boolean(need))).catch(() => setSetupNeeded(false));
	}, []);
	(0, import_react.useEffect)(() => {
		if (session && user && mode !== "recover") navigate({
			to: "/dashboard",
			replace: true
		});
	}, [
		session,
		user,
		mode,
		navigate
	]);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		try {
			if (mode === "signin") {
				await signIn(email.trim(), password);
				navigate({
					to: "/dashboard",
					replace: true
				});
			} else if (mode === "forgot") {
				const { error: e2 } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/auth` });
				if (e2) throw new Error(e2.message);
				toast.success(lang === "ar" ? "تم إرسال رابط الاستعادة" : "Reset link sent");
				setMode("signin");
			} else {
				const { error: e3 } = await supabase.auth.updateUser({ password });
				if (e3) throw new Error(e3.message);
				toast.success(t("saved"));
				navigate({
					to: "/dashboard",
					replace: true
				});
			}
		} catch (err) {
			setError(err instanceof Error ? err.message : String(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/40 to-background px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-col items-center gap-3 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/roshan-logo.png",
					alt: t("app_name"),
					className: "h-20 object-contain"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-bold text-foreground",
					children: t("app_name")
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: mode === "signin" ? t("sign_in") : mode === "forgot" ? t("reset_password") : t("new_password") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("signup_disabled") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "space-y-4",
					children: [
						mode !== "recover" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("email"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								dir: "ltr",
								required: true,
								value: email,
								onChange: (e) => setEmail(e.target.value),
								autoComplete: "username"
							})
						}) : null,
						mode !== "forgot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: mode === "recover" ? t("new_password") : t("password"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								dir: "ltr",
								required: true,
								minLength: 6,
								value: password,
								onChange: (e) => setPassword(e.target.value),
								autoComplete: mode === "recover" ? "new-password" : "current-password"
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "w-full",
							disabled: busy,
							children: busy ? t("loading") : mode === "signin" ? t("sign_in") : mode === "forgot" ? t("send_reset_link") : t("update_password")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center justify-between gap-2 text-sm",
					children: [mode === "signin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-primary hover:underline",
						onClick: () => setMode("forgot"),
						children: t("forgot_password")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-primary hover:underline",
						onClick: () => setMode("signin"),
						children: t("back")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-muted-foreground hover:underline",
						onClick: toggle,
						children: lang === "ar" ? "English" : "العربية"
					})]
				}),
				setupNeeded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mt-4 w-full",
					onClick: () => void navigate({ to: "/setup" }),
					children: t("first_run_setup")
				}) : null
			] })] })]
		})
	});
}
//#endregion
export { AuthPage as component };
