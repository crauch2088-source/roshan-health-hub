import { a as rpc } from "./db-Ckpr7291.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pharmacy-Co3jb7c8.js
/**
* Phase 3 — Pharmacy Inventory Modernization.
*
* Shared types + pure helpers for the batch/FEFO/expiry system. This repo
* doesn't use generated Supabase types anywhere (see lib/db.ts's `Row =
* Record<string, unknown>` + `s()/n()/rel()` accessor pattern) so these
* are hand-written to match that same convention, not a codegen dump.
*/
/**
* Classifies a batch by its expiry date against the clinic's configurable
* threshold (system_settings.pharmacy_expiry_threshold_days, default 90).
* A null expiry date is treated as healthy (nothing to warn about).
*/
function expiryStatus(expiryDate, thresholdDays) {
	if (!expiryDate) return "healthy";
	const today = /* @__PURE__ */ new Date();
	today.setHours(0, 0, 0, 0);
	const expiry = new Date(expiryDate);
	if (Number.isNaN(expiry.getTime())) return "healthy";
	const daysLeft = Math.floor((expiry.getTime() - today.getTime()) / 864e5);
	if (daysLeft < 0) return "expired";
	if (daysLeft <= thresholdDays) return "expiring_soon";
	return "healthy";
}
/** Tailwind classes for the expiry badge, matching the tone scale already used by StatusBadge. */
var EXPIRY_TONE = {
	healthy: "bg-success/15 text-success border-success/30",
	expiring_soon: "bg-warning/15 text-warning border-warning/30",
	expired: "bg-destructive/15 text-destructive border-destructive/30"
};
/**
* Dispenses every item on a pending prescription First-Expire-First-Out.
* Runs entirely inside one Postgres function (fn_dispense_prescription) so
* it's atomic under concurrent dispensing, and returns one row per batch
* (or legacy-stock) consumption for display.
*/
async function dispensePrescriptionFefo(prescriptionId) {
	return rpc("fn_dispense_prescription", { p_prescription_id: prescriptionId });
}
//#endregion
export { dispensePrescriptionFefo as n, expiryStatus as r, EXPIRY_TONE as t };
