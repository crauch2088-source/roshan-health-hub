import { a as TSS_SERVER_FUNCTION, i as createServerFn } from "./server-EqTNyADH.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as SUPABASE_URL } from "./supabase-B2ycSfIQ.mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/-users.server-3te-exms.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Privileged-role assignment rules, shared by every SERVER-side code path that
* writes `users.role_id` with the service-role client (which bypasses RLS).
*
* The database enforces the same rule independently (see
* db/roshan_security_privileged_role_guard.sql); this module is the
* application-layer half of that defence in depth.
*
* Everything here fails closed: unknown caller or unknown role => denied.
*/
var SUPER_ADMIN_ROLE_CODE = "super_admin";
/** The only privileged role today. Add codes here to protect more roles. */
function isPrivilegedRole(role) {
	if (!role) return true;
	return role.code === SUPER_ADMIN_ROLE_CODE;
}
/**
* May `caller` assign `target` to a user?
* - The target role must exist (null => false, even for a super admin).
* - Only a super admin may assign a privileged role.
*/
function canAssignRole(caller, target) {
	if (!caller || !target) return false;
	if (caller.isSuperAdmin === true) return true;
	return !isPrivilegedRole(target);
}
/**
* SERVER-ONLY Supabase client authenticated with the Supabase secret key (full access).
*
* ⚠️ Import this ONLY from `createServerFn` handlers (e.g. `*.server.ts`
* files). Never import it from a route `component`, a hook that runs in the
* browser, or any file reachable from client-rendered code — TanStack
* Start only strips server-function bodies out of the client bundle, not
* arbitrary modules, so a stray client-side import here would ship the
* service_role key to every visitor's browser.
*
* The service_role key bypasses every Row Level Security policy. Any code
* built on top of `getSupabaseAdmin()` is fully responsible for checking
* "is this caller allowed to do this?" itself, in the handler, before
* touching the database.
*/
var cached = null;
function getSupabaseAdmin() {
	if (cached) return cached;
	const serviceRoleKey = process.env["SUPABASE_SECRET_KEY"] ?? process.env["SUPABASE_SERVICE_ROLE_KEY"];
	if (!serviceRoleKey) throw new Error("SUPABASE_SECRET_KEY is not set on the server. Add it to your environment (.env locally, your host's project settings in production) — see .env.example. Do NOT prefix it with VITE_, or it will be bundled into the client and exposed publicly.");
	cached = createClient(SUPABASE_URL, serviceRoleKey, { auth: {
		persistSession: false,
		autoRefreshToken: false,
		detectSessionInUrl: false
	} });
	return cached;
}
var CreateStaffUserInput = objectType({
	accessToken: stringType().min(1),
	full_name: stringType().trim().min(1, "Full name is required"),
	email: stringType().trim().toLowerCase().email("Invalid email"),
	password: stringType().min(8, "Password must be at least 8 characters"),
	phone: stringType().trim().optional(),
	role_id: stringType().uuid("Invalid role")
});
function roleCode(roles) {
	return (Array.isArray(roles) ? roles[0] : roles)?.code ?? null;
}
var createStaffUser_createServerFn_handler = createServerRpc({
	id: "2e90f3cf3e8e7f72fb0495863df47321372aa4c10d525dafcae66416bb53c7d5",
	name: "createStaffUser",
	filename: "src/routes/_authenticated/-users.server.ts"
}, (opts) => createStaffUser.__executeServer(opts));
var createStaffUser = createServerFn({ method: "POST" }).validator(CreateStaffUserInput).handler(createStaffUser_createServerFn_handler, async ({ data }) => {
	const admin = getSupabaseAdmin();
	const { data: callerAuth, error: callerAuthError } = await admin.auth.getUser(data.accessToken);
	if (callerAuthError || !callerAuth.user) throw new Error("Your session has expired. Please sign in again.");
	const { data: callerRow, error: callerRowError } = await admin.from("users").select("id, active, role_id, roles(code)").eq("auth_user_id", callerAuth.user.id).maybeSingle();
	if (callerRowError || !callerRow || !callerRow.active) throw new Error("Your account is not permitted to create users.");
	const callerIsSuperAdmin = roleCode(callerRow.roles) === SUPER_ADMIN_ROLE_CODE;
	let allowed = callerIsSuperAdmin;
	if (!allowed && callerRow.role_id) {
		const { data: perm } = await admin.from("role_permissions").select("permissions!inner(code)").eq("role_id", callerRow.role_id).eq("permissions.code", "users.create").maybeSingle();
		allowed = Boolean(perm);
	}
	if (!allowed) throw new Error("Your account is not permitted to create users.");
	const { data: targetRole, error: targetRoleError } = await admin.from("roles").select("id, code").eq("id", data.role_id).maybeSingle();
	if (targetRoleError || !targetRole) throw new Error("The selected role is invalid.");
	if (!canAssignRole({ isSuperAdmin: callerIsSuperAdmin }, { code: targetRole.code ?? null })) throw new Error("Only a super admin can assign this role.");
	const { data: created, error: createError } = await admin.auth.admin.createUser({
		email: data.email,
		password: data.password,
		email_confirm: true,
		user_metadata: { full_name: data.full_name }
	});
	if (createError || !created.user) throw new Error(createError?.message ?? "Could not create the account.");
	const { error: profileError } = await admin.from("users").insert({
		full_name: data.full_name,
		email: data.email,
		phone: data.phone || null,
		role_id: data.role_id,
		auth_user_id: created.user.id,
		active: true
	});
	if (profileError) {
		await admin.auth.admin.deleteUser(created.user.id);
		throw new Error(profileError.message);
	}
	return { id: created.user.id };
});
//#endregion
export { createStaffUser_createServerFn_handler };
