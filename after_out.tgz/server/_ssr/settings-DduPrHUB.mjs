import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, l as useSave, o as s } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { D as Textarea, _ as PageHeader, b as PermissionGate, c as Field, d as Input, f as Loading, l as Forbidden, n as Button, o as ErrorBox } from "./kit-asLB5pSR.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DduPrHUB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEYS = [
	"center_name",
	"center_name_ar",
	"phone",
	"address",
	"currency",
	"tax_percent",
	"invoice_footer",
	"pharmacy_expiry_threshold_days"
];
function SettingsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "settings.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPageInner, {})
	});
}
function SettingsPageInner() {
	const { lang, t } = useLang();
	const { can } = useAuth();
	const [form, setForm] = (0, import_react.useState)({});
	const list = useRows(["system_settings"], () => supabase.from("system_settings").select("setting_key, setting_value"));
	(0, import_react.useEffect)(() => {
		const rows = list.data ?? [];
		if (!rows.length) return;
		const next = {};
		for (const r of rows) next[s(r, "setting_key")] = s(r, "setting_value");
		setForm((prev) => Object.keys(prev).length ? prev : next);
	}, [list.data]);
	const save = useSave(async () => {
		const payload = KEYS.map((k) => ({
			setting_key: k,
			setting_value: form[k] ?? "",
			is_public: true
		}));
		const { error } = await supabase.from("system_settings").upsert(payload, { onConflict: "setting_key" });
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["system_settings"]],
		successMessage: t("saved")
	});
	if (!can("settings.read")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Forbidden, { message: lang === "ar" ? "ليس لديك صلاحية للوصول إلى الإعدادات." : "You are not authorized to access settings." });
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const set = (k) => (e) => setForm({
		...form,
		[k]: e.target.value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: t("settings"),
				subtitle: t("system_configuration")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("center_info")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("center_name"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form["center_name"] ?? "",
							onChange: set("center_name")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `${t("center_name")} (AR)`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form["center_name_ar"] ?? "",
							onChange: set("center_name_ar")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("phone"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							dir: "ltr",
							value: form["phone"] ?? "",
							onChange: set("phone")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("address"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form["address"] ?? "",
							onChange: set("address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("currency"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							dir: "ltr",
							value: form["currency"] ?? "",
							onChange: set("currency")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("tax_percent"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							dir: "ltr",
							value: form["tax_percent"] ?? "0",
							onChange: set("tax_percent")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("invoice_footer"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							value: form["invoice_footer"] ?? "",
							onChange: set("invoice_footer")
						})
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: t("pharmacy")
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "grid gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("pharmacy_expiry_threshold"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							dir: "ltr",
							value: form["pharmacy_expiry_threshold_days"] ?? "90",
							onChange: set("pharmacy_expiry_threshold_days")
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full sm:w-auto",
					disabled: !can("settings.update") || save.isPending,
					onClick: () => save.mutate(void 0),
					children: save.isPending ? t("saving") : t("save")
				})
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
