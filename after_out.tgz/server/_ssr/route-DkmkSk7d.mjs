import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link, g as Outlet, p as useLocation, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { $ as ChevronLeft, A as LoaderCircle, B as FlaskConical, C as Plus, G as ClipboardList, I as History, K as Circle, L as HeartPulse, M as LayoutDashboard, N as Languages, P as Landmark, Q as ChevronRight, R as Handshake, T as Pill, U as Clock, V as FileText, X as ChevronsLeft, Y as ChevronsRight, _ as ScrollText, a as UserRound, d as Star, f as Sparkles, g as Search, h as Settings, i as Users, it as Banknote, j as ListOrdered, k as LogOut, lt as Activity, m as ShieldCheck, n as Warehouse, nt as ChartColumn, r as Wallet, rt as CalendarDays, t as X, tt as Check, u as Stethoscope, x as Receipt, z as Grid2x2 } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { A as cn, f as Loading, n as Button } from "./kit-asLB5pSR.mjs";
import { a as DialogTitle$1, n as DialogContent$1, t as Dialog$1 } from "./dialog-WDSquJSC.mjs";
import { a as DropdownMenuItemIndicator, c as DropdownMenuRadioItem$1, d as DropdownMenuSubTrigger$1, f as DropdownMenuTrigger$1, i as DropdownMenuItem$1, l as DropdownMenuSeparator$1, n as DropdownMenuCheckboxItem$1, o as DropdownMenuLabel$1, r as DropdownMenuContent$1, s as DropdownMenuPortal, t as DropdownMenu$1, u as DropdownMenuSubContent$1 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { a as CommandItem, n as CommandEmpty, o as CommandList, r as CommandGroup, s as CommandSeparator, t as Command$1 } from "./command-mgTY8Z-h.mjs";
import { a as useDebounced, n as patientPickerQuery, r as sanitizeTerm, t as patientEmbeddedFilter } from "./search-CZ_9AvM8.mjs";
import { a as ScrollAreaViewport, i as ScrollAreaThumb, n as ScrollAreaCorner, r as ScrollAreaScrollbar, t as ScrollArea$1 } from "../_libs/radix-ui__react-scroll-area.mjs";
import { a as TooltipTrigger$1, i as TooltipProvider$1, n as TooltipContent$1, r as TooltipPortal, t as Tooltip$1 } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-DkmkSk7d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DropdownMenu = DropdownMenu$1;
var DropdownMenuTrigger = DropdownMenuTrigger$1;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuSubTrigger$1, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = DropdownMenuSubTrigger$1.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSubContent$1, {
	ref,
	className: cn("z-[10050] pointer-events-auto min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = DropdownMenuSubContent$1.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent$1, {
	ref,
	sideOffset,
	className: cn("z-[10050] pointer-events-auto max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = DropdownMenuContent$1.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = DropdownMenuItem$1.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuCheckboxItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = DropdownMenuCheckboxItem$1.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = DropdownMenuRadioItem$1.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = DropdownMenuLabel$1.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = DropdownMenuSeparator$1.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
/** Phone/tablet account control. On desktop the rail footer carries identity and sign-out. */
function AccountMenu({ onSignOut }) {
	const { user } = useAuth();
	const { t, lang } = useLang();
	const initial = (user?.full_name ?? "").trim().charAt(0).toUpperCase() || "•";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, {
		dir: lang === "ar" ? "rtl" : "ltr",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": t("account"),
				className: "flex size-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary outline-none transition-colors hover:bg-primary/15 focus-visible:ring-2 focus-visible:ring-ring lg:hidden",
				children: initial
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
			align: "end",
			className: "w-56",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuLabel, {
					className: "space-y-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold",
						children: user?.full_name ?? "—"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs font-normal text-muted-foreground",
						children: user?.role_name ?? ""
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onSelect: onSignOut,
					className: "min-h-10 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
							className: "size-4",
							"aria-hidden": true
						}),
						" ",
						t("sign_out")
					]
				})
			]
		})]
	});
}
var HOME_ITEM = {
	to: "/dashboard",
	key: "dashboard",
	perm: "dashboard.read",
	icon: "LayoutDashboard",
	favoritable: false
};
var NAV_GROUPS = [
	{
		group: "clinical",
		items: [
			{
				to: "/patients",
				key: "patients",
				perm: "patients.read",
				icon: "UserRound"
			},
			{
				to: "/visits",
				key: "visits",
				perm: "visits.read",
				icon: "ClipboardList"
			},
			{
				to: "/queue",
				key: "queue",
				perm: "queue.read",
				icon: "ListOrdered"
			},
			{
				to: "/clinic",
				key: "clinic",
				perm: "visits.read",
				icon: "Stethoscope"
			},
			{
				to: "/appointments",
				key: "appointments",
				perm: "appointments.read",
				icon: "CalendarDays"
			},
			{
				to: "/followups",
				key: "followups",
				perm: "followups.read",
				icon: "HeartPulse"
			},
			{
				to: "/certificates",
				key: "certificates",
				perm: "certificates.read",
				icon: "FileText"
			}
		]
	},
	{
		group: "pharmacy",
		items: [{
			to: "/pharmacy",
			key: "pharmacy",
			perm: "pharmacy.read",
			icon: "Pill"
		}, {
			to: "/inventory",
			key: "inventory",
			perm: "pharmacy.read",
			icon: "Warehouse"
		}]
	},
	{
		group: "laboratory",
		items: [{
			to: "/lab",
			key: "laboratory",
			perm: "lab.read",
			icon: "FlaskConical"
		}, {
			to: "/lab-catalog",
			key: "lab_catalog",
			perm: "lab_admin.read",
			icon: "ScrollText"
		}]
	},
	{
		group: "finance",
		items: [
			{
				to: "/billing",
				key: "billing",
				perm: "billing.read",
				icon: "Receipt"
			},
			{
				to: "/finance",
				key: "finance_hub",
				perm: "cashbox.read",
				icon: "Wallet"
			},
			{
				to: "/accounting",
				key: "accounting",
				perm: "accounting.read",
				icon: "Landmark"
			},
			{
				to: "/expenses",
				key: "expenses",
				perm: "accounting.read",
				icon: "Banknote"
			},
			{
				to: "/partners",
				key: "partners",
				perm: "partners.read",
				icon: "Handshake"
			},
			{
				to: "/reports",
				key: "reports",
				perm: "reports.read",
				icon: "BarChart3"
			},
			{
				to: "/analytics",
				key: "analytics",
				perm: "reports.read",
				icon: "Activity"
			},
			{
				to: "/insurance",
				key: "insurance",
				perm: "insurance.read",
				icon: "ShieldCheck"
			}
		]
	},
	{
		group: "administration",
		items: [
			{
				to: "/users",
				key: "users",
				perm: "users.read",
				icon: "Users"
			},
			{
				to: "/audit",
				key: "audit_log",
				perm: "audit.read",
				icon: "ScrollText"
			},
			{
				to: "/settings",
				key: "settings",
				perm: "settings.read",
				icon: "Settings"
			}
		]
	}
];
function flatNavItems() {
	return NAV_GROUPS.flatMap((g) => g.items);
}
/**
* The one active-route matcher shared by the desktop rail, the mobile bottom
* bar, the More sheet, the breadcrumbs and the command palette. Pure and
* dependency-free so it can be unit tested with `node --test`.
*/
/** Path only: no query string or hash, and no trailing slash (except "/"). */
function normalizePath(path) {
	const clean = (path.split(/[?#]/)[0] ?? "").replace(/\/+$/, "");
	return clean === "" ? "/" : clean;
}
/**
* True for the exact route and for nested/detail routes (/patients/123), but
* never for a sibling that merely shares a prefix (/lab-catalog is not /lab).
*/
function isNavItemActive(pathname, to) {
	const current = normalizePath(pathname);
	const target = normalizePath(to);
	return current === target || current.startsWith(`${target}/`);
}
/** The most specific matching item (longest path wins), or undefined. */
function matchNavItem(pathname, items) {
	let best;
	for (const item of items) {
		if (!isNavItemActive(pathname, item.to)) continue;
		if (!best || normalizePath(item.to).length > normalizePath(best.to).length) best = item;
	}
	return best;
}
/** The rail sits at the inline-start edge: right in Arabic (RTL), left in English (LTR). */
function railTooltipSide(lang) {
	return lang === "ar" ? "left" : "right";
}
/** One equal column per visible primary destination, plus the More button. */
function bottomBarColumns(primaryCount) {
	return `repeat(${Math.max(0, Math.floor(primaryCount)) + 1}, minmax(0, 1fr))`;
}
/**
* The mobile bottom bar has room for four destinations plus More. Pick the first
* `max` entries of `priority` the user may open, so a pharmacist or lab assistant
* (who cannot open Patients/Visits) still gets their own module on the bar instead
* of a bar that is mostly empty. Permissions are only *read* here: whatever is not
* picked stays reachable through More, and routes are still gated by PermissionGate.
*/
function pickPrimaryRoutes(priority, isAllowed, max = 4) {
	const picked = [];
	for (const to of priority) {
		if (picked.length >= max) break;
		if (!picked.includes(to) && isAllowed(to)) picked.push(to);
	}
	return picked;
}
/**
* Structure of the header breadcrumb: Home › Module › Section › (Detail).
* Module is a label only (modules have no route of their own). The detail step
* appears on nested routes such as /patients/<id>.
*/
function navTrail(opts) {
	const steps = [];
	if (opts.hasHome) steps.push({
		kind: "home",
		to: "/dashboard"
	});
	if (opts.moduleKey) steps.push({ kind: "module" });
	steps.push({
		kind: "section",
		to: opts.sectionTo
	});
	if (!opts.onSection) steps.push({ kind: "detail" });
	return steps;
}
/**
* Home › Module › Section › Details. The module is a plain label (modules have no
* route); the detail step appears on nested routes such as /patients/<id>. Below
* `sm` only the section (and detail) remain, so the trail never wraps or clips.
*
* Sections the user cannot read are never linked here: the trail must not offer a
* jump that the destination PermissionGate will refuse.
*/
function BreadcrumbNav() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const location = useLocation();
	const Chevron = lang === "ar" ? ChevronLeft : ChevronRight;
	if (location.pathname === HOME_ITEM.to) return null;
	const items = flatNavItems().filter((item) => can(item.perm));
	const current = matchNavItem(location.pathname, items);
	if (!current) return null;
	const onSection = normalizePath(location.pathname) === normalizePath(current.to);
	const moduleKey = NAV_GROUPS.find((g) => g.items.some((i) => i.to === current.to))?.group;
	const steps = navTrail({
		hasHome: can(HOME_ITEM.perm),
		moduleKey,
		sectionTo: current.to,
		onSection
	});
	const last = steps.length - 1;
	const linkCls = "rounded-sm outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "no-print min-w-0 text-sm text-muted-foreground",
		"aria-label": t("breadcrumb"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex min-w-0 items-center gap-1.5",
			children: steps.map((step, i) => {
				const isLast = i === last;
				const hideOnPhone = step.kind === "home" || step.kind === "module";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: `min-w-0 items-center gap-1.5 ${hideOnPhone ? "hidden sm:flex" : "flex"} ${step.kind === "module" ? "hidden md:flex" : ""}`,
					children: [step.kind === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: HOME_ITEM.to,
						className: linkCls,
						children: t(HOME_ITEM.key)
					}) : step.kind === "module" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(moduleKey ?? "") }) : step.kind === "section" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: current.to,
						"aria-current": isLast ? "page" : void 0,
						className: `block truncate ${linkCls} ${isLast ? "font-semibold text-foreground" : ""}`,
						children: t(current.key)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-current": "page",
						className: "truncate font-semibold text-foreground",
						children: t("details")
					}), !isLast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, {
						className: `size-3.5 shrink-0 text-muted-foreground/60 ${step.kind === "home" ? "hidden sm:block" : ""} ${step.kind === "module" ? "hidden md:block" : ""}`,
						"aria-hidden": true
					}) : null]
				}) }, step.kind);
			})
		})
	});
}
var FULL_SCOPE = {
	patients: true,
	visits: true,
	lab: true,
	medicines: true
};
/**
* Thrown when a category query comes back with a database error. It deliberately carries
* only the category name: never the database message, SQL, hints or identifiers.
*/
var SearchCategoryError = class extends Error {
	category;
	constructor(category) {
		super(`search category failed: ${category}`);
		this.name = "SearchCategoryError";
		this.category = category;
	}
};
/**
* Supabase resolves `{ data, error }` instead of rejecting, so `.catch()` alone never sees
* a database error. Every category query must pass its response through here.
*/
function unwrapRows(response, category) {
	if (response.error) throw new SearchCategoryError(category);
	return Array.isArray(response.data) ? response.data : [];
}
var CATEGORY_SCOPE = {
	patient: "patients",
	visit: "visits",
	lab: "lab",
	medicine: "medicines"
};
/**
* Search history lives in this browser's storage and may have been written by a different
* signed-in user. Only entries from categories the current user may search are shown.
*/
function filterByScope(items, scope) {
	return items.filter((item) => scope[CATEGORY_SCOPE[item.category]]);
}
var EMPTY_RESULTS = {
	patients: [],
	visits: [],
	lab: [],
	medicines: []
};
var SCOPE_KEYS = [
	"patients",
	"visits",
	"lab",
	"medicines"
];
function createSearchAll(queries, options = {}) {
	const ttlMs = options.ttlMs ?? 3e4;
	const now = options.now ?? Date.now;
	const cache = /* @__PURE__ */ new Map();
	return async function searchAll(rawTerm, scope = FULL_SCOPE) {
		const term = rawTerm.trim();
		if (term.length < 2) return EMPTY_RESULTS;
		const cacheKey = `${term}|${SCOPE_KEYS.map((k) => Number(scope[k])).join("")}`;
		const hit = cache.get(cacheKey);
		if (hit) {
			if (now() - hit.at <= ttlMs) return hit.results;
			cache.delete(cacheKey);
		}
		let failed = false;
		const run = async (enabled, query) => {
			if (!enabled) return [];
			try {
				return await query(term);
			} catch {
				failed = true;
				return [];
			}
		};
		const [patients, visits, lab, medicines] = await Promise.all([
			run(scope.patients, queries.patients),
			run(scope.visits, queries.visits),
			run(scope.lab, queries.lab),
			run(scope.medicines, queries.medicines)
		]);
		const results = {
			patients,
			visits,
			lab,
			medicines,
			failed
		};
		if (!failed) cache.set(cacheKey, {
			at: now(),
			results
		});
		return results;
	};
}
var RECENT_BASE = "roshan:search:recent-terms";
var HISTORY_BASE = "roshan:search:history";
var MAX_RECENT_TERMS = 8;
var MAX_HISTORY = 10;
function read(storage, key) {
	try {
		const raw = storage.getItem(key);
		const parsed = raw ? JSON.parse(raw) : [];
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function write(storage, key, value) {
	try {
		storage.setItem(key, JSON.stringify(value));
	} catch {}
}
/**
* Before per-user keys existed, one shared (unscoped) list was kept per browser. Remove it so
* names typed or opened by an earlier user are not left behind in storage.
*/
function purgeLegacySearchMemory(storage) {
	try {
		storage.removeItem(RECENT_BASE);
		storage.removeItem(HISTORY_BASE);
	} catch {}
}
/**
* With no signed-in owner (or no storage) every read is empty and every write is a no-op, so
* nothing is ever stored under a shared key.
*/
function createSearchMemory(storage, ownerId) {
	const active = storage !== null && Boolean(ownerId);
	const recentKey = `${RECENT_BASE}:${ownerId ?? ""}`;
	const historyKey = `${HISTORY_BASE}:${ownerId ?? ""}`;
	if (storage && active) purgeLegacySearchMemory(storage);
	const getRecentTerms = () => storage && active ? read(storage, recentKey) : [];
	const getHistory = () => storage && active ? read(storage, historyKey) : [];
	return {
		getRecentTerms,
		pushRecentTerm(term) {
			const clean = term.trim();
			if (!storage || !active || !clean) return;
			const next = [clean, ...getRecentTerms().filter((t) => t.toLowerCase() !== clean.toLowerCase())].slice(0, MAX_RECENT_TERMS);
			write(storage, recentKey, next);
		},
		clearRecentTerms() {
			if (storage && active) write(storage, recentKey, []);
		},
		getHistory,
		pushHistoryItem(item) {
			if (!storage || !active) return;
			const next = [item, ...getHistory().filter((h) => h.key !== item.key)].slice(0, MAX_HISTORY);
			write(storage, historyKey, next);
		},
		clearHistory() {
			if (storage && active) write(storage, historyKey, []);
		}
	};
}
var PER_CATEGORY_LIMIT = 6;
async function searchPatients(term) {
	return unwrapRows(await patientPickerQuery(term, PER_CATEGORY_LIMIT), "patients").map((p) => ({
		key: `patient:${p["id"]}`,
		title: String(p["full_name"] ?? ""),
		subtitle: [p["mrn"], p["phone"]].filter(Boolean).join(" · "),
		to: `/patients/${p["id"]}`,
		category: "patient"
	}));
}
async function searchVisits(term) {
	const clean = sanitizeTerm(term);
	const byPatient = supabase.from("visits").select("id, visit_date, status, patients!visits_patient_id_fkey(full_name, mrn)").is("deleted_at", null).order("visit_date", { ascending: false }).limit(PER_CATEGORY_LIMIT);
	return unwrapRows(await (clean ? patientEmbeddedFilter(byPatient, clean) : byPatient), "visits").map((v) => {
		const patient = v["patients"] ?? {};
		return {
			key: `visit:${v["id"]}`,
			title: String(patient["full_name"] ?? ""),
			subtitle: `${String(patient["mrn"] ?? "")} · ${String(v["visit_date"] ?? "")}`,
			meta: String(v["status"] ?? ""),
			to: `/clinic/${v["id"]}`,
			category: "visit"
		};
	});
}
async function searchLab(term) {
	const clean = sanitizeTerm(term);
	if (!clean) return [];
	return unwrapRows(await supabase.from("lab_orders").select("id, status, created_at, patients!lab_orders_patient_id_fkey(full_name, mrn), lab_order_items(lab_tests(name))").is("deleted_at", null).or(`mrn.ilike.%${clean}%,full_name.ilike.%${clean}%`, { referencedTable: "patients" }).order("created_at", { ascending: false }).limit(PER_CATEGORY_LIMIT), "lab").map((o) => {
		const patient = o["patients"] ?? {};
		const testNames = (o["lab_order_items"] ?? []).map((i) => i.lab_tests?.name).filter(Boolean);
		return {
			key: `lab:${o["id"]}`,
			title: String(patient["full_name"] ?? ""),
			subtitle: testNames.length > 0 ? testNames.join(", ") : String(patient["mrn"] ?? ""),
			meta: String(o["status"] ?? ""),
			to: `/lab/${o["id"]}`,
			category: "lab"
		};
	});
}
async function searchMedicines(term) {
	const clean = sanitizeTerm(term);
	if (!clean) return [];
	return unwrapRows(await supabase.from("medicines").select("id, name, unit, stock_quantity, selling_price, barcode").is("deleted_at", null).or(`name.ilike.%${clean}%,barcode.ilike.%${clean}%`).order("name", { ascending: true }).limit(PER_CATEGORY_LIMIT), "medicines").map((m) => ({
		key: `medicine:${m["id"]}`,
		title: String(m["name"] ?? ""),
		subtitle: m["unit"] ? String(m["unit"]) : void 0,
		meta: `${String(m["stock_quantity"] ?? 0)}`,
		to: `/inventory`,
		category: "medicine"
	}));
}
/**
* Runs every permitted category in parallel (see search-core.ts for the failure and
* caching rules). Categories outside `scope` are never queried.
*/
var searchAll = createSearchAll({
	patients: searchPatients,
	visits: searchVisits,
	lab: searchLab,
	medicines: searchMedicines
});
function browserStorage() {
	try {
		return typeof window === "undefined" ? null : window.localStorage;
	} catch {
		return null;
	}
}
function getSearchMemory(ownerId) {
	return createSearchMemory(browserStorage(), ownerId);
}
var EMPTY = {
	patients: [],
	visits: [],
	lab: [],
	medicines: []
};
/**
* Debounces the query, then fans it out to every permitted category via
* SearchService. `isSearching` is also true while the debounce is pending, so
* the dialog never flashes "no results" for a term that has not been run yet.
*/
function useGlobalSearch(query, scope = FULL_SCOPE) {
	const debounced = useDebounced(query, 300);
	const [results, setResults] = (0, import_react.useState)(EMPTY);
	const [isRunning, setIsRunning] = (0, import_react.useState)(false);
	const { patients, visits, lab, medicines } = scope;
	(0, import_react.useEffect)(() => {
		const term = debounced.trim();
		if (term.length < 2) {
			setResults(EMPTY);
			setIsRunning(false);
			return;
		}
		let cancelled = false;
		setIsRunning(true);
		searchAll(term, {
			patients,
			visits,
			lab,
			medicines
		}).then((next) => {
			if (!cancelled) setResults(next);
		}).catch(() => {
			if (!cancelled) setResults({
				...EMPTY,
				failed: true
			});
		}).finally(() => {
			if (!cancelled) setIsRunning(false);
		});
		return () => {
			cancelled = true;
		};
	}, [
		debounced,
		patients,
		visits,
		lab,
		medicines
	]);
	const pending = query.trim() !== debounced.trim() && query.trim().length >= 2;
	return {
		results,
		isSearching: isRunning || pending
	};
}
var FAVORITES_KEY = "roshan:nav:favorites";
var RECENTS_KEY = "roshan:nav:recents";
var MAX_RECENTS = 6;
var NavPreferencesContext = (0, import_react.createContext)(null);
function readList(key, fallback) {
	try {
		const raw = window.localStorage.getItem(key);
		return raw ? JSON.parse(raw) : fallback;
	} catch {
		return fallback;
	}
}
function writeList(key, value) {
	try {
		window.localStorage.setItem(key, JSON.stringify(value));
	} catch {}
}
/**
* Tracks pinned pages and recently-visited pages, both purely client-side
* (per browser/device, not synced through Supabase — nothing clinical is
* stored here). Mounted once in app-shell so the rail, mobile nav, and the
* command palette all read the same state.
*/
function NavPreferencesProvider({ children }) {
	const location = useLocation();
	const [favorites, setFavorites] = (0, import_react.useState)(() => readList(FAVORITES_KEY, []));
	const [recents, setRecents] = (0, import_react.useState)(() => readList(RECENTS_KEY, []));
	(0, import_react.useEffect)(() => {
		const to = location.pathname;
		setRecents((prev) => {
			const next = [{
				to,
				visitedAt: Date.now()
			}, ...prev.filter((r) => r.to !== to)].slice(0, MAX_RECENTS);
			writeList(RECENTS_KEY, next);
			return next;
		});
	}, [location.pathname]);
	const toggleFavorite = (0, import_react.useCallback)((to) => {
		setFavorites((prev) => {
			const next = prev.includes(to) ? prev.filter((f) => f !== to) : [...prev, to];
			writeList(FAVORITES_KEY, next);
			return next;
		});
	}, []);
	const isFavorite = (0, import_react.useCallback)((to) => favorites.includes(to), [favorites]);
	const value = (0, import_react.useMemo)(() => ({
		favorites,
		recents,
		toggleFavorite,
		isFavorite
	}), [
		favorites,
		recents,
		toggleFavorite,
		isFavorite
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavPreferencesContext.Provider, {
		value,
		children
	});
}
function useNavPreferences() {
	const ctx = (0, import_react.useContext)(NavPreferencesContext);
	if (!ctx) throw new Error("useNavPreferences must be used within NavPreferencesProvider");
	return ctx;
}
/**
* Maps the icon *names* stored in config/nav.ts (plain strings, so they're
* safe to serialize/log) to the actual lucide components. Add new icons
* here, not by importing lucide directly in nav.ts.
*/
var NAV_ICONS = {
	Activity,
	BarChart3: ChartColumn,
	Banknote,
	CalendarDays,
	ClipboardList,
	FileText,
	FlaskConical,
	Handshake,
	HeartPulse,
	Landmark,
	LayoutDashboard,
	ListOrdered,
	Pill,
	Receipt,
	ScrollText,
	Settings,
	ShieldCheck,
	Stethoscope,
	UserRound,
	Users,
	Warehouse,
	Wallet
};
function getNavIcon(name) {
	if (!name) return Activity;
	return NAV_ICONS[name] ?? Activity;
}
var FLAG_PREFIX = "roshan:quick-action:";
var QUICK_ACTIONS = [
	{
		key: "new_patient",
		labelKey: "new_patient",
		to: "/patients",
		icon: "UserRound"
	},
	{
		key: "new_visit",
		labelKey: "new_visit",
		to: "/visits",
		icon: "ClipboardList"
	},
	{
		key: "new_invoice",
		labelKey: "new_invoice",
		to: "/billing",
		icon: "Receipt"
	},
	{
		key: "new_lab_order",
		labelKey: "new_lab_order",
		to: "/lab",
		icon: "FlaskConical"
	}
];
/**
* The command palette navigates to a plain route (e.g. /patients) — it has
* no reference to that page's local dialog state. So it "arms" a one-shot
* flag in sessionStorage before navigating; the destination page checks
* (and immediately clears) that flag on mount and opens its own create
* dialog. This avoids a second, parallel "create patient" implementation
* living inside the palette itself.
*/
function armQuickAction(key) {
	try {
		window.sessionStorage.setItem(FLAG_PREFIX + key, "1");
	} catch {}
}
var CATEGORY_ICON = {
	patient: UserRound,
	visit: Stethoscope,
	lab: FlaskConical,
	medicine: Pill
};
/** Small star toggle reused by every pinnable row (pages + favorites). */
function PinToggle({ pinned, onToggle, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: (e) => {
			e.preventDefault();
			e.stopPropagation();
			onToggle();
		},
		"aria-label": label,
		className: "ms-auto flex size-8 shrink-0 items-center justify-center rounded-md opacity-60 transition-colors hover:bg-accent hover:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-3.5", pinned ? "fill-current text-amber-500" : "text-muted-foreground") })
	});
}
function GlobalSearchDialog({ open, onOpenChange }) {
	const { t, lang } = useLang();
	const { can, user } = useAuth();
	const navigate = useNavigate();
	const { favorites, recents, toggleFavorite } = useNavPreferences();
	const [query, setQuery] = (0, import_react.useState)("");
	const trimmed = query.trim();
	const hasQuery = trimmed.length >= 2;
	const scope = (0, import_react.useMemo)(() => ({
		patients: can("patients.read"),
		visits: can("visits.read"),
		lab: can("lab.read"),
		medicines: can("pharmacy.read")
	}), [can]);
	const { results, isSearching } = useGlobalSearch(query, scope);
	const memory = (0, import_react.useMemo)(() => getSearchMemory(user?.id), [user?.id]);
	const [recentTerms, setRecentTerms] = (0, import_react.useState)(() => memory.getRecentTerms());
	const [storedHistory, setHistory] = (0, import_react.useState)(() => memory.getHistory());
	(0, import_react.useEffect)(() => {
		setRecentTerms(memory.getRecentTerms());
		setHistory(memory.getHistory());
	}, [memory]);
	const history = (0, import_react.useMemo)(() => filterByScope(storedHistory, scope), [storedHistory, scope]);
	const pages = (0, import_react.useMemo)(() => [HOME_ITEM, ...flatNavItems().filter((i) => i.to !== HOME_ITEM.to)], []);
	const visiblePages = (0, import_react.useMemo)(() => {
		const allowed = pages.filter((item) => can(item.perm));
		if (!trimmed) return [];
		const q = trimmed.toLowerCase();
		return allowed.filter((item) => t(item.key).toLowerCase().includes(q) || item.key.includes(q));
	}, [
		pages,
		can,
		trimmed,
		t
	]);
	const favoritePages = (0, import_react.useMemo)(() => pages.filter((item) => can(item.perm) && favorites.includes(item.to)), [
		pages,
		can,
		favorites
	]);
	const availableActions = (0, import_react.useMemo)(() => QUICK_ACTIONS.filter((action) => {
		const destination = pages.find((item) => item.to === action.to);
		return destination ? can(destination.perm) : false;
	}), [pages, can]);
	function reset() {
		setQuery("");
	}
	function close() {
		onOpenChange(false);
		reset();
	}
	function goTo(to) {
		navigate({ to });
		close();
	}
	function selectResult(item) {
		memory.pushHistoryItem(item);
		if (trimmed) memory.pushRecentTerm(trimmed);
		setRecentTerms(memory.getRecentTerms());
		setHistory(memory.getHistory());
		goTo(item.to);
	}
	function selectQuickAction(actionKey, to) {
		armQuickAction(actionKey);
		goTo(to);
	}
	function rerunRecentTerm(term) {
		setQuery(term);
	}
	function pinLabel(item) {
		return favorites.includes(item.to) ? t("unpin") : t("pin");
	}
	const noResults = hasQuery && !isSearching && visiblePages.length === 0 && results.patients.length === 0 && results.visits.length === 0 && results.lab.length === 0 && results.medicines.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange: (next) => {
			onOpenChange(next);
			if (!next) reset();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
			className: "top-[8dvh] max-h-[84dvh] max-w-2xl translate-y-0 overflow-hidden p-0 sm:top-[12dvh]",
			dir: lang === "ar" ? "rtl" : "ltr",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
				className: "sr-only",
				children: t("search_everywhere")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, {
				shouldFilter: false,
				className: "flex h-full max-h-[76dvh] flex-col overflow-hidden rounded-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-5 shrink-0 text-muted-foreground",
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								autoFocus: true,
								type: "search",
								"aria-label": t("search_everywhere"),
								enterKeyHint: "search",
								autoComplete: "off",
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: t("search_placeholder"),
								className: "flex h-14 w-full bg-transparent text-base outline-none placeholder:text-muted-foreground"
							}),
							query.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: reset,
								className: "flex size-8 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground",
								"aria-label": t("clear"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, {
						className: "max-h-[calc(76dvh-7rem)] px-1 py-1",
						children: [!hasQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							favoritePages.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
								heading: t("favorites"),
								children: favoritePages.map((item) => {
									const Icon = getNavIcon(item.icon);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
										value: `fav-${item.to}`,
										onSelect: () => goTo(item.to),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(item.key) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinToggle, {
												pinned: true,
												onToggle: () => toggleFavorite(item.to),
												label: t("unpin")
											})
										]
									}, `fav:${item.to}`);
								})
							}),
							recents.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
								heading: t("recent_pages"),
								children: recents.map((r) => {
									const item = pages.find((p) => p.to === r.to);
									if (!item || !can(item.perm)) return null;
									getNavIcon(item.icon);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
										value: `recent-${item.to}`,
										onSelect: () => goTo(item.to),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(item.key) })]
									}, `recent:${item.to}`);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
								heading: t("quick_actions"),
								children: availableActions.map((action) => {
									const Icon = getNavIcon(action.icon);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
										value: `qa-${action.key}`,
										onSelect: () => selectQuickAction(action.key, action.to),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(action.labelKey) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "ms-auto size-3.5 text-muted-foreground" })
										]
									}, action.key);
								})
							}),
							history.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandSeparator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandGroup, {
								heading: t("search_history"),
								children: [history.map((item) => {
									const Icon = CATEGORY_ICON[item.category];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
										value: `hist-${item.key}`,
										onSelect: () => selectResult(item),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4 text-muted-foreground" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex min-w-0 flex-col",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: item.title
												}), item.subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate text-xs text-muted-foreground",
													children: item.subtitle
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "ms-auto size-3.5 shrink-0 text-muted-foreground" })
										]
									}, `hist:${item.key}`);
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
									value: "clear-history",
									onSelect: () => {
										memory.clearHistory();
										setHistory([]);
									},
									className: "text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("clear") })]
								})]
							})] }),
							recentTerms.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandSeparator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandGroup, {
								heading: t("recent_searches"),
								children: [recentTerms.map((term) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
									value: `term-${term}`,
									onSelect: () => rerunRecentTerm(term),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: term })]
								}, `term:${term}`)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
									value: "clear-recent-terms",
									onSelect: () => {
										memory.clearRecentTerms();
										setRecentTerms([]);
									},
									className: "text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("clear") })]
								})]
							})] })
						] }), hasQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							visiblePages.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
								heading: t("pages"),
								children: visiblePages.map((item) => {
									const Icon = getNavIcon(item.icon);
									const favoritable = item.favoritable !== false;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
										value: `page-${item.to}`,
										onSelect: () => goTo(item.to),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(item.key) }),
											favoritable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinToggle, {
												pinned: favorites.includes(item.to),
												onToggle: () => toggleFavorite(item.to),
												label: pinLabel(item)
											})
										]
									}, `page:${item.to}`);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultGroup, {
								heading: t("patient_result"),
								icon: CATEGORY_ICON.patient,
								items: results.patients,
								onSelect: selectResult
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultGroup, {
								heading: t("visit_result"),
								icon: CATEGORY_ICON.visit,
								items: results.visits,
								onSelect: selectResult
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultGroup, {
								heading: t("lab_result"),
								icon: CATEGORY_ICON.lab,
								items: results.lab,
								onSelect: selectResult
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultGroup, {
								heading: t("medicine_result"),
								icon: CATEGORY_ICON.medicine,
								items: results.medicines,
								onSelect: selectResult
							}),
							isSearching && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "status",
								className: "flex items-center gap-2 px-3 py-4 text-sm text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "size-4 animate-spin motion-reduce:animate-none",
									"aria-hidden": true
								}), t("searching")]
							}),
							results.failed && !isSearching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								role: "alert",
								className: "px-3 py-3 text-sm text-destructive",
								children: t("search_failed")
							}),
							noResults && !results.failed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: t("no_results") })
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center justify-between border-t px-4 py-2 text-[11px] text-muted-foreground sm:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("type_to_search") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
									className: "rounded border bg-muted px-1.5 py-0.5 font-mono",
									children: "↑↓"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
									className: "rounded border bg-muted px-1.5 py-0.5 font-mono",
									children: "Enter"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
									className: "rounded border bg-muted px-1.5 py-0.5 font-mono",
									children: "Esc"
								})
							]
						})]
					})
				]
			})]
		})
	});
}
function ResultGroup({ heading, icon: Icon, items, onSelect }) {
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
		heading,
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
			value: item.key,
			onSelect: () => onSelect(item),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: item.title
					}), item.subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-xs text-muted-foreground",
						children: item.subtitle
					})]
				}),
				item.meta && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("ms-auto text-xs text-muted-foreground"),
					children: item.meta
				})
			]
		}, item.key))
	});
}
var CommandPaletteContext = (0, import_react.createContext)(null);
/** Keyboard shortcut → route. Permission is resolved from the shared nav config. */
var SHORTCUT_ROUTES = {
	d: "/dashboard",
	p: "/patients",
	v: "/visits",
	a: "/appointments",
	b: "/billing",
	l: "/lab",
	h: "/pharmacy"
};
/**
* Mounted once near the root of the authenticated app. Listens for
* Ctrl+K / Cmd+K anywhere in the app and owns the single instance of
* <GlobalSearchDialog>. Also registers a few navigation shortcuts that
* mirror high-traffic destinations. Shortcuts fail closed: a user without
* the module's read permission simply does not move, instead of landing on
* an access-denied screen.
*/
function CommandPaletteProvider({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	const { can } = useAuth();
	(0, import_react.useEffect)(() => {
		function onKeyDown(e) {
			if (e.isComposing || e.repeat) return;
			const target = e.target;
			const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable);
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				setOpen((prev) => !prev);
				return;
			}
			if (typing) return;
			if (!(e.metaKey || e.ctrlKey) || !e.shiftKey) return;
			const path = SHORTCUT_ROUTES[e.key.toLowerCase()];
			if (!path) return;
			const perm = flatNavItems().find((item) => item.to === path)?.perm;
			if (perm && !can(perm)) return;
			e.preventDefault();
			navigate({ to: path });
		}
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, [navigate, can]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandPaletteContext.Provider, {
		value: {
			open,
			setOpen
		},
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlobalSearchDialog, {
			open,
			onOpenChange: setOpen
		})]
	});
}
function useCommandPalette() {
	const ctx = (0, import_react.useContext)(CommandPaletteContext);
	if (!ctx) throw new Error("useCommandPalette must be used within CommandPaletteProvider");
	return ctx;
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-foreground/45 backdrop-blur-[2px]", "data-[state=open]:pointer-events-auto", "data-[state=closed]:pointer-events-none", "data-[state=open]:animate-in", "data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0", "data-[state=open]:fade-in-0", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva([
	"fixed z-50 gap-4 overflow-y-auto overscroll-contain bg-background p-4 shadow-xl transition ease-in-out sm:p-6",
	"data-[state=open]:animate-in",
	"data-[state=closed]:animate-out",
	"data-[state=closed]:duration-300",
	"data-[state=open]:duration-500"
].join(" "), {
	variants: { side: {
		top: [
			"inset-x-0 top-0 border-b",
			"data-[state=closed]:slide-out-to-top",
			"data-[state=open]:slide-in-from-top"
		].join(" "),
		bottom: [
			"inset-x-0 bottom-0 max-h-[min(90dvh,90vh)] rounded-t-lg border-t",
			"data-[state=closed]:slide-out-to-bottom",
			"data-[state=open]:slide-in-from-bottom"
		].join(" "),
		left: [
			"inset-y-0 left-0 h-full w-3/4 border-r",
			"data-[state=closed]:slide-out-to-left",
			"data-[state=open]:slide-in-from-left",
			"sm:max-w-sm"
		].join(" "),
		right: [
			"inset-y-0 right-0 h-full w-3/4 border-l",
			"data-[state=closed]:slide-out-to-right",
			"data-[state=open]:slide-in-from-right",
			"sm:max-w-sm"
		].join(" ")
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute end-3 top-3 flex size-9 cursor-pointer items-center justify-center rounded-md opacity-70 transition-opacity hover:bg-accent hover:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 pe-8 text-start", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("sticky bottom-0 z-10 -mx-4 -mb-4 flex flex-col-reverse gap-2 border-t bg-background/95 px-4 py-3 backdrop-blur sm:-mx-6 sm:-mb-6 sm:flex-row sm:justify-end sm:px-6 [&>*]:w-full sm:[&>*]:w-auto", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var PRIMARY_PRIORITY = [
	"/dashboard",
	"/patients",
	"/visits",
	"/pharmacy",
	"/lab",
	"/queue",
	"/billing",
	"/appointments"
];
function MobileBottomNav() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const location = useLocation();
	const navigate = useNavigate();
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const [fabOpen, setFabOpen] = (0, import_react.useState)(false);
	const direction = lang === "ar" ? "rtl" : "ltr";
	const allItems = [HOME_ITEM, ...NAV_GROUPS.flatMap((g) => g.items)];
	const primaryRoutes = pickPrimaryRoutes(PRIMARY_PRIORITY, (to) => {
		const item = allItems.find((i) => i.to === to);
		return Boolean(item && can(item.perm));
	});
	const primary = primaryRoutes.flatMap((to) => allItems.filter((i) => i.to === to));
	const availableActions = QUICK_ACTIONS.filter((action) => {
		const destination = allItems.find((item) => item.to === action.to);
		return destination ? can(destination.perm) : false;
	});
	const moreActive = NAV_GROUPS.some((group) => group.items.some((item) => !primaryRoutes.includes(item.to) && can(item.perm) && isNavItemActive(location.pathname, item.to)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [availableActions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "no-print fixed inset-x-0 bottom-[calc(4.25rem+env(safe-area-inset-bottom))] z-30 flex justify-end px-4 lg:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
			open: fabOpen,
			onOpenChange: setFabOpen,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": t("quick_actions"),
					className: "flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md transition-transform focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 focus-visible:ring-offset-2 active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
				side: "bottom",
				className: "rounded-t-2xl",
				dir: direction,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
					className: "mb-2",
					children: t("quick_actions")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 pb-[max(1rem,env(safe-area-inset-bottom))]",
					children: availableActions.map((action) => {
						const Icon = getNavIcon(action.icon);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-h-14 items-center gap-2.5 rounded-lg border border-border/70 p-3 text-start text-sm font-medium transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 active:scale-[0.98]",
							onClick: () => {
								armQuickAction(action.key);
								setFabOpen(false);
								navigate({ to: action.to });
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-primary" }), t(action.labelKey)]
						}, action.key);
					})
				})]
			})]
		})
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "no-print fixed inset-x-0 bottom-0 z-30 grid min-h-16 items-center border-t border-border bg-card/95 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden",
		"aria-label": t("navigation"),
		style: { gridTemplateColumns: bottomBarColumns(primary.length) },
		children: [primary.map((item) => {
			const Icon = getNavIcon(item.icon);
			const active = isNavItemActive(location.pathname, item.to);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				"aria-current": active ? "page" : void 0,
				className: "relative flex min-h-14 min-w-0 flex-col items-center justify-center gap-0.5 rounded-md px-1 py-1.5 text-[11px] font-semibold outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						className: cn("absolute inset-x-4 top-0 h-[3px] rounded-b-full bg-primary transition-opacity", active ? "opacity-100" : "opacity-0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex h-7 w-10 items-center justify-center", active ? "text-primary" : "text-muted-foreground"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("max-w-full truncate", active ? "text-primary" : "text-muted-foreground"),
						children: t(item.key)
					})
				]
			}, item.to);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
			open: moreOpen,
			onOpenChange: setMoreOpen,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"data-active": moreActive ? "true" : void 0,
					className: cn("relative flex min-h-14 min-w-0 flex-col items-center justify-center gap-0.5 rounded-md px-1 py-1.5 text-[11px] font-semibold outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring", moreActive ? "text-primary" : "text-muted-foreground"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: cn("absolute inset-x-4 top-0 h-[3px] rounded-b-full bg-primary transition-opacity", moreActive ? "opacity-100" : "opacity-0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-7 w-10 items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid2x2, { className: "size-5" })
						}),
						t("more")
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
				side: "bottom",
				className: "max-h-[80dvh] overflow-y-auto rounded-t-2xl",
				dir: direction,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
					className: "sr-only",
					children: t("more")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-2",
					children: NAV_GROUPS.map((group) => {
						const items = group.items.filter((i) => can(i.perm));
						if (items.length === 0) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 px-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground rtl:text-xs rtl:normal-case rtl:tracking-normal",
							children: t(group.group)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-4 gap-2",
							children: items.map((item) => {
								const Icon = getNavIcon(item.icon);
								const active = isNavItemActive(location.pathname, item.to);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									onClick: () => setMoreOpen(false),
									"aria-current": active ? "page" : void 0,
									className: cn("flex min-h-20 flex-col items-center justify-center gap-1 rounded-lg border border-border/70 p-2.5 text-center text-[11px] font-medium transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 active:scale-[0.98]", active && "border-2 border-primary bg-primary/10 font-bold text-primary"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "line-clamp-2",
										children: t(item.key)
									})]
								}, item.to);
							})
						})] }, group.group);
					})
				})]
			})]
		})]
	})] });
}
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScrollArea$1, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaViewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaCorner, {})
	]
}));
ScrollArea.displayName = ScrollArea$1.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
var TooltipProvider = TooltipProvider$1;
var Tooltip = Tooltip$1;
var TooltipTrigger = TooltipTrigger$1;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent$1, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-tooltip-content-transform-origin)", className),
	...props
}) }));
TooltipContent.displayName = TooltipContent$1.displayName;
function RailLink({ item, collapsed, active, onNavigate, trailing, markCurrent = true }) {
	const { t, lang } = useLang();
	const Icon = getNavIcon(item.icon);
	const hasTrailing = Boolean(trailing) && !collapsed;
	const link = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: item.to,
		onClick: onNavigate,
		"aria-current": active && markCurrent ? "page" : void 0,
		"aria-label": collapsed ? t(item.key) : void 0,
		className: cn("group/link relative flex min-h-9 items-center gap-2.5 rounded-md px-2.5 py-2 text-sm font-medium outline-none transition-[background-color,color,transform] duration-150 active:translate-y-px", "focus-visible:ring-2 focus-visible:ring-sidebar-ring focus-visible:ring-offset-1 focus-visible:ring-offset-sidebar", collapsed && "justify-center px-2", hasTrailing && "pe-9", active ? "bg-sidebar-accent font-semibold text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				className: cn("absolute inset-y-2 -start-2.5 w-[3px] rounded-full bg-sidebar-primary transition-opacity duration-150", active ? "opacity-100" : "opacity-0")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-4 shrink-0 transition-colors", active ? "text-sidebar-primary" : "text-sidebar-foreground/70 group-hover/link:text-sidebar-accent-foreground") }),
			!collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: t(item.key)
			}) : null
		]
	});
	const body = collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, {
		delayDuration: 150,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
			asChild: true,
			children: link
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
			side: railTooltipSide(lang),
			sideOffset: 8,
			className: "font-medium",
			children: t(item.key)
		})]
	}) : link;
	if (!hasTrailing) return body;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [body, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute end-1 top-1/2 -translate-y-1/2",
			children: trailing
		})]
	});
}
function NavRail({ collapsed, onToggleCollapsed, onNavigate }) {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const location = useLocation();
	const { favorites, toggleFavorite } = useNavPreferences();
	const favoriteItems = NAV_GROUPS.flatMap((g) => g.items).filter((item) => can(item.perm) && favorites.includes(item.to));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 150,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
				className: "flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "space-y-5 p-2.5",
					"aria-label": t("main_navigation"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailLink, {
							item: HOME_ITEM,
							collapsed,
							active: isNavItemActive(location.pathname, HOME_ITEM.to),
							onNavigate
						}),
						favoriteItems.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("space-y-0.5", !collapsed && "rounded-lg border border-sidebar-border bg-sidebar-accent/40 p-1.5"),
							children: [!collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-sidebar-foreground/60 rtl:text-[11px] rtl:normal-case rtl:tracking-normal",
								children: t("favorites")
							}) : null, favoriteItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailLink, {
								item,
								collapsed,
								active: isNavItemActive(location.pathname, item.to),
								onNavigate,
								markCurrent: false
							}, `fav-${item.to}`))]
						}) : null,
						NAV_GROUPS.map((group) => {
							const items = group.items.filter((item) => can(item.perm));
							if (items.length === 0) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-0.5",
								children: [!collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-2.5 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-sidebar-foreground/60 rtl:text-[11px] rtl:normal-case rtl:tracking-normal",
									children: t(group.group)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto my-1 h-px w-6 bg-sidebar-border/80",
									"aria-hidden": true
								}), items.map((item) => {
									const pinned = favorites.includes(item.to);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "group relative",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailLink, {
											item,
											collapsed,
											active: isNavItemActive(location.pathname, item.to),
											onNavigate,
											trailing: item.favoritable !== false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: (e) => {
													e.preventDefault();
													e.stopPropagation();
													toggleFavorite(item.to);
												},
												className: cn("flex size-8 shrink-0 items-center justify-center rounded-md transition-[opacity,background-color] hover:bg-sidebar-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring", pinned ? "opacity-100 text-amber-500" : "opacity-0 text-sidebar-foreground/50 group-hover:opacity-70 group-focus-within:opacity-70 hover:!opacity-100 focus-visible:!opacity-100 [@media(hover:none)]:opacity-70"),
												"aria-label": pinned ? t("unpin") : t("pin"),
												"aria-pressed": pinned,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-3.5", pinned && "fill-current") })
											}) : null
										})
									}, item.to);
								})]
							}, group.group);
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden border-t border-sidebar-border p-2 lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					className: "w-full justify-center text-sidebar-foreground/70 hover:text-sidebar-foreground",
					onClick: onToggleCollapsed,
					"aria-label": collapsed ? t("expand_sidebar") : t("collapse_sidebar"),
					children: collapsed ? lang === "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsLeft, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsRight, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						lang === "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsRight, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsLeft, { className: "size-4" }),
						" ",
						t("collapse_sidebar")
					] })
				})
			})]
		})
	});
}
var RAIL_COLLAPSED_KEY = "roshan:nav:rail-collapsed";
function Brand({ collapsed }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex h-14 items-center gap-2.5 border-b border-sidebar-border px-3.5", collapsed && "justify-center px-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/roshan-logo.png",
			alt: t("app_name"),
			className: "size-8 shrink-0 object-contain"
		}), !collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 leading-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-display text-base font-extrabold text-sidebar-foreground",
				children: t("app_short")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-[11px] text-sidebar-foreground/60",
				children: t("app_name")
			})]
		}) : null]
	});
}
function SearchTrigger() {
	const { t } = useLang();
	const { setOpen } = useCommandPalette();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size: "sm",
		className: "hidden min-w-40 justify-between gap-2 border-border/70 bg-background/70 text-muted-foreground shadow-xs sm:flex",
		onClick: () => setOpen(true),
		"aria-label": t("search_everywhere"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "size-4",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden md:inline",
				children: t("search_everywhere")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
				className: "ms-auto hidden rounded border border-border/70 bg-muted/70 px-1.5 py-0.5 font-mono text-[10px] md:inline",
				children: "Ctrl K"
			})
		]
	});
}
function MobileSearchButton() {
	const { t } = useLang();
	const { setOpen } = useCommandPalette();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size: "sm",
		className: "size-9 shrink-0 p-0 sm:hidden",
		onClick: () => setOpen(true),
		"aria-label": t("search_everywhere"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
	});
}
function Shell({ children }) {
	const { toggle, lang, t } = useLang();
	const { user, signOut } = useAuth();
	const navigate = useNavigate();
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const direction = lang === "ar" ? "rtl" : "ltr";
	(0, import_react.useEffect)(() => {
		try {
			setCollapsed(window.localStorage.getItem(RAIL_COLLAPSED_KEY) === "1");
		} catch {}
	}, []);
	function toggleCollapsed() {
		setCollapsed((prev) => {
			const next = !prev;
			try {
				window.localStorage.setItem(RAIL_COLLAPSED_KEY, next ? "1" : "0");
			} catch {}
			return next;
		});
	}
	async function handleSignOut() {
		await signOut();
		navigate({
			to: "/auth",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen bg-background",
		dir: direction,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main-content",
				className: "sr-only focus:not-sr-only focus:fixed focus:start-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-sm focus:font-medium focus:text-primary-foreground",
				children: t("skip_to_content")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cnRail(collapsed),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { collapsed }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-h-0 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavRail, {
							collapsed,
							onToggleCollapsed: toggleCollapsed
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: collapsed ? "border-t border-sidebar-border p-2" : "border-t border-sidebar-border p-3",
						children: [!collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex min-w-0 items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-8 shrink-0 items-center justify-center rounded-full bg-sidebar-accent text-sidebar-accent-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium text-sidebar-foreground",
									children: user?.full_name ?? "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-sidebar-foreground/60",
									children: user?.role_name ?? ""
								})]
							})]
						}) }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							className: collapsed ? "mt-0 w-full justify-center px-0" : "mt-2 w-full",
							onClick: handleSignOut,
							"aria-label": t("sign_out"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }),
								" ",
								!collapsed ? t("sign_out") : null
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col pb-[calc(7.5rem+env(safe-area-inset-bottom))] lg:pb-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "no-print sticky top-0 z-20 flex h-14 items-center gap-2 border-b border-border bg-background/95 px-3 backdrop-blur sm:gap-3 sm:px-5 lg:px-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/roshan-logo.png",
							alt: "",
							className: "size-7 shrink-0 object-contain lg:hidden"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreadcrumbNav, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-w-0 flex-1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchTrigger, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchButton, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: toggle,
							"aria-label": lang === "ar" ? "Switch to English" : "التبديل إلى العربية",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: lang === "ar" ? "English" : "العربية"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, { onSignOut: handleSignOut })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					id: "main-content",
					tabIndex: -1,
					className: "mx-auto w-full min-w-0 max-w-[1600px] flex-1 p-3 outline-none sm:p-5 lg:p-7",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileBottomNav, {})
		]
	});
}
function cnRail(collapsed) {
	return cn("no-print sticky top-0 hidden h-dvh shrink-0 flex-col border-e border-sidebar-border bg-sidebar lg:flex transition-[width] duration-200 ease-out", collapsed ? "w-[4.25rem]" : "w-60");
}
function AppShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavPreferencesProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandPaletteProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children }) }) });
}
function ProtectedLayout() {
	const { loading } = useAuth();
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { ProtectedLayout as component };
