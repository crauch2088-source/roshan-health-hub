import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { i as useLang } from "./router-BiMGT4Sf.mjs";
import { T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, d as Input, f as Loading, o as ErrorBox, s as ExportButtons } from "./kit-asLB5pSR.mjs";
import { n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, c as todayISO, s as money } from "./medical-CD1sc5il.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-Cz_DZk-6.mjs";
import { r as expiryStatus } from "./pharmacy-Co3jb7c8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-BGM8ysOV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReportsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "reports.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportsPageInner, {})
	});
}
function ReportsPageInner() {
	const { t, lang } = useLang();
	const { currency } = useSettings();
	const [from, setFrom] = (0, import_react.useState)(`${todayISO().slice(0, 7)}-01`);
	const [to, setTo] = (0, import_react.useState)(todayISO());
	const visits = useRows([
		"rep-visits",
		from,
		to
	], () => supabase.from("visits").select("id, visit_date, status, consultation_fee, departments(name, name_ar), users(full_name)").gte("visit_date", from).lte("visit_date", to).is("deleted_at", null));
	const labs = useRows([
		"rep-labs",
		from,
		to
	], () => supabase.from("lab_order_items").select("id, price, lab_tests(name, name_ar), lab_orders!inner(created_at)").gte("lab_orders.created_at", from).lte("lab_orders.created_at", `${to}T23:59:59`));
	const diagnoses = useRows([
		"rep-dx",
		from,
		to
	], () => supabase.from("medical_records").select("id, diagnosis, created_at").gte("created_at", from).lte("created_at", `${to}T23:59:59`).is("deleted_at", null));
	const visitRows = visits.data ?? [];
	const labRows = labs.data ?? [];
	const dxRows = diagnoses.data ?? [];
	const byDepartment = {};
	for (const v of visitRows) {
		const dep = rel(v, "departments");
		const name = (lang === "ar" ? s(dep, "name_ar") || s(dep, "name") : s(dep, "name")) || t("none");
		byDepartment[name] = (byDepartment[name] ?? 0) + 1;
	}
	const byDoctor = {};
	for (const v of visitRows) {
		const name = s(rel(v, "users"), "full_name") || t("none");
		byDoctor[name] = (byDoctor[name] ?? 0) + 1;
	}
	const byTest = {};
	for (const l of labRows) {
		const test = rel(l, "lab_tests");
		const name = (lang === "ar" ? s(test, "name_ar") || s(test, "name") : s(test, "name")) || "—";
		byTest[name] = (byTest[name] ?? 0) + 1;
	}
	const byDiagnosis = {};
	for (const d of dxRows) {
		const key = s(d, "diagnosis").trim();
		if (!key) continue;
		byDiagnosis[key] = (byDiagnosis[key] ?? 0) + 1;
	}
	const consultRevenue = visitRows.reduce((sum, v) => sum + n(v, "consultation_fee"), 0);
	const labRevenue = labRows.reduce((sum, l) => sum + n(l, "price"), 0);
	if (visits.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const rank = (map) => Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 20);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("reports"),
			subtitle: `${formatDate(from)} — ${formatDate(to)}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: from,
					onChange: (e) => setFrom(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: to,
					onChange: (e) => setTo(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows: visitRows,
					filename: `roshan-visits-${from}-${to}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: visits.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("visits"),
					value: String(visitRows.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("laboratory"),
					value: String(labRows.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("consultation_fee"),
					value: money(consultRevenue, currency)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("lab_revenue"),
					value: money(labRevenue, currency)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "dept",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
				className: "mb-4 flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "dept",
						children: t("department")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "doctor",
						children: t("doctor")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "tests",
						children: t("test")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "dx",
						children: t("diagnosis")
					})
				]
			}), [
				["dept", byDepartment],
				["doctor", byDoctor],
				["tests", byTest],
				["dx", byDiagnosis]
			].map(([key, map]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: key,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "p-0",
					children: Object.keys(map).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("count") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rank(map).map(([name, count]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: count
						})] }, name)) })]
					})
				}) })
			}, key))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PharmacyReports, {})
	] });
}
function PharmacyReports() {
	const { t } = useLang();
	const { currency, settings } = useSettings();
	const thresholdDays = Number(settings["pharmacy_expiry_threshold_days"]) || 90;
	const medicines = useRows(["rep-medicines"], () => supabase.from("medicines").select("id, name, unit, stock_quantity, reorder_level, cost_price, selling_price").is("deleted_at", null).order("name", { ascending: true }));
	const batches = useRows(["rep-batches"], () => supabase.from("pharmacy_inventory").select("id, batch_number, expiry_date, quantity_received, quantity_remaining, purchase_price, selling_price, medicines(name), suppliers(name)").is("deleted_at", null).order("expiry_date", {
		ascending: true,
		nullsFirst: false
	}));
	const medRows = medicines.data ?? [];
	const batchRows = batches.data ?? [];
	const lowStockRows = medRows.filter((m) => n(m, "stock_quantity") <= n(m, "reorder_level"));
	const expiryRows = batchRows.filter((b) => {
		const status = expiryStatus(s(b, "expiry_date") || null, thresholdDays);
		return status === "expiring_soon" || status === "expired";
	});
	const batchInventoryValue = batchRows.reduce((sum, b) => sum + n(b, "quantity_remaining") * n(b, "purchase_price"), 0);
	if (medicines.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-4 text-lg font-bold tracking-tight text-foreground",
			children: t("pharmacy")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "expiry",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "mb-4 flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "expiry",
							children: t("expiry_report")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "low-stock",
							children: t("low_stock_report")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "batch-inventory",
							children: t("batch_inventory_report")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "expiry",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
								rows: expiryRows,
								filename: "roshan-expiry-report"
							})
						}), expiryRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("batch_number") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("supplier") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("remaining_quantity") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: expiryRows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: s(rel(b, "medicines"), "name") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: s(b, "batch_number") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(b, "suppliers"), "name") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: formatDate(s(b, "expiry_date"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: n(b, "quantity_remaining")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: t(expiryStatus(s(b, "expiry_date") || null, thresholdDays)) })
							] }, s(b, "id"))) })]
						})]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "low-stock",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
								rows: lowStockRows,
								filename: "roshan-low-stock-report"
							})
						}), lowStockRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("stock") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("reorder_level") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("selling_price") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: lowStockRows.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: s(m, "name")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									className: "font-semibold text-destructive",
									children: n(m, "stock_quantity")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: n(m, "reorder_level")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(m, "selling_price"), currency) })
							] }, s(m, "id"))) })]
						})]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "batch-inventory",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: t("batches"),
							value: String(batchRows.length)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: t("stock_value"),
							value: money(batchInventoryValue, currency)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
								rows: batchRows,
								filename: "roshan-batch-inventory-report"
							})
						}), batchRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("batch_number") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("supplier") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity_received") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("remaining_quantity") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("purchase_price") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: batchRows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: s(rel(b, "medicines"), "name") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: s(b, "batch_number") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(b, "suppliers"), "name") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: s(b, "expiry_date") ? formatDate(s(b, "expiry_date")) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: n(b, "quantity_received")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: n(b, "quantity_remaining")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(b, "purchase_price"), currency) })
							] }, s(b, "id"))) })]
						})]
					}) })]
				})
			]
		})]
	});
}
//#endregion
export { ReportsPage as component };
