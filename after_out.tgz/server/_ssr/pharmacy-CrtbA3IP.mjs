import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as SearchField, E as StatusBadge, O as Toolbar, _ as PageHeader, a as Empty, b as PermissionGate, g as NoResults, n as Button, o as ErrorBox, r as DataPanel, s as ExportButtons, u as InitialAvatar, v as PageSkeleton, w as SectionTitle } from "./kit-BmCdZVQb.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { o as formatDateTime, s as money } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-vwCASk5X.mjs";
import { n as dispensePrescriptionFefo } from "./pharmacy-Co3jb7c8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pharmacy-CrtbA3IP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"pending",
	"dispensed",
	"external",
	"all"
];
function PharmacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "pharmacy.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PharmacyPageInner, {})
	});
}
function PharmacyPageInner() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const { currency } = useSettings();
	const [status, setStatus] = (0, import_react.useState)("pending");
	const [search, setSearch] = (0, import_react.useState)("");
	const [dispenseDetail, setDispenseDetail] = (0, import_react.useState)({});
	const list = useRows(["pharmacy-queue", status], () => {
		let q = supabase.from("prescriptions").select("id, status, created_at, is_external, patients(full_name, mrn), users(full_name), prescription_items(id, quantity, dosage, frequency, duration, medicine_id, medicines(name, selling_price, stock_quantity))").is("deleted_at", null).order("created_at", { ascending: false }).limit(200);
		if (status !== "all") q = q.eq("status", status);
		return q;
	}, {
		refetchInterval: 2e4,
		keepPrevious: true
	});
	const dispense = useSave(async ({ prescriptionId }) => {
		const result = await dispensePrescriptionFefo(prescriptionId);
		setDispenseDetail((prev) => ({
			...prev,
			[prescriptionId]: result
		}));
		return result;
	}, {
		invalidate: [
			["pharmacy-queue"],
			["medicines"],
			["inventory"],
			["pharmacy-batches"]
		],
		successMessage: t("dispensed")
	});
	const rows = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		return (list.data ?? []).filter((p) => {
			if (!q) return true;
			const patient = rel(p, "patients");
			const meds = (p["prescription_items"] ?? []).map((i) => s(rel(i, "medicines"), "name")).join(" ");
			return `${s(patient, "full_name")} ${s(patient, "mrn")} ${meds}`.toLowerCase().includes(q);
		});
	}, [list.data, search]);
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {});
	const filtered = search.trim() !== "" || status !== "pending";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: t("pharmacy"),
			subtitle: t("dispense_queue"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-prescriptions"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Toolbar, {
			className: "mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchField, {
				value: search,
				onChange: setSearch,
				placeholder: t("search"),
				label: t("search")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: status,
				onValueChange: setStatus,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-11 w-full sm:w-44",
					"aria-label": t("status"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: STATUSES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: x,
					children: t(x)
				}, x)) })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		rows.length === 0 && filtered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoResults, { onClear: () => {
			setSearch("");
			setStatus("pending");
		} }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: t("no_data"),
			description: lang === "ar" ? "لا وصفات مطابقة." : "No matching prescriptions."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4",
			children: rows.map((p) => {
				const items = p["prescription_items"] ?? [];
				const total = items.reduce((sum, i) => sum + (n(i, "quantity") || 1) * n(rel(i, "medicines"), "selling_price"), 0);
				const usedBatches = dispenseDetail[s(p, "id")];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InitialAvatar, { name: s(rel(p, "patients"), "full_name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-semibold",
										children: s(rel(p, "patients"), "full_name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										dir: "ltr",
										children: [
											s(rel(p, "patients"), "mrn"),
											" · ",
											formatDateTime(s(p, "created_at")),
											" ·",
											" ",
											s(rel(p, "users"), "full_name")
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex w-full items-center justify-between gap-2 sm:w-auto sm:justify-end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(p, "status") }), can("pharmacy.update") && s(p, "status") === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									disabled: dispense.isPending,
									onClick: () => dispense.mutate({ prescriptionId: s(p, "id") }),
									children: t("dispense")
								}) : null]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("medicines") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y rounded-md border md:hidden",
							children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start justify-between gap-3 p-2.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 space-y-0.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: s(rel(i, "medicines"), "name")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												s(i, "dosage"),
												s(i, "frequency"),
												s(i, "duration")
											].filter(Boolean).join(" · ") || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												t("quantity"),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													dir: "ltr",
													children: n(i, "quantity") || 1
												}),
												" ·",
												" ",
												t("stock"),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													dir: "ltr",
													children: n(rel(i, "medicines"), "stock_quantity")
												})
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-semibold",
									children: money((n(i, "quantity") || 1) * n(rel(i, "medicines"), "selling_price"), currency)
								})]
							}, s(i, "id")))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden md:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
								density: "compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("dosage") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("stock") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("total") })
								] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "font-medium",
										children: s(rel(i, "medicines"), "name")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: [
										s(i, "dosage"),
										s(i, "frequency"),
										s(i, "duration")
									].filter(Boolean).join(" · ") || "—" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: n(i, "quantity") || 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: n(rel(i, "medicines"), "stock_quantity")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money((n(i, "quantity") || 1) * n(rel(i, "medicines"), "selling_price"), currency) })
								] }, s(i, "id"))) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-end text-sm font-semibold",
							children: [
								t("total"),
								": ",
								money(total, currency)
							]
						}),
						usedBatches && usedBatches.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-lg border bg-accent/30 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("batches_used") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
								density: "compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("batch_number") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity_dispensed") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("remaining_quantity") })
								] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: usedBatches.map((row, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "font-medium",
										children: row.medicine_name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: row.batch_number ?? t("legacy_stock")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: row.expiry_date ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: row.quantity_dispensed
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: row.batch_quantity_remaining ?? "—"
									})
								] }, `${row.item_id}-${row.batch_id ?? "legacy"}-${idx}`)) })]
							})]
						}) : null
					]
				}) }, s(p, "id"));
			})
		})
	] });
}
//#endregion
export { PharmacyPage as component };
