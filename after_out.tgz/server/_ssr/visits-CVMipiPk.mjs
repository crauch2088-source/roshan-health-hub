import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as rpc, c as useRows, i as rel, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang, r as Route$4 } from "./router-BiMGT4Sf.mjs";
import { C as Plus, l as Trash2 } from "../_libs/lucide-react.mjs";
import { D as Textarea, E as StatusBadge, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-asLB5pSR.mjs";
import { n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-WDSquJSC.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, c as todayISO, s as money } from "./medical-CD1sc5il.mjs";
import { n as PatientSnapshotStrip, t as PatientPicker } from "./patient-picker-uBzAaZVm.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DcyYd86X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/visits-CVMipiPk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var emptyForm = {
	patient_id: "",
	department_id: "",
	doctor_id: "",
	visit_type: "walk_in",
	consultation_fee: "0",
	notes: ""
};
function VisitsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "visits.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisitsPageInner, {})
	});
}
function VisitsPageInner() {
	const { t, lang } = useLang();
	const { can, user } = useAuth();
	const { currency } = useSettings();
	const search = Route$4.useSearch();
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [selectedPatient, setSelectedPatient] = (0, import_react.useState)(null);
	const canCreate = can("visits.create");
	const canDelete = can("visits.delete");
	const visits = useRows(["visits", date], () => supabase.from("visits").select(`
          id,
          visit_number,
          queue_number,
          queue_date,
          visit_date,
          status,
          visit_type,
          consultation_fee,
          notes,
          patients!visits_patient_id_fkey(
            id,
            full_name,
            mrn
          ),
          departments!visits_department_id_fkey(
            id,
            name,
            name_ar
          ),
          users!visits_doctor_id_fkey(
            id,
            full_name
          )
        `).eq("queue_date", date).is("deleted_at", null).order("queue_number", { ascending: true }));
	(0, import_react.useEffect)(() => {
		if (!search.patient || search.patient === selectedPatient?.id) return;
		let cancelled = false;
		supabase.from("patients").select("id, full_name, mrn, phone").eq("id", search.patient).is("deleted_at", null).maybeSingle().then(({ data }) => {
			if (cancelled || !data) return;
			const picked = data;
			setSelectedPatient(picked);
			setForm((current) => ({
				...current,
				patient_id: picked.id
			}));
			setOpen(true);
		});
		return () => {
			cancelled = true;
		};
	}, [search.patient]);
	const departments = useRows(["departments"], () => supabase.from("departments").select("id, name, name_ar").is("deleted_at", null).eq("is_active", true));
	const doctors = useRows(["doctors"], () => supabase.from("users").select("id, full_name, roles(code)").eq("active", true).is("deleted_at", null));
	const create = useSave(async () => {
		if (!form.patient_id) throw new Error(t("patient"));
		const { data: createdVisit, error } = await supabase.from("visits").insert({
			patient_id: form.patient_id,
			department_id: form.department_id || null,
			doctor_id: form.doctor_id || null,
			visit_date: (/* @__PURE__ */ new Date(`${date}T00:00:00+02:00`)).toISOString(),
			visit_type: form.visit_type,
			status: "waiting",
			consultation_fee: Number(form.consultation_fee) || 0,
			notes: form.notes.trim() || null
		}).select("id").single();
		if (error) throw new Error(error.message);
		const fee = Number(form.consultation_fee) || 0;
		if (fee > 0) {
			const invoiceNumber = await rpc("next_invoice_number");
			const { data: invoice, error: invoiceError } = await supabase.from("invoices").insert({
				invoice_number: invoiceNumber,
				patient_id: form.patient_id,
				visit_id: createdVisit?.id ?? null,
				invoice_date: date,
				total_amount: fee,
				subtotal: fee,
				discount_amount: 0,
				net_amount: fee,
				paid_amount: 0,
				status: "unpaid",
				payment_status: "unpaid",
				created_by: user?.id ?? null
			}).select("id").single();
			if (invoiceError) throw new Error(invoiceError.message);
			const { error: itemError } = await supabase.from("invoice_items").insert({
				invoice_id: invoice.id,
				item_type: "consultation",
				item_name: "Consultation",
				quantity: 1,
				unit_price: fee,
				total_price: fee
			});
			if (itemError) throw new Error(itemError.message);
		}
	}, {
		invalidate: [
			["visits", date],
			["queue", date],
			["invoices", date]
		],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm(emptyForm);
			setSelectedPatient(null);
		}
	});
	const deleteVisit = useSave(async (visitId) => {
		const { error } = await supabase.from("visits").update({
			deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
			deleted_by: null,
			status: "cancelled"
		}).eq("id", visitId);
		if (error) throw new Error(error.message);
		const { error: queueError } = await supabase.from("queue_tickets").update({
			status: "cancelled",
			completed_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("visit_id", visitId);
		if (queueError) throw new Error(queueError.message);
		return visitId;
	}, {
		invalidate: [["visits", date], ["queue", date]],
		successMessage: t("deleted")
	});
	const rows = visits.data ?? [];
	const filteredDoctors = (doctors.data ?? []).filter((doctor) => {
		const roleCode = s(rel(doctor, "roles"), "code").toLowerCase();
		return [
			"gp",
			"dentist",
			"specialist",
			"doctor",
			"physician"
		].includes(roleCode);
	});
	if (visits.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("visits"),
			subtitle: formatDate(date),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: date,
					onChange: (event) => setDate(event.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: `roshan-visits-${date}`
				}),
				canCreate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: (value) => {
						setOpen(value);
						if (!value) {
							setForm(emptyForm);
							setSelectedPatient(null);
						}
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t("new_visit")]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-h-[min(90dvh,90vh)] w-[calc(100%-1.5rem)] max-w-lg overflow-y-auto overscroll-contain sm:w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("new_visit") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
										label: `${t("patient")} *`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPicker, {
											value: selectedPatient,
											autoFocus: open,
											onSelect: (patient) => {
												setSelectedPatient(patient);
												setForm((current) => ({
													...current,
													patient_id: patient?.id ?? ""
												}));
											}
										}), selectedPatient ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientSnapshotStrip, {
											patientId: selectedPatient.id,
											currency
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("department"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											...form.department_id ? { value: form.department_id } : {},
											onValueChange: (value) => setForm((current) => ({
												...current,
												department_id: value
											})),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (departments.data ?? []).map((department) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: s(department, "id"),
												children: lang === "ar" ? s(department, "name_ar") || s(department, "name") : s(department, "name")
											}, s(department, "id"))) })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("doctor"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											...form.doctor_id ? { value: form.doctor_id } : {},
											onValueChange: (value) => setForm((current) => ({
												...current,
												doctor_id: value
											})),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: filteredDoctors.map((doctor) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: s(doctor, "id"),
												children: s(doctor, "full_name")
											}, s(doctor, "id"))) })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: t("visit_type"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: form.visit_type,
												onValueChange: (value) => setForm((current) => ({
													...current,
													visit_type: value
												})),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: "walk_in",
													children: t("walk_in")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: "scheduled",
													children: t("scheduled")
												})] })]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: t("consultation_fee"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												dir: "ltr",
												min: 0,
												value: form.consultation_fee,
												onChange: (event) => setForm((current) => ({
													...current,
													consultation_fee: event.target.value
												}))
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t("notes"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 2,
											value: form.notes,
											onChange: (event) => setForm((current) => ({
												...current,
												notes: event.target.value
											}))
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => {
									setOpen(false);
									setForm(emptyForm);
								},
								children: t("cancel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: !form.patient_id || create.isPending,
								onClick: () => create.mutate(),
								children: create.isPending ? t("saving") : t("save")
							})] })
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: visits.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "overflow-x-auto p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "لا زيارات في هذا النطاق. أنشئ زيارة جديدة من الزر أعلاه." : "No visits in this range. Create a new visit from the button above."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("visits"),
				children: rows.map((visit) => {
					const queueNumber = n(visit, "queue_number");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "space-y-2 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "break-words font-semibold",
										children: s(rel(visit, "patients"), "full_name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										dir: "ltr",
										children: s(rel(visit, "patients"), "mrn") || "—"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 flex-col items-end gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(visit, "status") }), queueNumber > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs font-semibold",
										dir: "ltr",
										children: `Q${queueNumber}`
									}) : null]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "ar" ? s(rel(visit, "departments"), "name_ar") || s(rel(visit, "departments"), "name") : s(rel(visit, "departments"), "name") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s(rel(visit, "users"), "full_name") || "—" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(visit, "consultation_fee"), currency) })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									size: "sm",
									className: "min-h-10 flex-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/clinic/$visitId",
										params: { visitId: s(visit, "id") },
										children: t("clinic")
									})
								}), canDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									className: "min-h-10 text-destructive hover:text-destructive",
									"aria-label": t("delete"),
									disabled: deleteVisit.isPending,
									onClick: () => {
										if (confirm(t("are_you_sure"))) deleteVisit.mutate(s(visit, "id"));
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})]
							})
						]
					}, s(visit, "id"));
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("queue_number") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("department") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("doctor") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("consultation_fee") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-end",
							children: t("actions")
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((visit) => {
						const queueNumber = n(visit, "queue_number");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "whitespace-nowrap font-medium",
								children: [s(rel(visit, "patients"), "full_name"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ms-2 text-xs text-muted-foreground",
									dir: "ltr",
									children: s(rel(visit, "patients"), "mrn")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: "font-mono text-xs font-semibold",
								children: queueNumber > 0 ? `Q${queueNumber}` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap",
								children: lang === "ar" ? s(rel(visit, "departments"), "name_ar") || s(rel(visit, "departments"), "name") : s(rel(visit, "departments"), "name")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap",
								children: s(rel(visit, "users"), "full_name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap",
								children: money(n(visit, "consultation_fee"), currency)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(visit, "status") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "space-x-1 space-x-reverse whitespace-nowrap text-end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/clinic/$visitId",
										params: { visitId: s(visit, "id") },
										children: t("clinic")
									})
								}), canDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									className: "text-destructive hover:text-destructive",
									disabled: deleteVisit.isPending,
									onClick: () => {
										if (confirm(t("are_you_sure"))) deleteVisit.mutate(s(visit, "id"));
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})]
							})
						] }, s(visit, "id"));
					}) })]
				})
			})] })
		}) })
	] });
}
//#endregion
export { VisitsPage as component };
