import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as rpc, c as useRows, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { C as Plus, P as Landmark, b as ReceiptText, ct as ArrowDownToLine, g as Search, i as Users, ot as ArrowUpFromLine, s as Truck, y as RefreshCw } from "../_libs/lucide-react.mjs";
import { T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox } from "./kit-asLB5pSR.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-WDSquJSC.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { s as money } from "./medical-CD1sc5il.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/accounting-0IxfJ4xW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "accounting.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountingPageInner, {})
	});
}
function AccountingPageInner() {
	const { t } = useLang();
	const { currency } = useSettings();
	const { can } = useAuth();
	const [tab, setTab] = (0, import_react.useState)("overview");
	if (!can("accounting.read")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "p-6",
		children: t("no_permission")
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: t("finance_hub"),
				subtitle: t("finance_hub_subtitle"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => window.location.reload(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "me-2 size-4" }), t("refresh")]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					[
						"overview",
						"finance_overview",
						Landmark
					],
					[
						"cashbox",
						"cashbox",
						ReceiptText
					],
					[
						"receivables",
						"receivables",
						Users
					],
					[
						"suppliers",
						"suppliers_finance",
						Truck
					]
				].map(([key, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: tab === key ? "default" : "outline",
					className: "justify-start",
					onClick: () => setTab(key),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "me-2 size-4" }), t(label)]
				}, key))
			}),
			tab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, { currency }),
			tab === "cashbox" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cashbox, {
				currency,
				canCreate: can("accounting.create")
			}),
			tab === "receivables" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receivables, {
				currency,
				canCreate: can("payments.create") || can("accounting.create")
			}),
			tab === "suppliers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Suppliers, {
				currency,
				canCreate: can("accounting.create"),
				canUpdate: can("accounting.update")
			})
		]
	});
}
function Overview({ currency }) {
	const payments = useRows(["finance-overview-payments"], () => supabase.from("payments").select("id,amount,payment_method,payment_date,deleted_at").is("deleted_at", null).limit(1e3));
	const expenses = useRows(["finance-overview-expenses"], () => supabase.from("expenses").select("id,amount,expense_date,deleted_at").is("deleted_at", null).limit(1e3));
	const bills = useRows(["finance-overview-bills"], () => supabase.from("supplier_bills").select("id,total_amount,paid_amount,status,deleted_at").is("deleted_at", null).limit(1e3));
	const cash = useRows(["finance-overview-cash"], () => supabase.from("cashbox_transactions").select("id,amount,transaction_type,transaction_date,deleted_at").is("deleted_at", null).order("transaction_date", { ascending: false }).limit(1e3));
	if (payments.isLoading || expenses.isLoading || bills.isLoading || cash.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const collected = (payments.data ?? []).reduce((a, r) => a + n(r, "amount"), 0);
	const spent = (expenses.data ?? []).reduce((a, r) => a + n(r, "amount"), 0);
	const supplierDebt = (bills.data ?? []).reduce((a, r) => a + Math.max(n(r, "total_amount") - n(r, "paid_amount"), 0), 0);
	const cashBalance = (cash.data ?? []).reduce((a, r) => a + n(r, "amount"), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: payments.error ?? expenses.error ?? bills.error ?? cash.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "الإيرادات المحصلة",
					value: money(collected, currency),
					tone: "success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "المصروفات",
					value: money(spent, currency),
					tone: "destructive"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "رصيد الخزنة",
					value: money(cashBalance, currency),
					tone: "primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "ديون الموردين",
					value: money(supplierDebt, currency),
					tone: "warning"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "ملخص مالي" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
					label: "صافي التدفق",
					value: money(collected - spent, currency)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
					label: "عدد الدفعات",
					value: String(payments.data?.length ?? 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
					label: "عدد حركات الخزنة",
					value: String(cash.data?.length ?? 0)
				})
			]
		}) })] })
	] });
}
function Summary({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-xl font-semibold",
			children: value
		})]
	});
}
function Cashbox({ currency, canCreate }) {
	const { t } = useLang();
	const [open, setOpen] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const rows = useRows(["cashbox"], () => supabase.from("cashbox_transactions").select("id,transaction_type,amount,payment_method,category,description,source_type,source_id,transaction_date,created_at").is("deleted_at", null).order("transaction_date", { ascending: false }).limit(300));
	const save = useSave(async () => {
		if (!amount || Number(amount) <= 0) throw new Error(t("invalid_amount"));
		await rpc("post_cashbox_entry", {
			_direction: open,
			_amount: Number(amount),
			_method: "cash",
			_category: "manual",
			_description: description || (open === "deposit" ? "Manual deposit" : "Manual withdrawal")
		});
	}, {
		invalidate: [
			["cashbox"],
			["finance-overview-cash"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(null);
			setAmount("");
			setDescription("");
		}
	});
	const balance = (rows.data ?? []).reduce((a, r) => a + n(r, "amount"), 0);
	if (rows.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: rows.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("cashbox_balance"),
					value: money(balance, currency),
					tone: "primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("cash_in"),
					value: money((rows.data ?? []).filter((r) => n(r, "amount") > 0).reduce((a, r) => a + n(r, "amount"), 0), currency),
					tone: "success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("cash_out"),
					value: money(Math.abs((rows.data ?? []).filter((r) => n(r, "amount") < 0).reduce((a, r) => a + n(r, "amount"), 0)), currency),
					tone: "destructive"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				disabled: !canCreate,
				onClick: () => setOpen("deposit"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "me-2 size-4" }), t("deposit")]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				disabled: !canCreate,
				variant: "outline",
				onClick: () => setOpen("withdrawal"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpFromLine, { className: "me-2 size-4" }), t("withdrawal")]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("type") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("description") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (rows.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					colSpan: 4,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {})
				}) }) : (rows.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: new Date(s(r, "transaction_date") || s(r, "created_at")).toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(r, "transaction_type") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(r, "description") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: n(r, "amount") >= 0 ? "font-medium" : "font-medium text-destructive",
						children: money(n(r, "amount"), currency)
					})
				] }, s(r, "id"))) })]
			})
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!open,
			onOpenChange: (v) => !v && setOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: open === "deposit" ? t("deposit") : t("withdrawal") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("amount"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: "0.01",
							dir: "ltr",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("description"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: description,
							onChange: (e) => setDescription(e.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setOpen(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: save.isPending,
					onClick: () => save.mutate(void 0),
					children: t("save")
				})] })
			] })
		})
	] });
}
function Receivables({ currency, canCreate }) {
	const { t } = useLang();
	const [search, setSearch] = (0, import_react.useState)("");
	const [paymentFor, setPaymentFor] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("");
	const invoices = useRows(["receivables", search], () => {
		let q = supabase.from("invoices").select("id,invoice_number,patient_id,net_amount,paid_amount,status,invoice_date,patients(full_name,mrn)").is("deleted_at", null).order("invoice_date", { ascending: false }).limit(500);
		if (search.trim()) q = q.or(`invoice_number.ilike.%${search.trim()}%`);
		return q;
	});
	const save = useSave(async () => {
		if (!paymentFor || Number(amount) <= 0) throw new Error(t("invalid_amount"));
		const outstanding = Math.max(n(paymentFor, "net_amount") - n(paymentFor, "paid_amount"), 0);
		if (Number(amount) > outstanding) throw new Error(t("payment_exceeds_balance"));
		await rpc("post_invoice_payment", {
			_invoice_id: s(paymentFor, "id"),
			_amount: Number(amount),
			_method: "cash",
			_reference: null
		});
	}, {
		invalidate: [
			["receivables"],
			["cashbox"],
			["finance-overview-payments"],
			["finance-overview-cash"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setPaymentFor(null);
			setAmount("");
		}
	});
	if (invoices.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const rows = (invoices.data ?? []).filter((r) => Math.max(n(r, "net_amount") - n(r, "paid_amount"), 0) > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: invoices.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative max-w-sm flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute start-3 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "ps-9",
					placeholder: t("search"),
					value: search,
					onChange: (e) => setSearch(e.target.value)
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("invoice_number") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("paid") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("balance") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					colSpan: 6,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {})
				}) }) : rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "invoice_number")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(Array.isArray(r["patients"]) ? r["patients"][0] : r["patients"], "full_name") || s(Array.isArray(r["patients"]) ? r["patients"][0] : r["patients"], "mrn") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "net_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "paid_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-semibold",
						children: money(Math.max(n(r, "net_amount") - n(r, "paid_amount"), 0), currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						disabled: !canCreate,
						onClick: () => setPaymentFor(r),
						children: t("take_payment")
					}) })
				] }, s(r, "id"))) })]
			})
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!paymentFor,
			onOpenChange: (v) => !v && setPaymentFor(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("take_payment") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("amount"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0.01",
						dir: "ltr",
						value: amount,
						onChange: (e) => setAmount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setPaymentFor(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: save.isPending,
					onClick: () => save.mutate(void 0),
					children: t("save")
				})] })
			] })
		})
	] });
}
function Suppliers({ currency, canCreate, canUpdate }) {
	const { t } = useLang();
	const [supplier, setSupplier] = (0, import_react.useState)(null);
	const [billOpen, setBillOpen] = (0, import_react.useState)(false);
	const [paymentOpen, setPaymentOpen] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [billTotal, setBillTotal] = (0, import_react.useState)("");
	const [billNo, setBillNo] = (0, import_react.useState)("");
	const [billDate, setBillDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [payAmount, setPayAmount] = (0, import_react.useState)("");
	const suppliers = useRows(["suppliers"], () => supabase.from("suppliers").select("id,name,phone,address,active,created_at").is("deleted_at", null).order("name").limit(500));
	const bills = useRows(["supplier-bills", supplier ? s(supplier, "id") : "none"], () => supabase.from("supplier_bills").select("id,supplier_id,invoice_number,bill_date,due_date,total_amount,paid_amount,status,notes").eq("supplier_id", s(supplier, "id")).is("deleted_at", null).order("bill_date", { ascending: false }));
	const addSupplier = useSave(async () => {
		if (!name.trim()) throw new Error(t("required"));
		const { error } = await supabase.from("suppliers").insert({
			name: name.trim(),
			phone: phone || null,
			address: address || null,
			active: true
		});
		if (error) throw error;
	}, {
		invalidate: [["suppliers"]],
		successMessage: t("saved"),
		onDone: () => {
			setName("");
			setPhone("");
			setAddress("");
		}
	});
	const addBill = useSave(async () => {
		if (!supplier || Number(billTotal) <= 0) throw new Error(t("invalid_amount"));
		await rpc("post_supplier_bill", {
			_supplier_id: s(supplier, "id"),
			_invoice_number: billNo || null,
			_bill_date: billDate,
			_due_date: null,
			_subtotal: Number(billTotal),
			_discount: 0
		});
	}, {
		invalidate: [
			["supplier-bills", supplier ? s(supplier, "id") : "none"],
			["suppliers"],
			["supplier-outstanding"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setBillOpen(false);
			setBillTotal("");
			setBillNo("");
		}
	});
	const payBill = useSave(async () => {
		if (!paymentOpen || Number(payAmount) <= 0) throw new Error(t("invalid_amount"));
		const outstanding = Math.max(n(paymentOpen, "total_amount") - n(paymentOpen, "paid_amount"), 0);
		if (Number(payAmount) > outstanding) throw new Error(t("payment_exceeds_balance"));
		await rpc("post_supplier_payment", {
			_bill_id: s(paymentOpen, "id"),
			_amount: Number(payAmount),
			_method: "cash"
		});
	}, {
		invalidate: [
			["supplier-bills", supplier ? s(supplier, "id") : "none"],
			["cashbox"],
			["finance-overview-cash"],
			["supplier-outstanding"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setPaymentOpen(null);
			setPayAmount("");
		}
	});
	if (suppliers.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: suppliers.error ?? bills.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: t("suppliers_finance") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-[1fr_2fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 font-medium",
						children: t("add_supplier")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: t("name"),
								value: name,
								onChange: (e) => setName(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: t("phone"),
								value: phone,
								onChange: (e) => setPhone(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: t("address"),
								value: address,
								onChange: (e) => setAddress(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								disabled: !canCreate || addSupplier.isPending,
								onClick: () => addSupplier.mutate(void 0),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "me-2 size-4" }), t("add")]
							})
						]
					})]
				}), (suppliers.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSupplier(r),
					className: `w-full rounded-lg border p-3 text-start hover:bg-muted ${supplier && s(supplier, "id") === s(r, "id") ? "ring-2 ring-primary" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium",
						children: s(r, "name")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: s(r, "phone") || "—"
					})]
				}, s(r, "id")))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: !supplier ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-lg font-semibold",
					children: s(supplier, "name")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-muted-foreground",
					children: s(supplier, "phone")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					disabled: !canCreate,
					onClick: () => setBillOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "me-2 size-4" }), t("new_supplier_bill")]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("invoice_number") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("total") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("paid") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("balance") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (bills.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					colSpan: 6,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {})
				}) }) : (bills.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "invoice_number") || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "bill_date")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "total_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(r, "paid_amount"), currency) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-semibold",
						children: money(Math.max(n(r, "total_amount") - n(r, "paid_amount"), 0), currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						disabled: !canUpdate || n(r, "total_amount") <= n(r, "paid_amount"),
						onClick: () => setPaymentOpen(r),
						children: t("take_payment")
					}) })
				] }, s(r, "id"))) })]
			})] }) })]
		}) })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: billOpen,
			onOpenChange: (v) => setBillOpen(v),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("new_supplier_bill") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("invoice_number"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: billNo,
								onChange: (e) => setBillNo(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("date"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								dir: "ltr",
								value: billDate,
								onChange: (e) => setBillDate(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("total"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0.01",
								dir: "ltr",
								value: billTotal,
								onChange: (e) => setBillTotal(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setBillOpen(false),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: addBill.isPending,
					onClick: () => addBill.mutate(void 0),
					children: t("save")
				})] })
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!paymentOpen,
			onOpenChange: (v) => !v && setPaymentOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("supplier_payment") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("amount"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0.01",
						dir: "ltr",
						value: payAmount,
						onChange: (e) => setPayAmount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setPaymentOpen(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: payBill.isPending,
					onClick: () => payBill.mutate(void 0),
					children: t("save")
				})] })
			] })
		})
	] });
}
//#endregion
export { AccountingPage as component };
