import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { i as rel, o as s, s as usePagedRows } from "./db-Ckpr7291.mjs";
import { i as useLang } from "./router-BiMGT4Sf.mjs";
import { _ as PageHeader, a as Empty, b as PermissionGate, d as Input, f as Loading, o as ErrorBox, s as ExportButtons, y as Pager } from "./kit-asLB5pSR.mjs";
import { n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { o as formatDateTime } from "./medical-CD1sc5il.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-t0GtWGOQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 50;
/** Keeps free-text search safe to embed in a PostgREST `.or()` filter string. */
function sanitizeSearch(term) {
	return term.replace(/[,()%]/g, "").trim();
}
function AuditPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "audit.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditPageInner, {})
	});
}
function AuditPageInner() {
	const { t } = useLang();
	const [page, setPage] = (0, import_react.useState)(1);
	const [q, setQ] = (0, import_react.useState)("");
	const list = usePagedRows(["audit", q], ({ from, to }) => {
		let query = supabase.from("audit_logs").select("id, action, table_name, created_at, users(full_name)", { count: "exact" });
		const term = sanitizeSearch(q);
		if (term) query = query.or(`action.ilike.%${term}%,table_name.ilike.%${term}%`);
		return query.order("created_at", { ascending: false }).range(from, to);
	}, page, PAGE_SIZE);
	const rows = list.rows;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("audit_log"),
			subtitle: t("recent_activity"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: t("search"),
				value: q,
				onChange: (e) => {
					setQ(e.target.value);
					setPage(1);
				},
				className: "w-56"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-audit"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "p-0",
			children: [list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("user") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("action") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("table") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: formatDateTime(s(r, "created_at"))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(r, "users"), "full_name") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(r, "action") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "table_name")
					})
				] }, s(r, "id"))) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				page: list.page,
				pageCount: list.pageCount,
				count: list.count,
				pageSize: PAGE_SIZE,
				hasPrev: list.hasPrev,
				hasNext: list.hasNext,
				isFetching: list.isFetching,
				onPrev: () => setPage((p) => Math.max(1, p - 1)),
				onNext: () => setPage((p) => p + 1)
			})]
		}) })
	] });
}
//#endregion
export { AuditPage as component };
