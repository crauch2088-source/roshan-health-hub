import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { i as useLang } from "./router-CIKlg6Xn.mjs";
import { T as StatCard, _ as PageHeader, a as Empty, b as PermissionGate, f as Loading, o as ErrorBox, s as ExportButtons } from "./kit-BmCdZVQb.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-CZpHQ_ke.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { s as money } from "./medical-CD1sc5il.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-D0CoeBa_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analytics-CuVEM3B5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function monthsAgoISO(months) {
	const d = /* @__PURE__ */ new Date();
	d.setMonth(d.getMonth() - months);
	d.setDate(1);
	return d.toISOString().slice(0, 10);
}
/** "2026-03" -> "Mar 2026" (or an Arabic-numeral-safe equivalent via Intl when lang=ar handled by caller). */
function monthLabel(key, lang) {
	const [y, m] = key.split("-").map(Number);
	return new Date(y ?? (/* @__PURE__ */ new Date()).getFullYear(), (m || 1) - 1, 1).toLocaleDateString(lang === "ar" ? "ar" : "en", {
		year: "numeric",
		month: "short"
	});
}
function monthKey(dateStr) {
	if (!dateStr) return "—";
	return dateStr.slice(0, 7);
}
/** Groups rows by month and sums one numeric field, returning the last N months in order (oldest first). */
function sumByMonth(rows, dateField, amountField, months) {
	const buckets = /* @__PURE__ */ new Map();
	for (const r of rows) {
		const key = monthKey(s(r, dateField));
		if (key === "—") continue;
		buckets.set(key, (buckets.get(key) ?? 0) + n(r, amountField));
	}
	const keys = [];
	for (let i = months - 1; i >= 0; i--) {
		const d = /* @__PURE__ */ new Date();
		d.setMonth(d.getMonth() - i);
		keys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
	}
	return keys.map((k) => ({
		month: k,
		total: buckets.get(k) ?? 0
	}));
}
function TrendTable({ rows, currency, lang }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
		density: "compact",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("month") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			dir: "ltr",
			children: monthLabel(r.month, lang)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "font-medium",
			children: money(r.total, currency)
		})] }, r.month)) })]
	});
}
function ReportCard({ title, children, exportRows, filename }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
		className: "flex flex-row items-center justify-between space-y-0 pb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
			className: "text-base",
			children: title
		}), exportRows && filename ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
			rows: exportRows,
			filename
		}) : null]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "p-0",
		children
	})] });
}
function AnalyticsPage() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "reports.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: t("analytics"),
			subtitle: t("analytics_subtitle")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "financial",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "mb-4 flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "financial",
							children: t("finance")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "pharmacy",
							children: t("pharmacy")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "clinical",
							children: t("clinical")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "financial",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinancialAnalytics, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "pharmacy",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PharmacyAnalytics, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "clinical",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClinicalAnalytics, {})
				})
			]
		})] })
	});
}
function FinancialAnalytics() {
	const { t, lang } = useLang();
	const { currency } = useSettings();
	const since = monthsAgoISO(11);
	const payments = useRows(["an-payments"], () => supabase.from("payments").select("amount, payment_date").is("deleted_at", null).gte("payment_date", since).limit(5e3));
	const expenses = useRows(["an-expenses"], () => supabase.from("expenses").select("amount, expense_date").is("deleted_at", null).gte("expense_date", since).limit(5e3));
	const insurancePayments = useRows(["an-insurance-claims-paid"], () => supabase.from("insurance_claims").select("paid_amount, paid_at").is("deleted_at", null).not("paid_at", "is", null).gte("paid_at", since).limit(2e3));
	const receivables = useRows(["an-receivables"], () => supabase.from("v_patient_receivables").select("*").order("outstanding", { ascending: false }).limit(500));
	const supplierDebt = useRows(["an-supplier-debt"], () => supabase.from("v_supplier_outstanding").select("*").order("outstanding", { ascending: false }).limit(500));
	const revenueTrend = (0, import_react.useMemo)(() => sumByMonth(payments.data ?? [], "payment_date", "amount", 12), [payments.data]);
	const expenseTrend = (0, import_react.useMemo)(() => sumByMonth(expenses.data ?? [], "expense_date", "amount", 12), [expenses.data]);
	const insuranceTrend = (0, import_react.useMemo)(() => sumByMonth(insurancePayments.data ?? [], "paid_at", "paid_amount", 12), [insurancePayments.data]);
	const receivablesRows = (receivables.data ?? []).filter((r) => n(r, "outstanding") > 0);
	const supplierRows = (supplierDebt.data ?? []).filter((r) => n(r, "outstanding") > 0);
	const totalReceivable = receivablesRows.reduce((sum, r) => sum + n(r, "outstanding"), 0);
	const totalSupplierDebt = supplierRows.reduce((sum, r) => sum + n(r, "outstanding"), 0);
	const totalRevenue12mo = revenueTrend.reduce((sum, r) => sum + r.total, 0);
	const totalExpense12mo = expenseTrend.reduce((sum, r) => sum + r.total, 0);
	if (payments.isLoading || expenses.isLoading || insurancePayments.isLoading || receivables.isLoading || supplierDebt.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: payments.error ?? expenses.error ?? insurancePayments.error ?? receivables.error ?? supplierDebt.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("revenue_12mo"),
						value: money(totalRevenue12mo, currency),
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("expenses_12mo"),
						value: money(totalExpense12mo, currency),
						tone: "destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("outstanding_balance"),
						value: money(totalReceivable, currency),
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("supplier_debt"),
						value: money(totalSupplierDebt, currency),
						tone: "warning"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("revenue_trends"),
						exportRows: revenueTrend,
						filename: "roshan-revenue-trends",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendTable, {
							rows: revenueTrend,
							currency,
							lang
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("expense_trends"),
						exportRows: expenseTrend,
						filename: "roshan-expense-trends",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendTable, {
							rows: expenseTrend,
							currency,
							lang
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("insurance_revenue"),
						exportRows: insuranceTrend,
						filename: "roshan-insurance-revenue",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendTable, {
							rows: insuranceTrend,
							currency,
							lang
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("outstanding_receivables"),
						exportRows: receivablesRows,
						filename: "roshan-outstanding-receivables",
						children: receivablesRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("outstanding_balance") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: receivablesRows.slice(0, 15).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(r, "patient_name")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "text-destructive",
								children: money(n(r, "outstanding"), currency)
							})] }, s(r, "invoice_id"))) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("supplier_debt_analysis"),
						exportRows: supplierRows,
						filename: "roshan-supplier-debt-analysis",
						children: supplierRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("supplier") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("outstanding_balance") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: supplierRows.slice(0, 15).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: s(r, "name")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "text-destructive",
								children: money(n(r, "outstanding"), currency)
							})] }, s(r, "supplier_id"))) })]
						})
					})
				]
			})
		]
	});
}
function PharmacyAnalytics() {
	const { t } = useLang();
	const { currency } = useSettings();
	const since = monthsAgoISO(11);
	const dispenseMoves = useRows(["an-dispense-moves"], () => supabase.from("stock_movements").select("medicine_id, quantity, medicines(name, selling_price)").eq("movement_type", "dispense").gte("created_at", since).limit(5e3));
	const wasteMoves = useRows(["an-waste-moves"], () => supabase.from("stock_movements").select("medicine_id, quantity, created_at, medicines(name)").eq("movement_type", "writeoff").gte("created_at", since).limit(2e3));
	const batches = useRows(["an-expiry-forecast"], () => supabase.from("pharmacy_inventory").select("expiry_date, quantity_remaining, purchase_price, medicines(name)").is("deleted_at", null).gt("quantity_remaining", 0).not("expiry_date", "is", null).order("expiry_date", { ascending: true }).limit(1e3));
	const performance = (0, import_react.useMemo)(() => {
		const byMed = /* @__PURE__ */ new Map();
		for (const r of dispenseMoves.data ?? []) {
			const med = rel(r, "medicines");
			const name = s(med, "name") || "—";
			const qty = Math.abs(n(r, "quantity"));
			const revenue = qty * n(med, "selling_price");
			const cur = byMed.get(name) ?? {
				name,
				qty: 0,
				revenue: 0
			};
			cur.qty += qty;
			cur.revenue += revenue;
			byMed.set(name, cur);
		}
		return Array.from(byMed.values()).sort((a, b) => b.revenue - a.revenue).slice(0, 15);
	}, [dispenseMoves.data]);
	const waste = (0, import_react.useMemo)(() => {
		const byMed = /* @__PURE__ */ new Map();
		for (const r of wasteMoves.data ?? []) {
			const name = s(rel(r, "medicines"), "name") || "—";
			const qty = Math.abs(n(r, "quantity"));
			const cur = byMed.get(name) ?? {
				name,
				qty: 0
			};
			cur.qty += qty;
			byMed.set(name, cur);
		}
		return Array.from(byMed.values()).sort((a, b) => b.qty - a.qty).slice(0, 15);
	}, [wasteMoves.data]);
	const forecast = (0, import_react.useMemo)(() => {
		const buckets = /* @__PURE__ */ new Map();
		const rows = batches.data ?? [];
		for (const r of rows) {
			const key = monthKey(s(r, "expiry_date"));
			if (key === "—") continue;
			buckets.set(key, (buckets.get(key) ?? 0) + n(r, "quantity_remaining") * n(r, "purchase_price"));
		}
		const keys = [];
		for (let i = 0; i < 6; i++) {
			const d = /* @__PURE__ */ new Date();
			d.setMonth(d.getMonth() + i);
			keys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
		}
		return keys.map((k) => ({
			month: k,
			value: buckets.get(k) ?? 0
		}));
	}, [batches.data]);
	const totalWasteQty = waste.reduce((sum, w) => sum + w.qty, 0);
	const totalForecastValue = forecast.reduce((sum, f) => sum + f.value, 0);
	if (dispenseMoves.isLoading || wasteMoves.isLoading || batches.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: dispenseMoves.error ?? wasteMoves.error ?? batches.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("fefo_waste_units"),
					value: String(totalWasteQty),
					tone: "destructive"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: t("expiry_forecast_value"),
					value: money(totalForecastValue, currency),
					tone: "warning"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("pharmacy_performance"),
						exportRows: performance,
						filename: "roshan-pharmacy-performance",
						children: performance.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity_dispensed") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: performance.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: p.qty
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(p.revenue, currency) })
							] }, p.name)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("fefo_waste_tracking"),
						exportRows: waste,
						filename: "roshan-fefo-waste",
						children: waste.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("medicines") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: waste.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: w.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								className: "text-destructive",
								children: w.qty
							})] }, w.name)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("expiry_forecasting"),
						exportRows: forecast,
						filename: "roshan-expiry-forecast",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("month") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("value_at_risk") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: forecast.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: monthLabel(f.month, "en")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: f.value > 0 ? "font-medium text-warning" : void 0,
								children: money(f.value, currency)
							})] }, f.month)) })]
						})
					})
				]
			})
		]
	});
}
function ClinicalAnalytics() {
	const { t, lang } = useLang();
	const { currency } = useSettings();
	const since = monthsAgoISO(11);
	const visits = useRows(["an-visits"], () => supabase.from("visits").select("visit_date, status, consultation_fee, doctor_id, department_id, users(full_name), departments(name, name_ar)").is("deleted_at", null).gte("visit_date", since).limit(5e3));
	const appointments = useRows(["an-appointments"], () => supabase.from("appointments").select("appointment_date, status").is("deleted_at", null).gte("appointment_date", since).limit(5e3));
	const labOrders = useRows(["an-lab-orders"], () => supabase.from("lab_orders").select("created_at, status, lab_order_items(price)").is("deleted_at", null).gte("created_at", since).limit(3e3));
	const visitTrend = (0, import_react.useMemo)(() => {
		return sumByMonth((visits.data ?? []).map((r) => ({
			...r,
			_count: 1
		})), "visit_date", "_count", 12);
	}, [visits.data]);
	const doctorStats = (0, import_react.useMemo)(() => {
		const byDoctor = /* @__PURE__ */ new Map();
		for (const r of visits.data ?? []) {
			const name = s(rel(r, "users"), "full_name") || t("unassigned");
			const cur = byDoctor.get(name) ?? {
				name,
				count: 0,
				revenue: 0
			};
			cur.count += 1;
			cur.revenue += n(r, "consultation_fee");
			byDoctor.set(name, cur);
		}
		return Array.from(byDoctor.values()).sort((a, b) => b.count - a.count).slice(0, 15);
	}, [visits.data, t]);
	const deptStats = (0, import_react.useMemo)(() => {
		const byDept = /* @__PURE__ */ new Map();
		for (const r of visits.data ?? []) {
			const dept = rel(r, "departments");
			const name = (lang === "ar" ? s(dept, "name_ar") : s(dept, "name")) || t("unassigned");
			const cur = byDept.get(name) ?? {
				name,
				count: 0
			};
			cur.count += 1;
			byDept.set(name, cur);
		}
		return Array.from(byDept.values()).sort((a, b) => b.count - a.count);
	}, [
		visits.data,
		lang,
		t
	]);
	const appointmentStats = (0, import_react.useMemo)(() => {
		const byStatus = /* @__PURE__ */ new Map();
		for (const r of appointments.data ?? []) {
			const status = s(r, "status") || "—";
			byStatus.set(status, (byStatus.get(status) ?? 0) + 1);
		}
		return Array.from(byStatus.entries()).map(([status, count]) => ({
			status,
			count
		}));
	}, [appointments.data]);
	const labStats = (0, import_react.useMemo)(() => {
		const rows = labOrders.data ?? [];
		const byMonth = /* @__PURE__ */ new Map();
		for (const r of rows) {
			const key = monthKey(s(r, "created_at"));
			if (key === "—") continue;
			const revenue = (r["lab_order_items"] ?? []).reduce((sum, i) => sum + n(i, "price"), 0);
			const cur = byMonth.get(key) ?? {
				count: 0,
				revenue: 0
			};
			cur.count += 1;
			cur.revenue += revenue;
			byMonth.set(key, cur);
		}
		const keys = [];
		for (let i = 11; i >= 0; i--) {
			const d = /* @__PURE__ */ new Date();
			d.setMonth(d.getMonth() - i);
			keys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
		}
		return keys.map((k) => ({
			month: k,
			...byMonth.get(k) ?? {
				count: 0,
				revenue: 0
			}
		}));
	}, [labOrders.data]);
	const totalVisits12mo = visitTrend.reduce((sum, r) => sum + r.total, 0);
	const totalAppointments = appointmentStats.reduce((sum, r) => sum + r.count, 0);
	const totalLabRevenue = labStats.reduce((sum, r) => sum + r.revenue, 0);
	if (visits.isLoading || appointments.isLoading || labOrders.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: visits.error ?? appointments.error ?? labOrders.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("visits_12mo"),
						value: String(totalVisits12mo)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("appointments_12mo"),
						value: String(totalAppointments)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: t("lab_revenue_12mo"),
						value: money(totalLabRevenue, currency),
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("visit_trends"),
						exportRows: visitTrend,
						filename: "roshan-visit-trends",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("month") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("visits") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: visitTrend.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: monthLabel(r.month, lang)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: r.total
							})] }, r.month)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("doctor_productivity"),
						exportRows: doctorStats,
						filename: "roshan-doctor-productivity",
						children: doctorStats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("visits") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: doctorStats.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: d.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: d.count
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(d.revenue, currency) })
							] }, d.name)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("department_statistics"),
						exportRows: deptStats,
						filename: "roshan-department-statistics",
						children: deptStats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("department") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("visits") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: deptStats.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: d.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: d.count
							})] }, d.name)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("appointment_analytics"),
						exportRows: appointmentStats,
						filename: "roshan-appointment-analytics",
						children: appointmentStats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity") })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: appointmentStats.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium",
								children: t(a.status)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								dir: "ltr",
								children: a.count
							})] }, a.status)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						title: t("laboratory_analytics"),
						exportRows: labStats,
						filename: "roshan-laboratory-analytics",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("month") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: labStats.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: monthLabel(r.month, lang)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: r.count
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(r.revenue, currency) })
							] }, r.month)) })]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { AnalyticsPage as component };
