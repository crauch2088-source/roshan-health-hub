import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { c as useRows, i as rel, l as useSave, o as s, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-BiMGT4Sf.mjs";
import { C as Plus, l as Trash2 } from "../_libs/lucide-react.mjs";
import { D as Textarea, E as StatusBadge, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, f as Loading, n as Button, o as ErrorBox, s as ExportButtons } from "./kit-asLB5pSR.mjs";
import { n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-WDSquJSC.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CW7stYkz.mjs";
import { a as formatDate, c as todayISO } from "./medical-CD1sc5il.mjs";
import { n as PatientSnapshotStrip, t as PatientPicker } from "./patient-picker-uBzAaZVm.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DcyYd86X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/appointments-6JCcEKb_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppointmentsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "appointments.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppointmentsPageInner, {})
	});
}
function AppointmentsPageInner() {
	const { lang, t } = useLang();
	const { user } = useAuth();
	const { currency } = useSettings();
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [open, setOpen] = (0, import_react.useState)(false);
	const [selectedPatient, setSelectedPatient] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		patient_id: "",
		doctor_id: "",
		department_id: "",
		appointment_date: todayISO(),
		appointment_time: "09:00",
		notes: ""
	});
	const appointments = useRows(["appointments", date], () => supabase.from("appointments").select("id, appointment_date, appointment_time, status, notes, patients(id, full_name, mrn), users(full_name), departments(name, name_ar)").gte("appointment_date", (/* @__PURE__ */ new Date(`${date}T00:00:00+02:00`)).toISOString()).lt("appointment_date", new Date((/* @__PURE__ */ new Date(`${date}T00:00:00+02:00`)).getTime() + 864e5).toISOString()).is("deleted_at", null).order("appointment_date", { ascending: true }));
	const departments = useRows(["departments"], () => supabase.from("departments").select("id, name, name_ar").is("deleted_at", null));
	const doctors = useRows(["doctors"], () => supabase.from("users").select("id, full_name, roles(code)").eq("active", true).is("deleted_at", null));
	const create = useSave(async () => {
		if (!user?.id) throw new Error(lang === "ar" ? "لم يتم العثور على مستخدم النظام الحالي. يرجى تسجيل الدخول مرة أخرى." : "The current application user could not be identified. Please sign in again.");
		if (!form.patient_id) throw new Error(lang === "ar" ? "يرجى اختيار المريض." : "Please select a patient.");
		if (!form.appointment_date) throw new Error(lang === "ar" ? "يرجى اختيار تاريخ الموعد." : "Please select an appointment date.");
		if (!form.appointment_time) throw new Error(lang === "ar" ? "يرجى اختيار وقت الموعد." : "Please select an appointment time.");
		const appointmentDateTime = `${form.appointment_date}T${form.appointment_time}:00`;
		const { error } = await supabase.from("appointments").insert({
			patient_id: form.patient_id,
			doctor_id: form.doctor_id || null,
			department_id: form.department_id || null,
			appointment_date: appointmentDateTime,
			appointment_time: form.appointment_time,
			status: "scheduled",
			notes: form.notes || null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["appointments", date]],
		successMessage: lang === "ar" ? "تم حفظ الموعد بنجاح" : "Appointment saved successfully",
		onDone: () => {
			setOpen(false);
			setSelectedPatient(null);
			setForm({
				patient_id: "",
				doctor_id: "",
				department_id: "",
				appointment_date: todayISO(),
				appointment_time: "09:00",
				notes: ""
			});
		}
	});
	const deleteAppointment = useSave(async (id) => {
		if (!user?.id) throw new Error(lang === "ar" ? "لم يتم العثور على المستخدم الحالي." : "The current application user could not be identified.");
		const { error } = await supabase.from("appointments").update({
			deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
			deleted_by: user.id,
			updated_by: user.id
		}).eq("id", id);
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["appointments", date]],
		successMessage: lang === "ar" ? "تم حذف الموعد" : "Appointment deleted"
	});
	const rows = appointments.data ?? [];
	const doctorRows = (doctors.data ?? []).filter((doctor) => {
		const roleCode = s(rel(doctor, "roles"), "code").toLowerCase();
		return !roleCode || [
			"gp",
			"dentist",
			"specialist",
			"doctor",
			"physician"
		].includes(roleCode);
	});
	if (appointments.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: lang === "ar" ? "المواعيد" : "Appointments",
			subtitle: formatDate(date),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					dir: "ltr",
					value: date,
					onChange: (e) => setDate(e.target.value),
					className: "w-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
					rows,
					filename: `roshan-appointments-${date}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							type: "button",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), lang === "ar" ? "ميعاد جديد" : "New Appointment"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-h-[90vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: lang === "ar" ? "حجز ميعاد جديد" : "New Appointment" }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
										label: lang === "ar" ? "المريض *" : "Patient *",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPicker, {
											value: selectedPatient,
											onSelect: (patient) => {
												setSelectedPatient(patient);
												setForm({
													...form,
													patient_id: patient?.id ?? ""
												});
											}
										}), selectedPatient ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientSnapshotStrip, {
											patientId: selectedPatient.id,
											currency
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: lang === "ar" ? "الطبيب" : "Doctor",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											...form.doctor_id ? { value: form.doctor_id } : {},
											onValueChange: (value) => setForm({
												...form,
												doctor_id: value
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "بدون" : "None" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: doctorRows.map((doctor) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: s(doctor, "id"),
												children: s(doctor, "full_name")
											}, s(doctor, "id"))) })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: lang === "ar" ? "القسم" : "Department",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: form.department_id,
											onValueChange: (value) => setForm({
												...form,
												department_id: value
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "بدون" : "None" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (departments.data ?? []).map((department) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: s(department, "id"),
												children: lang === "ar" ? s(department, "name_ar") || s(department, "name") : s(department, "name")
											}, s(department, "id"))) })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: lang === "ar" ? "تاريخ الموعد" : "Appointment Date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												dir: "ltr",
												value: form.appointment_date,
												onChange: (e) => setForm({
													...form,
													appointment_date: e.target.value
												})
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: lang === "ar" ? "الوقت" : "Time",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "time",
												dir: "ltr",
												value: form.appointment_time,
												onChange: (e) => setForm({
													...form,
													appointment_time: e.target.value
												})
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: lang === "ar" ? "ملاحظات" : "Notes",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 2,
											value: form.notes,
											onChange: (e) => setForm({
												...form,
												notes: e.target.value
											})
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setOpen(false),
								children: lang === "ar" ? "إلغاء" : "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								disabled: !form.patient_id || create.isPending,
								onClick: () => create.mutate(void 0),
								children: create.isPending ? lang === "ar" ? "جاري الحفظ..." : "Saving..." : lang === "ar" ? "حفظ" : "Save"
							})] })
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: appointments.error ?? departments.error ?? doctors.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0 overflow-x-auto",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "لا مواعيد في هذا اليوم." : "No appointments for this day."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "المريض" : "Patient" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الطبيب" : "Doctor" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "القسم" : "Department" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "التاريخ" : "Date" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الوقت" : "Time" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الحالة" : "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "text-end",
						children: lang === "ar" ? "الإجراءات" : "Actions"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((item) => {
					const patient = rel(item, "patients");
					const doctor = rel(item, "users");
					const department = rel(item, "departments");
					const dateVal = s(item, "appointment_date") || "";
					const [datePart, timePart] = dateVal.includes("T") ? dateVal.split("T") : [dateVal, ""];
					const storedAppointmentTime = s(item, "appointment_time");
					const formattedTime = storedAppointmentTime ? storedAppointmentTime.substring(0, 5) : timePart ? timePart.substring(0, 5) : "—";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
							className: "font-medium whitespace-nowrap",
							children: [s(patient, "full_name") || "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ms-2 text-xs text-muted-foreground",
								dir: "ltr",
								children: s(patient, "mrn")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "whitespace-nowrap",
							children: s(doctor, "full_name") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "whitespace-nowrap",
							children: lang === "ar" ? s(department, "name_ar") || s(department, "name") || "—" : s(department, "name") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							className: "whitespace-nowrap font-mono text-xs",
							children: datePart || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							className: "whitespace-nowrap font-mono text-xs font-bold text-primary",
							children: formattedTime
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(item, "status") }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-end whitespace-nowrap",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								className: "text-destructive hover:text-destructive",
								disabled: deleteAppointment.isPending,
								onClick: () => {
									if (confirm(lang === "ar" ? "هل أنت متأكد من حذف هذا الموعد؟" : "Are you sure you want to delete this appointment?")) deleteAppointment.mutate(s(item, "id"));
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						})
					] }, s(item, "id"));
				}) })]
			})
		}) })
	] });
}
//#endregion
export { AppointmentsPage as component };
