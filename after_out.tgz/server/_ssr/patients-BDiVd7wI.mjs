import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as rpc, l as useSave, o as s, s as usePagedRows } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang } from "./router-CIKlg6Xn.mjs";
import { C as Plus, E as Phone, at as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { C as SearchField, O as Toolbar, S as RecordRow, _ as PageHeader, a as Empty, b as PermissionGate, c as Field, d as Input, g as NoResults, n as Button, o as ErrorBox, p as LoadingRows, r as DataPanel, u as InitialAvatar, y as Pager } from "./kit-BmCdZVQb.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-ChVCEi1n.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-CV8Xfquv.mjs";
import { a as formatDate, i as calcAge } from "./medical-CD1sc5il.mjs";
import { a as useDebounced, i as searchPatientsPaged } from "./search-CZ_9AvM8.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-vwCASk5X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/patients-BDiVd7wI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 20;
function emptyForm() {
	return {
		full_name: "",
		phone: "",
		gender: "male",
		date_of_birth: "",
		national_id: ""
	};
}
function PatientsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "patients.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientsPageInner, {})
	});
}
function PatientsPageInner() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [page, setPage] = (0, import_react.useState)(1);
	const [search, setSearch] = (0, import_react.useState)("");
	const debouncedSearch = useDebounced(search, 300);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(emptyForm());
	const list = usePagedRows(["patients", debouncedSearch], ({ from, to }) => searchPatientsPaged({
		term: debouncedSearch,
		from,
		to
	}), page, PAGE_SIZE);
	const create = useSave(async () => {
		if (!form.full_name.trim()) throw new Error(t("full_name"));
		const mrn = await rpc("next_mrn");
		const { error } = await supabase.from("patients").insert({
			mrn,
			full_name: form.full_name.trim(),
			phone: form.phone || null,
			gender: form.gender || null,
			date_of_birth: form.date_of_birth || null,
			national_id: form.national_id || null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["patients"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm(emptyForm());
		}
	});
	const rows = list.rows;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: t("clinical"),
				title: t("patients"),
				subtitle: list.count != null ? `${list.count} ${t("records")}` : t("register_patient"),
				children: can("patients.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
								" ",
								t("add")
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("register_patient") }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: `${t("full_name")} *`,
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										required: true,
										"aria-required": "true",
										value: form.full_name,
										onChange: (e) => setForm({
											...form,
											full_name: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("phone"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										dir: "ltr",
										value: form.phone,
										onChange: (e) => setForm({
											...form,
											phone: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("gender"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.gender,
										onValueChange: (v) => setForm({
											...form,
											gender: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "male",
											children: t("male")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "female",
											children: t("female")
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("dob"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										dir: "ltr",
										value: form.date_of_birth,
										onChange: (e) => setForm({
											...form,
											date_of_birth: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("national_id"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										dir: "ltr",
										value: form.national_id,
										onChange: (e) => setForm({
											...form,
											national_id: e.target.value
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setOpen(false),
							children: t("cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !form.full_name.trim() || create.isPending,
							onClick: () => create.mutate(void 0),
							children: create.isPending ? t("saving") : t("save")
						})] })
					] })]
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toolbar, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchField, {
				value: search,
				onChange: (value) => {
					setSearch(value);
					setPage(1);
				},
				placeholder: t("search")
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingRows, { count: 6 }) : rows.length === 0 && debouncedSearch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoResults, { onClear: () => {
				setSearch("");
				setPage(1);
			} }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: t("no_data"),
				description: lang === "ar" ? "لا يوجد مرضى مطابقون. أضف مريضاً جديداً أو غيّر البحث." : "No matching patients. Add a new patient or refine your search."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-border sm:hidden",
				children: rows.map((patient) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordRow, {
					main: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/patients/$patientId",
						params: { patientId: s(patient, "id") },
						className: "block min-w-0 rounded-md outline-none focus-visible:ring-2 focus-visible:ring-ring",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InitialAvatar, { name: s(patient, "full_name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-semibold",
										children: s(patient, "full_name")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										dir: "ltr",
										children: [
											s(patient, "mrn") || "—",
											" · ",
											s(patient, "phone") || "—"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-0.5 text-xs text-muted-foreground",
										children: [
											calcAge(s(patient, "date_of_birth")) ?? "—",
											" ·",
											" ",
											t(s(patient, "gender"))
										]
									})
								]
							})]
						})
					}),
					trailing: can("visits.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "icon",
						"aria-label": t("new_visit"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/visits",
							search: { patient: s(patient, "id") },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
						className: "size-4 text-muted-foreground",
						"aria-hidden": true
					})
				}, s(patient, "id")))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto sm:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("mrn") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("full_name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("phone") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("age") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							className: "font-mono text-xs",
							children: s(p, "mrn") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/patients/$patientId",
								params: { patientId: s(p, "id") },
								className: "hover:underline",
								children: s(p, "full_name")
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(p, "phone") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3" }),
									" ",
									s(p, "phone")
								]
							}) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: calcAge(s(p, "date_of_birth")) ?? "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: formatDate(s(p, "created_at"))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "no-print text-end",
							children: can("visits.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/visits",
									search: { patient: s(p, "id") },
									title: t("new_visit"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }),
										" ",
										t("new_visit")
									]
								})
							}) : null
						})
					] }, s(p, "id"))) })]
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				page: list.page,
				pageCount: list.pageCount,
				count: list.count,
				pageSize: PAGE_SIZE,
				hasPrev: list.hasPrev,
				hasNext: list.hasNext,
				isFetching: list.isFetching,
				onPrev: () => setPage((p) => Math.max(1, p - 1)),
				onNext: () => setPage((p) => p + 1)
			})] }) })
		]
	});
}
//#endregion
export { PatientsPage as component };
