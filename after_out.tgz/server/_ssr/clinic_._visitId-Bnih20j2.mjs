import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as supabase } from "./supabase-B2ycSfIQ.mjs";
import { a as rpc, c as useRows, i as rel$3, l as useSave, o as s, r as n, u as useSettings } from "./db-Ckpr7291.mjs";
import { a as useAuth, i as useLang, n as Route$2 } from "./router-BiMGT4Sf.mjs";
import { g as Search, q as CircleCheck, st as ArrowLeft, t as X, x as Receipt } from "../_libs/lucide-react.mjs";
import { D as Textarea, E as StatusBadge, a as Empty, b as PermissionGate, d as Input, f as Loading, k as buttonVariants, n as Button } from "./kit-asLB5pSR.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BYYnhUtQ.mjs";
import { a as formatDate, i as calcAge, s as money } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DcyYd86X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/clinic_._visitId-Bnih20j2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Roshan Health Hub
* Clinical consultation quick-entry options.
*
* Keep these values centralized so the consultation UI can use
* consistent structured choices instead of free-text entry wherever possible.
*/
var QUICK_COMPLAINTS = [
	{
		value: "fever",
		label: "Fever",
		labelAr: "حمى"
	},
	{
		value: "headache",
		label: "Headache",
		labelAr: "صداع"
	},
	{
		value: "dizziness",
		label: "Dizziness",
		labelAr: "دوخة"
	},
	{
		value: "fatigue",
		label: "Fatigue",
		labelAr: "إرهاق"
	},
	{
		value: "cough",
		label: "Cough",
		labelAr: "سعال"
	},
	{
		value: "shortness_of_breath",
		label: "Shortness of breath",
		labelAr: "ضيق التنفس"
	},
	{
		value: "chest_pain",
		label: "Chest pain",
		labelAr: "ألم الصدر"
	},
	{
		value: "palpitations",
		label: "Palpitations",
		labelAr: "خفقان"
	},
	{
		value: "abdominal_pain",
		label: "Abdominal pain",
		labelAr: "ألم البطن"
	},
	{
		value: "vomiting",
		label: "Vomiting",
		labelAr: "قيء"
	},
	{
		value: "diarrhea",
		label: "Diarrhea",
		labelAr: "إسهال"
	},
	{
		value: "constipation",
		label: "Constipation",
		labelAr: "إمساك"
	},
	{
		value: "nausea",
		label: "Nausea",
		labelAr: "غثيان"
	},
	{
		value: "back_pain",
		label: "Back pain",
		labelAr: "ألم الظهر"
	},
	{
		value: "joint_pain",
		label: "Joint pain",
		labelAr: "ألم المفاصل"
	},
	{
		value: "muscle_pain",
		label: "Muscle pain",
		labelAr: "ألم العضلات"
	},
	{
		value: "sore_throat",
		label: "Sore throat",
		labelAr: "التهاب الحلق"
	},
	{
		value: "runny_nose",
		label: "Runny nose",
		labelAr: "رشح"
	},
	{
		value: "nasal_congestion",
		label: "Nasal congestion",
		labelAr: "احتقان الأنف"
	},
	{
		value: "ear_pain",
		label: "Ear pain",
		labelAr: "ألم الأذن"
	},
	{
		value: "toothache",
		label: "Toothache",
		labelAr: "ألم الأسنان"
	},
	{
		value: "skin_rash",
		label: "Skin rash",
		labelAr: "طفح جلدي"
	},
	{
		value: "itching",
		label: "Itching",
		labelAr: "حكة"
	},
	{
		value: "dysuria",
		label: "Dysuria",
		labelAr: "عسر التبول"
	},
	{
		value: "frequency",
		label: "Urinary frequency",
		labelAr: "كثرة التبول"
	},
	{
		value: "hematuria",
		label: "Hematuria",
		labelAr: "دم في البول"
	},
	{
		value: "vaginal_bleeding",
		label: "Vaginal bleeding",
		labelAr: "نزيف مهبلي"
	},
	{
		value: "vaginal_discharge",
		label: "Vaginal discharge",
		labelAr: "إفرازات مهبلية"
	},
	{
		value: "pelvic_pain",
		label: "Pelvic pain",
		labelAr: "ألم الحوض"
	},
	{
		value: "menstrual_problem",
		label: "Menstrual problem",
		labelAr: "اضطراب الدورة الشهرية"
	},
	{
		value: "pregnancy_followup",
		label: "Pregnancy follow-up",
		labelAr: "متابعة الحمل"
	},
	{
		value: "poor_appetite",
		label: "Poor appetite",
		labelAr: "ضعف الشهية"
	},
	{
		value: "weight_loss",
		label: "Weight loss",
		labelAr: "فقدان الوزن"
	},
	{
		value: "weight_gain",
		label: "Weight gain",
		labelAr: "زيادة الوزن"
	},
	{
		value: "edema",
		label: "Edema",
		labelAr: "تورم / وذمة"
	},
	{
		value: "syncope",
		label: "Syncope",
		labelAr: "إغماء"
	},
	{
		value: "seizure",
		label: "Seizure",
		labelAr: "تشنجات"
	},
	{
		value: "weakness",
		label: "Weakness",
		labelAr: "ضعف"
	},
	{
		value: "other",
		label: "Other",
		labelAr: "أخرى"
	}
];
var QUICK_HPI = [
	{
		value: "acute",
		label: "Acute onset",
		labelAr: "بداية حادة"
	},
	{
		value: "subacute",
		label: "Subacute onset",
		labelAr: "بداية تحت حادة"
	},
	{
		value: "chronic",
		label: "Chronic",
		labelAr: "مزمن"
	},
	{
		value: "sudden",
		label: "Sudden onset",
		labelAr: "بداية مفاجئة"
	},
	{
		value: "gradual",
		label: "Gradual onset",
		labelAr: "بداية تدريجية"
	},
	{
		value: "intermittent",
		label: "Intermittent",
		labelAr: "متقطع"
	},
	{
		value: "continuous",
		label: "Continuous",
		labelAr: "مستمر"
	},
	{
		value: "progressive",
		label: "Progressive",
		labelAr: "متفاقم تدريجيًا"
	},
	{
		value: "stable",
		label: "Stable",
		labelAr: "مستقر"
	},
	{
		value: "recurrent",
		label: "Recurrent",
		labelAr: "متكرر"
	},
	{
		value: "worse_at_night",
		label: "Worse at night",
		labelAr: "أسوأ ليلًا"
	},
	{
		value: "worse_with_exertion",
		label: "Worse with exertion",
		labelAr: "يسوء مع المجهود"
	},
	{
		value: "relieved_by_rest",
		label: "Relieved by rest",
		labelAr: "يتحسن بالراحة"
	},
	{
		value: "associated_fever",
		label: "Associated fever",
		labelAr: "مصاحب بحمى"
	},
	{
		value: "associated_vomiting",
		label: "Associated vomiting",
		labelAr: "مصاحب بقيء"
	},
	{
		value: "associated_diarrhea",
		label: "Associated diarrhea",
		labelAr: "مصاحب بإسهال"
	},
	{
		value: "no_red_flags",
		label: "No reported red flags",
		labelAr: "لا توجد علامات خطورة مذكورة"
	}
];
var QUICK_EXAM = [
	{
		value: "well_appearing",
		label: "Well appearing",
		labelAr: "يبدو بحالة جيدة"
	},
	{
		value: "ill_appearing",
		label: "Ill appearing",
		labelAr: "يبدو مريضًا"
	},
	{
		value: "pale",
		label: "Pale",
		labelAr: "شحوب"
	},
	{
		value: "jaundiced",
		label: "Jaundiced",
		labelAr: "يرقان"
	},
	{
		value: "cyanosed",
		label: "Cyanosed",
		labelAr: "زرقة"
	},
	{
		value: "dehydrated",
		label: "Dehydrated",
		labelAr: "جفاف"
	},
	{
		value: "febrile",
		label: "Febrile",
		labelAr: "محموم"
	},
	{
		value: "tachycardic",
		label: "Tachycardic",
		labelAr: "تسرع قلب"
	},
	{
		value: "tachypneic",
		label: "Tachypneic",
		labelAr: "تسرع تنفس"
	},
	{
		value: "hypertensive",
		label: "Hypertensive",
		labelAr: "ارتفاع ضغط الدم"
	},
	{
		value: "hypotensive",
		label: "Hypotensive",
		labelAr: "انخفاض ضغط الدم"
	},
	{
		value: "chest_clear",
		label: "Chest clear",
		labelAr: "الصدر سليم بالسماعة"
	},
	{
		value: "wheeze",
		label: "Wheeze",
		labelAr: "صفير"
	},
	{
		value: "crepitations",
		label: "Crepitations",
		labelAr: "خراخر"
	},
	{
		value: "normal_heart_sounds",
		label: "Normal heart sounds",
		labelAr: "أصوات القلب طبيعية"
	},
	{
		value: "murmur",
		label: "Murmur",
		labelAr: "نفخة قلبية"
	},
	{
		value: "soft_abdomen",
		label: "Soft abdomen",
		labelAr: "البطن لين"
	},
	{
		value: "tender_abdomen",
		label: "Abdominal tenderness",
		labelAr: "إيلام بالبطن"
	},
	{
		value: "guarding",
		label: "Guarding",
		labelAr: "تيبس دفاعي"
	},
	{
		value: "edema_present",
		label: "Edema present",
		labelAr: "وجود وذمة"
	},
	{
		value: "neurologically_intact",
		label: "Neurologically intact",
		labelAr: "الفحص العصبي سليم"
	},
	{
		value: "other",
		label: "Other",
		labelAr: "أخرى"
	}
];
var QUICK_ASSESSMENT = [
	{
		value: "viral_urti",
		label: "Viral URTI",
		labelAr: "عدوى فيروسية بالجهاز التنفسي العلوي"
	},
	{
		value: "bacterial_urti",
		label: "Bacterial URTI",
		labelAr: "عدوى بكتيرية بالجهاز التنفسي العلوي"
	},
	{
		value: "acute_bronchitis",
		label: "Acute bronchitis",
		labelAr: "التهاب الشعب الهوائية الحاد"
	},
	{
		value: "pneumonia",
		label: "Pneumonia",
		labelAr: "التهاب رئوي"
	},
	{
		value: "asthma_exacerbation",
		label: "Asthma exacerbation",
		labelAr: "تفاقم الربو"
	},
	{
		value: "gastroenteritis",
		label: "Acute gastroenteritis",
		labelAr: "التهاب المعدة والأمعاء الحاد"
	},
	{
		value: "uti",
		label: "Urinary tract infection",
		labelAr: "التهاب المسالك البولية"
	},
	{
		value: "malaria_suspected",
		label: "Suspected malaria",
		labelAr: "اشتباه ملاريا"
	},
	{
		value: "malaria_confirmed",
		label: "Confirmed malaria",
		labelAr: "ملاريا مؤكدة"
	},
	{
		value: "hypertension",
		label: "Hypertension",
		labelAr: "ارتفاع ضغط الدم"
	},
	{
		value: "diabetes",
		label: "Diabetes mellitus",
		labelAr: "داء السكري"
	},
	{
		value: "migraine",
		label: "Migraine",
		labelAr: "صداع نصفي"
	},
	{
		value: "tension_headache",
		label: "Tension headache",
		labelAr: "صداع توتري"
	},
	{
		value: "musculoskeletal_pain",
		label: "Musculoskeletal pain",
		labelAr: "ألم عضلي هيكلي"
	},
	{
		value: "pregnancy",
		label: "Pregnancy",
		labelAr: "حمل"
	},
	{
		value: "other",
		label: "Other",
		labelAr: "أخرى"
	}
];
var QUICK_PLAN = [
	{
		value: "symptomatic_treatment",
		label: "Symptomatic treatment",
		labelAr: "علاج عرضي"
	},
	{
		value: "oral_hydration",
		label: "Oral hydration",
		labelAr: "إماهة فموية"
	},
	{
		value: "fluids",
		label: "Fluids",
		labelAr: "سوائل"
	},
	{
		value: "rest",
		label: "Rest",
		labelAr: "راحة"
	},
	{
		value: "diet_advice",
		label: "Diet advice",
		labelAr: "نصائح غذائية"
	},
	{
		value: "lifestyle_modification",
		label: "Lifestyle modification",
		labelAr: "تعديل نمط الحياة"
	},
	{
		value: "medication",
		label: "Medication prescribed",
		labelAr: "تم وصف علاج"
	},
	{
		value: "laboratory_tests",
		label: "Laboratory tests",
		labelAr: "فحوصات مخبرية"
	},
	{
		value: "imaging",
		label: "Imaging requested",
		labelAr: "طلب تصوير"
	},
	{
		value: "follow_up",
		label: "Follow-up",
		labelAr: "متابعة"
	},
	{
		value: "referral",
		label: "Referral",
		labelAr: "تحويل"
	},
	{
		value: "emergency_referral",
		label: "Emergency referral",
		labelAr: "تحويل للطوارئ"
	},
	{
		value: "return_if_worse",
		label: "Return if symptoms worsen",
		labelAr: "العودة عند تدهور الأعراض"
	},
	{
		value: "no_medication",
		label: "No medication required",
		labelAr: "لا حاجة لدواء"
	}
];
var DOSAGE_FORMS = [
	{
		value: "tablet",
		label: "Tablet",
		labelAr: "قرص"
	},
	{
		value: "capsule",
		label: "Capsule",
		labelAr: "كبسولة"
	},
	{
		value: "syrup",
		label: "Syrup",
		labelAr: "شراب"
	},
	{
		value: "suspension",
		label: "Suspension",
		labelAr: "معلق"
	},
	{
		value: "drops",
		label: "Drops",
		labelAr: "قطرات"
	},
	{
		value: "injection",
		label: "Injection",
		labelAr: "حقن"
	},
	{
		value: "cream",
		label: "Cream",
		labelAr: "كريم"
	},
	{
		value: "ointment",
		label: "Ointment",
		labelAr: "مرهم"
	},
	{
		value: "gel",
		label: "Gel",
		labelAr: "جل"
	},
	{
		value: "lotion",
		label: "Lotion",
		labelAr: "لوشن"
	},
	{
		value: "suppository",
		label: "Suppository",
		labelAr: "تحاميل"
	},
	{
		value: "inhaler",
		label: "Inhaler",
		labelAr: "بخاخ"
	},
	{
		value: "solution",
		label: "Solution",
		labelAr: "محلول"
	},
	{
		value: "sachet",
		label: "Sachet",
		labelAr: "ظرف"
	}
];
var ROUTES = [
	{
		value: "oral",
		label: "Oral",
		labelAr: "عن طريق الفم"
	},
	{
		value: "iv",
		label: "IV",
		labelAr: "وريدي"
	},
	{
		value: "im",
		label: "IM",
		labelAr: "عضلي"
	},
	{
		value: "sc",
		label: "SC",
		labelAr: "تحت الجلد"
	},
	{
		value: "topical",
		label: "Topical",
		labelAr: "موضعي"
	},
	{
		value: "inhaled",
		label: "Inhaled",
		labelAr: "استنشاق"
	},
	{
		value: "nasal",
		label: "Nasal",
		labelAr: "أنفي"
	},
	{
		value: "ophthalmic",
		label: "Ophthalmic",
		labelAr: "عيني"
	},
	{
		value: "otic",
		label: "Otic",
		labelAr: "أذني"
	},
	{
		value: "rectal",
		label: "Rectal",
		labelAr: "شرجي"
	},
	{
		value: "vaginal",
		label: "Vaginal",
		labelAr: "مهبلي"
	}
];
var FREQUENCIES = [
	{
		value: "once_daily",
		label: "Once daily",
		labelAr: "مرة يوميًا"
	},
	{
		value: "twice_daily",
		label: "Twice daily",
		labelAr: "مرتين يوميًا"
	},
	{
		value: "three_daily",
		label: "Three times daily",
		labelAr: "ثلاث مرات يوميًا"
	},
	{
		value: "four_daily",
		label: "Four times daily",
		labelAr: "أربع مرات يوميًا"
	},
	{
		value: "every_4_hours",
		label: "Every 4 hours",
		labelAr: "كل 4 ساعات"
	},
	{
		value: "every_6_hours",
		label: "Every 6 hours",
		labelAr: "كل 6 ساعات"
	},
	{
		value: "every_8_hours",
		label: "Every 8 hours",
		labelAr: "كل 8 ساعات"
	},
	{
		value: "every_12_hours",
		label: "Every 12 hours",
		labelAr: "كل 12 ساعة"
	},
	{
		value: "weekly",
		label: "Once weekly",
		labelAr: "مرة أسبوعيًا"
	},
	{
		value: "prn",
		label: "As needed",
		labelAr: "عند اللزوم"
	},
	{
		value: "stat",
		label: "Immediately",
		labelAr: "فورًا"
	}
];
var DURATIONS = [
	{
		value: "1_day",
		label: "1 day",
		labelAr: "يوم واحد"
	},
	{
		value: "3_days",
		label: "3 days",
		labelAr: "3 أيام"
	},
	{
		value: "5_days",
		label: "5 days",
		labelAr: "5 أيام"
	},
	{
		value: "7_days",
		label: "7 days",
		labelAr: "7 أيام"
	},
	{
		value: "10_days",
		label: "10 days",
		labelAr: "10 أيام"
	},
	{
		value: "14_days",
		label: "14 days",
		labelAr: "14 يومًا"
	},
	{
		value: "21_days",
		label: "21 days",
		labelAr: "21 يومًا"
	},
	{
		value: "30_days",
		label: "30 days",
		labelAr: "30 يومًا"
	},
	{
		value: "60_days",
		label: "60 days",
		labelAr: "60 يومًا"
	},
	{
		value: "90_days",
		label: "90 يومًا",
		labelAr: "90 يومًا"
	},
	{
		value: "ongoing",
		label: "Ongoing",
		labelAr: "مستمر"
	}
];
var DOSES = [
	{
		value: "1",
		label: "1",
		labelAr: "1"
	},
	{
		value: "2",
		label: "2",
		labelAr: "2"
	},
	{
		value: "2.5",
		label: "2.5",
		labelAr: "2.5"
	},
	{
		value: "5",
		label: "5",
		labelAr: "5"
	},
	{
		value: "7.5",
		label: "7.5",
		labelAr: "7.5"
	},
	{
		value: "10",
		label: "10",
		labelAr: "10"
	},
	{
		value: "15",
		label: "15",
		labelAr: "15"
	},
	{
		value: "20",
		label: "20",
		labelAr: "20"
	},
	{
		value: "25",
		label: "25",
		labelAr: "25"
	},
	{
		value: "50",
		label: "50",
		labelAr: "50"
	},
	{
		value: "100",
		label: "100",
		labelAr: "100"
	}
];
var FIELDS = [
	[
		"chief_complaint",
		"الشكوى الرئيسية / Chief complaint",
		2
	],
	[
		"hpi",
		"تاريخ المرض الحالي / HPI",
		4
	],
	[
		"past_medical_history",
		"التاريخ المرضي السابق / PMH",
		3
	],
	[
		"drug_history",
		"الأدوية الحالية / Drug history",
		3
	],
	[
		"allergy_history",
		"الحساسيات / Allergies",
		2
	],
	[
		"examination",
		"الفحص السريري / Examination",
		4
	],
	[
		"assessment",
		"التقييم / Assessment",
		3
	],
	[
		"plan",
		"الخطة / Plan",
		4
	]
];
function appendText(current, value) {
	if (!value) return current;
	if (!current.trim()) return value;
	if (current.split(/\n+/).map((x) => x.trim()).filter(Boolean).includes(value)) return current;
	return `${current.trim()}\n${value}`;
}
function QuickChips({ items, lang, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1.5",
		children: items.map((item) => {
			const label = lang === "ar" ? item.labelAr : item.label;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "sm",
				variant: "outline",
				className: "h-8 text-xs",
				onClick: () => onPick(label),
				children: label
			}, item.value);
		})
	});
}
function ClinicalNoteTab({ visitId }) {
	const { user } = useAuth();
	const { lang } = useLang();
	const [form, setForm] = (0, import_react.useState)({});
	const [diagnosisSearch, setDiagnosisSearch] = (0, import_react.useState)("");
	const noteQ = useRows(["clinical-note", visitId], () => supabase.from("clinical_notes").select("*").eq("visit_id", visitId).is("deleted_at", null).order("created_at", { ascending: false }).limit(1));
	const diagnosesQ = useRows(["diagnoses", visitId], () => supabase.from("diagnoses").select("*").eq("visit_id", visitId).is("deleted_at", null).order("created_at"));
	(0, import_react.useEffect)(() => {
		const r = (noteQ.data ?? [])[0];
		if (!r) return;
		const next = {};
		for (const [key, value] of Object.entries(r)) next[key] = value == null ? "" : String(value);
		setForm(next);
	}, [noteQ.data]);
	const save = useSave(async () => {
		const existing = (noteQ.data ?? [])[0];
		const payload = {
			visit_id: visitId,
			chief_complaint: form["chief_complaint"] || null,
			hpi: form["hpi"] || null,
			past_medical_history: form["past_medical_history"] || null,
			drug_history: form["drug_history"] || null,
			allergy_history: form["allergy_history"] || null,
			examination: form["examination"] || null,
			assessment: form["assessment"] || null,
			plan: form["plan"] || null,
			doctor_id: user?.id ?? null,
			updated_by: user?.id ?? null
		};
		const { error } = await (existing ? supabase.from("clinical_notes").update(payload).eq("id", s(existing, "id")) : supabase.from("clinical_notes").insert({
			...payload,
			created_by: user?.id ?? null
		}));
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["clinical-note", visitId]],
		successMessage: lang === "ar" ? "تم حفظ الملاحظات" : "Clinical note saved"
	});
	const addDiagnosis = useSave(async () => {
		const name = (form["new_diagnosis"] || "").trim();
		if (!name) throw new Error(lang === "ar" ? "أدخل التشخيص" : "Enter a diagnosis");
		const { error } = await supabase.from("diagnoses").insert({
			visit_id: visitId,
			diagnosis_name: name,
			icd10_code: form["icd10"] || null,
			diagnosis_type: "clinical",
			is_primary: (diagnosesQ.data ?? []).length === 0,
			doctor_id: user?.id ?? null,
			created_by: user?.id ?? null
		});
		if (error) throw new Error(error.message);
		setForm({
			...form,
			new_diagnosis: "",
			icd10: ""
		});
		return null;
	}, {
		invalidate: [["diagnoses", visitId]],
		successMessage: lang === "ar" ? "تم حفظ التشخيص" : "Diagnosis saved"
	});
	const set = (key, value) => setForm((prev) => ({
		...prev,
		[key]: value
	}));
	const diagnoses = (0, import_react.useMemo)(() => diagnosesQ.data ?? [], [diagnosesQ.data]);
	const filteredDiagnoses = (0, import_react.useMemo)(() => {
		const term = diagnosisSearch.trim().toLowerCase();
		if (!term) return diagnoses;
		return diagnoses.filter((d) => `${s(d, "diagnosis_name")} ${s(d, "icd10_code")}`.toLowerCase().includes(term));
	}, [diagnoses, diagnosisSearch]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		dir: "auto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
			className: "text-base",
			children: lang === "ar" ? "التقييم السريري السريع" : "Rapid clinical documentation"
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-4 p-4",
			children: [FIELDS.map(([key, label, rows]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						children: label
					}),
					key === "chief_complaint" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickChips, {
						items: QUICK_COMPLAINTS,
						lang,
						onPick: (v) => set(key, appendText(form[key] ?? "", v))
					}),
					key === "hpi" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickChips, {
						items: QUICK_HPI,
						lang,
						onPick: (v) => set(key, appendText(form[key] ?? "", v))
					}),
					key === "examination" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickChips, {
						items: QUICK_EXAM,
						lang,
						onPick: (v) => set(key, appendText(form[key] ?? "", v))
					}),
					key === "assessment" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickChips, {
						items: QUICK_ASSESSMENT,
						lang,
						onPick: (v) => set(key, appendText(form[key] ?? "", v))
					}),
					key === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickChips, {
						items: QUICK_PLAN,
						lang,
						onPick: (v) => set(key, appendText(form[key] ?? "", v))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form[key] ?? "",
						onChange: (e) => set(key, e.target.value),
						rows,
						placeholder: lang === "ar" ? "يمكنك الاختيار من الأزرار أعلاه أو الكتابة يدويًا..." : "Pick quick phrases above or type freely..."
					})
				]
			}, key)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: save.isPending,
					onClick: () => save.mutate(void 0),
					children: save.isPending ? lang === "ar" ? "جاري الحفظ..." : "Saving..." : lang === "ar" ? "حفظ الملاحظات" : "Save note"
				})
			})]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
			className: "text-base",
			children: lang === "ar" ? "التشخيصات" : "Diagnoses"
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-4 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-[1fr_180px_auto]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: lang === "ar" ? "التشخيص" : "Diagnosis",
							value: form["new_diagnosis"] ?? "",
							onChange: (e) => set("new_diagnosis", e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							dir: "ltr",
							placeholder: "ICD-10",
							value: form["icd10"] ?? "",
							onChange: (e) => set("icd10", e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							disabled: addDiagnosis.isPending,
							onClick: () => addDiagnosis.mutate(void 0),
							children: lang === "ar" ? "إضافة" : "Add"
						})
					]
				}),
				diagnoses.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: diagnosisSearch,
					onChange: (e) => setDiagnosisSearch(e.target.value),
					placeholder: lang === "ar" ? "بحث داخل تشخيصات الزيارة" : "Search visit diagnoses"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [filteredDiagnoses.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-lg border p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: s(d, "diagnosis_name")
						}), s(d, "icd10_code") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							dir: "ltr",
							children: s(d, "icd10_code")
						})] }), s(d, "is_primary") === "true" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary/10 px-2 py-1 text-xs text-primary",
							children: lang === "ar" ? "أساسي" : "Primary"
						})]
					}, s(d, "id"))), !diagnoses.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground",
						children: lang === "ar" ? "لا توجد تشخيصات بعد" : "No diagnoses yet"
					})]
				})
			]
		})] })]
	});
}
/** Clinical danger ranges for adult vitals — drives the red highlight. */
var DANGER = {
	bp_systolic: (v) => v < 90 || v >= 180,
	bp_diastolic: (v) => v < 60 || v >= 110,
	pulse: (v) => v < 50 || v > 120,
	respiratory_rate: (v) => v < 10 || v > 24,
	temperature: (v) => v < 35 || v >= 38.5,
	spo2: (v) => v < 92
};
function isDanger(key, raw) {
	const rule = DANGER[key];
	if (!rule || !raw.trim()) return false;
	const value = Number(raw);
	return Number.isFinite(value) && value > 0 && rule(value);
}
function VitalsTab({ visitId }) {
	const { user } = useAuth();
	const { lang } = useLang();
	const [f, setF] = (0, import_react.useState)({});
	const q = useRows(["vitals", visitId], () => supabase.from("vitals").select("*").eq("visit_id", visitId).is("deleted_at", null).order("created_at", { ascending: false }).limit(1));
	(0, import_react.useEffect)(() => {
		const row = (q.data ?? [])[0];
		if (!row) return;
		const next = {};
		for (const [key, value] of Object.entries(row)) next[key] = value == null ? "" : String(value);
		setF(next);
	}, [q.data]);
	const set = (key, value) => setF((prev) => ({
		...prev,
		[key]: value
	}));
	const get = (key) => f[key] ?? "";
	const bmi = (0, import_react.useMemo)(() => {
		const w = Number(get("weight"));
		const h = Number(get("height"));
		return w > 0 && h > 0 ? (w / (h / 100) ** 2).toFixed(1) : "";
	}, [f["weight"], f["height"]]);
	const lmp = get("lmp");
	const edd = lmp ? (() => {
		const d = /* @__PURE__ */ new Date(`${lmp}T00:00:00`);
		d.setDate(d.getDate() + 280);
		return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
	})() : "";
	const ga = lmp ? Math.max(0, Math.floor((Date.now() - (/* @__PURE__ */ new Date(`${lmp}T00:00:00`)).getTime()) / 864e5)) : 0;
	const num = (key) => {
		const v = Number(get(key));
		return Number.isFinite(v) && get(key).trim() !== "" ? v : null;
	};
	const save = useSave(async () => {
		const existing = (q.data ?? [])[0];
		const payload = {
			visit_id: visitId,
			patient_id: get("patient_id") || null,
			bp_systolic: num("bp_systolic"),
			bp_diastolic: num("bp_diastolic"),
			systolic_bp: num("bp_systolic"),
			diastolic_bp: num("bp_diastolic"),
			pulse: num("pulse"),
			respiratory_rate: num("respiratory_rate"),
			temperature: num("temperature"),
			spo2: num("spo2"),
			weight: num("weight"),
			height: num("height"),
			bmi: bmi ? Number(bmi) : null,
			lmp: lmp || null,
			edd: edd || null,
			gestational_age_days: lmp ? ga : null,
			recorded_by: user?.id ?? null,
			updated_by: user?.id ?? null
		};
		const { error } = await (existing ? supabase.from("vitals").update(payload).eq("id", s(existing, "id")) : supabase.from("vitals").insert({
			...payload,
			created_by: user?.id ?? null
		}));
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["vitals", visitId]],
		successMessage: lang === "ar" ? "تم حفظ العلامات الحيوية" : "Vitals saved"
	});
	const fields = [
		{
			key: "bp_systolic",
			label: lang === "ar" ? "الضغط الانقباضي" : "BP systolic",
			unit: "mmHg",
			placeholder: "120"
		},
		{
			key: "bp_diastolic",
			label: lang === "ar" ? "الضغط الانبساطي" : "BP diastolic",
			unit: "mmHg",
			placeholder: "80"
		},
		{
			key: "pulse",
			label: lang === "ar" ? "النبض" : "Pulse",
			unit: "bpm",
			placeholder: "78"
		},
		{
			key: "respiratory_rate",
			label: lang === "ar" ? "معدل التنفس" : "Respiratory rate",
			unit: "/min",
			placeholder: "16"
		},
		{
			key: "temperature",
			label: lang === "ar" ? "الحرارة" : "Temperature",
			unit: "°C",
			placeholder: "36.8",
			step: "0.1"
		},
		{
			key: "spo2",
			label: "SpO₂",
			unit: "%",
			placeholder: "98"
		},
		{
			key: "weight",
			label: lang === "ar" ? "الوزن" : "Weight",
			unit: "kg",
			placeholder: "70",
			step: "0.1"
		},
		{
			key: "height",
			label: lang === "ar" ? "الطول" : "Height",
			unit: "cm",
			placeholder: "170"
		}
	];
	const anyDanger = fields.some((x) => isDanger(x.key, get(x.key)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-4 p-4",
		children: [
			anyDanger ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm font-medium text-destructive",
				children: lang === "ar" ? "تحذير: توجد قيم حيوية خارج النطاق الآمن — راجع القيم المظللة بالأحمر." : "Warning: one or more vitals are outside the safe range — review the values highlighted in red."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					fields.map((x) => {
						const danger = isDanger(x.key, get(x.key));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium",
								children: [
									x.label,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground",
										children: [
											"(",
											x.unit,
											")"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								dir: "ltr",
								type: "number",
								step: x.step ?? "1",
								placeholder: x.placeholder,
								"aria-invalid": danger,
								value: get(x.key),
								onChange: (e) => set(x.key, e.target.value),
								className: danger ? "border-destructive bg-destructive/10 focus-visible:ring-destructive" : void 0
							})]
						}, x.key);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border p-2 text-sm",
						children: ["BMI", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-semibold",
							children: bmi || "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border p-3 sm:col-span-2 lg:col-span-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 font-medium",
							children: lang === "ar" ? "حسابات الحمل" : "Obstetric calculation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "space-y-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "LMP"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										dir: "ltr",
										type: "date",
										value: lmp,
										onChange: (e) => set("lmp", e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm",
									children: ["EDD", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										dir: "ltr",
										className: "font-semibold",
										children: edd || "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm",
									children: ["GA", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-semibold",
										children: lmp ? `${Math.floor(ga / 7)}w ${ga % 7}d` : "—"
									})]
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: save.isPending,
					onClick: () => save.mutate(void 0),
					children: save.isPending ? lang === "ar" ? "جاري الحفظ..." : "Saving..." : lang === "ar" ? "حفظ العلامات الحيوية" : "Save vitals"
				})
			})
		]
	}) });
}
var CATEGORY_ORDER = [
	"Hematology",
	"Clinical Chemistry",
	"Hormones",
	"Microbiology",
	"Serology",
	"Immunology",
	"Urinalysis",
	"Parasitology",
	"Other"
];
var CATEGORY_AR = {
	Hematology: "أمراض الدم",
	"Clinical Chemistry": "الكيمياء السريرية",
	Hormones: "الهرمونات",
	Microbiology: "الأحياء الدقيقة",
	Serology: "السيرولوجي",
	Immunology: "المناعة",
	Urinalysis: "تحليل البول",
	Parasitology: "الطفيليات",
	Other: "أخرى"
};
function normalizeCategory(value) {
	const v = value.trim();
	if (!v) return "Other";
	const lower = v.toLowerCase();
	if (lower.includes("hemat") || lower.includes("cbc") || lower.includes("blood")) return "Hematology";
	if (lower.includes("chem") || lower.includes("liver") || lower.includes("renal") || lower.includes("kidney") || lower.includes("lipid")) return "Clinical Chemistry";
	if (lower.includes("horm")) return "Hormones";
	if (lower.includes("micro") || lower.includes("culture")) return "Microbiology";
	if (lower.includes("sero") || lower.includes("viral") || lower.includes("hepat") || lower.includes("hiv")) return "Serology";
	if (lower.includes("immun")) return "Immunology";
	if (lower.includes("urine") || lower.includes("urin")) return "Urinalysis";
	if (lower.includes("paras") || lower.includes("malaria")) return "Parasitology";
	return v;
}
function LaboratoryTab({ visitId }) {
	const { user } = useAuth();
	const { lang } = useLang();
	const [search, setSearch] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [priority, setPriority] = (0, import_react.useState)("normal");
	const [notes, setNotes] = (0, import_react.useState)("");
	const visit = (useRows(["clinic-visit", visitId], () => supabase.from("visits").select("id,patient_id,patients(id,full_name)").eq("id", visitId).limit(1)).data ?? [])[0];
	const patient = rel$2(visit, "patients");
	const testsQ = useRows(["clinic-lab-tests", search], () => {
		let q = supabase.from("lab_tests").select("id,name,name_ar,code,price,category").eq("active", true).is("deleted_at", null).order("name").limit(300);
		const term = search.replace(/[,()%]/g, "").trim();
		if (term) q = q.or(`name.ilike.%${term}%,name_ar.ilike.%${term}%,code.ilike.%${term}%,category.ilike.%${term}%`);
		return q;
	});
	const tests = (0, import_react.useMemo)(() => testsQ.data ?? [], [testsQ.data]);
	const categories = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		for (const test of tests) set.add(normalizeCategory(s(test, "category")));
		return [
			"all",
			...CATEGORY_ORDER.filter((x) => x !== "Other" && set.has(x)),
			...Array.from(set).filter((x) => !CATEGORY_ORDER.includes(x) && x !== "all")
		];
	}, [tests]);
	const visible = (0, import_react.useMemo)(() => tests.filter((test) => category === "all" || normalizeCategory(s(test, "category")) === category), [tests, category]);
	const selectedIds = new Set(selected.map((x) => s(x, "id")));
	const profiles = (0, import_react.useMemo)(() => {
		const by = (words) => tests.filter((t) => words.some((w) => `${s(t, "name")} ${s(t, "name_ar")} ${s(t, "code")}`.toLowerCase().includes(w)));
		return [
			{
				id: "cbc",
				label: lang === "ar" ? "CBC / صورة الدم" : "CBC profile",
				tests: by(["cbc", "complete blood count"])
			},
			{
				id: "renal",
				label: lang === "ar" ? "وظائف الكلى" : "Renal profile",
				tests: by([
					"creatinine",
					"urea",
					"renal",
					"kidney"
				])
			},
			{
				id: "liver",
				label: lang === "ar" ? "وظائف الكبد" : "Liver profile",
				tests: by([
					"lft",
					"alt",
					"ast",
					"bilirubin",
					"liver"
				])
			},
			{
				id: "glucose",
				label: lang === "ar" ? "السكري" : "Glucose profile",
				tests: by([
					"glucose",
					"fbs",
					"rbs",
					"hba1c"
				])
			}
		].filter((p) => p.tests.length);
	}, [tests, lang]);
	const toggle = (test) => setSelected((current) => selectedIds.has(s(test, "id")) ? current.filter((x) => s(x, "id") !== s(test, "id")) : [...current, test]);
	const addProfile = (profile) => setSelected((current) => {
		const map = new Map(current.map((x) => [s(x, "id"), x]));
		profile.tests.forEach((x) => map.set(s(x, "id"), x));
		return Array.from(map.values());
	});
	const create = useSave(async () => {
		if (!s(patient, "id")) throw new Error(lang === "ar" ? "المريض غير موجود" : "Patient not found");
		if (!selected.length) throw new Error(lang === "ar" ? "اختر فحصاً واحداً على الأقل" : "Select at least one test");
		const { data: order, error } = await supabase.from("lab_orders").insert({
			patient_id: s(patient, "id"),
			visit_id: visitId,
			ordered_by: user?.id ?? null,
			status: "ordered",
			priority,
			notes: notes || null,
			created_by: user?.id ?? null
		}).select("id").single();
		if (error) throw new Error(error.message);
		const items = selected.map((t) => ({
			order_id: order.id,
			test_id: s(t, "id"),
			price: n(t, "price"),
			created_by: user?.id ?? null
		}));
		const { error: itemError } = await supabase.from("lab_order_items").insert(items);
		if (itemError) throw new Error(itemError.message);
		const total = selected.reduce((sum, t) => sum + n(t, "price"), 0);
		if (total > 0) {
			const invoiceNumber = await rpc("next_invoice_number");
			const { data: inv, error: invError } = await supabase.from("invoices").insert({
				invoice_number: invoiceNumber,
				patient_id: s(patient, "id"),
				visit_id: visitId,
				invoice_date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
				total_amount: total,
				subtotal: total,
				discount_amount: 0,
				net_amount: total,
				paid_amount: 0,
				status: "unpaid",
				payment_status: "unpaid",
				created_by: user?.id ?? null
			}).select("id").single();
			if (invError) throw new Error(invError.message);
			const rows = selected.map((t) => ({
				invoice_id: inv.id,
				item_type: "laboratory",
				item_name: s(t, "name"),
				quantity: 1,
				unit_price: n(t, "price"),
				total_price: n(t, "price"),
				item_id: s(t, "id"),
				created_by: user?.id ?? null
			}));
			const { error: invoiceItemsError } = await supabase.from("invoice_items").insert(rows);
			if (invoiceItemsError) throw new Error(invoiceItemsError.message);
		}
		setSelected([]);
		setNotes("");
		return order.id;
	}, {
		invalidate: [
			["lab-orders"],
			["lab-orders", visitId],
			["patient-labs", s(patient, "id")],
			["invoices"]
		],
		successMessage: lang === "ar" ? "تم إرسال طلب المختبر وإنشاء الفاتورة" : "Lab order created and invoice generated"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
		className: "text-base",
		children: lang === "ar" ? "اختيار الفحوصات" : "Select investigations"
	}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-4 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 lg:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "ps-9",
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: lang === "ar" ? "ابحث باسم الفحص أو الرمز أو التصنيف" : "Search test, code or category"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "rounded-md border bg-background px-3 py-2 text-sm",
					value: category,
					onChange: (e) => setCategory(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: lang === "ar" ? "كل التصنيفات" : "All categories"
					}), categories.filter((x) => x !== "all").map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: x,
						children: lang === "ar" ? CATEGORY_AR[x] ?? x : x
					}, x))]
				})]
			}),
			profiles.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 text-xs font-medium text-muted-foreground",
				children: lang === "ar" ? "حزم سريعة" : "Quick profiles"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: profiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "secondary",
					onClick: () => addProfile(p),
					children: [
						p.label,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ms-1 text-xs opacity-70",
							children: p.tests.length
						})
					]
				}, p.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: categories.filter((x) => x !== "all").map((cat) => {
					const group = visible.filter((t) => normalizeCategory(s(t, "category")) === cat);
					if (!group.length) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b bg-muted/30 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: lang === "ar" ? CATEGORY_AR[cat] ?? cat : cat
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: group.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2 p-2",
							children: group.map((test) => {
								const chosen = selectedIds.has(s(test, "id"));
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => toggle(test),
									className: `rounded-lg border p-3 text-start transition ${chosen ? "border-primary bg-primary/5" : "hover:bg-muted/50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-medium",
											children: lang === "ar" ? s(test, "name_ar") || s(test, "name") : s(test, "name")
										}), chosen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-primary",
											children: "✓"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-1 text-xs text-muted-foreground",
										dir: "ltr",
										children: [
											s(test, "code") || "—",
											" · ",
											n(test, "price")
										]
									})]
								}, s(test, "id"));
							})
						})]
					}, cat);
				})
			}),
			!visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground",
				children: lang === "ar" ? "لا توجد فحوصات مطابقة" : "No matching tests"
			}),
			selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border bg-muted/20 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: lang === "ar" ? `الفحوصات المختارة (${selected.length})` : `Selected tests (${selected.length})`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: () => setSelected([]),
						children: lang === "ar" ? "مسح الكل" : "Clear all"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: selected.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-full border bg-background px-2.5 py-1 text-xs",
						children: [lang === "ar" ? s(t, "name_ar") || s(t, "name") : s(t, "name"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggle(t),
							"aria-label": "remove",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
						})]
					}, s(t, "id")))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: [lang === "ar" ? "الأولوية" : "Priority", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-md border bg-background p-2 font-normal",
						value: priority,
						onChange: (e) => setPriority(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "normal",
							children: lang === "ar" ? "عادي" : "Normal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "urgent",
							children: lang === "ar" ? "عاجل" : "Urgent"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: [lang === "ar" ? "ملاحظات الطلب" : "Order notes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						className: "mt-1 font-normal",
						value: notes,
						onChange: (e) => setNotes(e.target.value)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: create.isPending || !selected.length,
					onClick: () => create.mutate(void 0),
					children: create.isPending ? lang === "ar" ? "جاري الإنشاء..." : "Creating..." : lang === "ar" ? "طلب الفحوصات وإنشاء الفاتورة" : "Order tests & create bill"
				})
			})
		]
	})] });
}
function rel$2(row, key) {
	const x = row?.[key];
	return (Array.isArray(x) ? x[0] : x) || {};
}
function PrescriptionTab({ visitId }) {
	const { user } = useAuth();
	const { lang } = useLang();
	const visitQ = useRows(["clinic-visit", visitId], () => supabase.from("visits").select("id,patient_id,doctor_id,patients(id,full_name)").eq("id", visitId).limit(1));
	const patient = s(rel$1((visitQ.data ?? [])[0], "patients"), "id");
	const medsQ = useRows(["medicines-search"], () => supabase.from("medicines").select("id,name,generic_name,brand_name,strength,dosage_form,selling_price,stock_quantity").eq("active", true).is("deleted_at", null).order("name").limit(500));
	const [form, setForm] = (0, import_react.useState)({
		medicine_id: "",
		name: "",
		dose: "",
		frequency: "",
		duration: "",
		quantity: "1",
		instructions: "",
		dosage_form: "",
		route: ""
	});
	const [items, setItems] = (0, import_react.useState)([]);
	const [external, setExternal] = (0, import_react.useState)(false);
	const [search, setSearch] = (0, import_react.useState)("");
	const medicines = (0, import_react.useMemo)(() => medsQ.data ?? [], [medsQ.data]);
	const filtered = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		if (!q) return medicines.slice(0, 30);
		return medicines.filter((m) => `${s(m, "name")} ${s(m, "generic_name")} ${s(m, "brand_name")} ${s(m, "strength")}`.toLowerCase().includes(q)).slice(0, 30);
	}, [medicines, search]);
	const chooseMedicine = (id) => {
		const m = medicines.find((x) => s(x, "id") === id);
		const formName = m ? s(m, "name") || s(m, "generic_name") : "";
		const dosageForm = m ? s(m, "dosage_form") : "";
		const defaultRoute = dosageForm.toLowerCase().includes("tablet") || dosageForm.toLowerCase().includes("capsule") || dosageForm.toLowerCase().includes("syrup") ? "Oral" : "";
		setForm((p) => ({
			...p,
			medicine_id: id,
			name: formName,
			dosage_form: dosageForm,
			route: defaultRoute
		}));
		setSearch(formName);
	};
	const add = () => {
		if (!form.name.trim() && !form.medicine_id) return;
		setItems((current) => [...current, { ...form }]);
		setForm({
			...form,
			medicine_id: "",
			name: "",
			quantity: "1",
			instructions: ""
		});
		setSearch("");
	};
	const save = useSave(async () => {
		if (!patient) throw new Error(lang === "ar" ? "المريض غير موجود" : "Patient not found");
		if (!items.length) throw new Error(lang === "ar" ? "أضف دواءً واحداً على الأقل" : "Add at least one medicine");
		const { data: rx, error } = await supabase.from("prescriptions").insert({
			patient_id: patient,
			visit_id: visitId,
			prescribed_by: user?.id ?? null,
			doctor_id: user?.id ?? null,
			prescription_type: external ? "external" : "internal",
			is_external: external,
			status: "pending",
			created_by: user?.id ?? null
		}).select("id").single();
		if (error) throw new Error(error.message);
		const rows = items.map((i) => ({
			prescription_id: rx.id,
			medicine_id: i.medicine_id || null,
			medication_name: i.name,
			dose: i.dose || null,
			dosage: i.dose || null,
			frequency: i.frequency || null,
			duration: i.duration || null,
			dosage_form: i.dosage_form || null,
			route: i.route || null,
			quantity: Number(i.quantity) || 1,
			instructions: i.instructions || null,
			unit_price: i.medicine_id ? Number((medsQ.data ?? []).find((m) => s(m, "id") === i.medicine_id)?.["selling_price"]) || 0 : 0,
			created_by: user?.id ?? null
		}));
		const { error: e } = await supabase.from("prescription_items").insert(rows);
		if (e) throw new Error(e.message);
		return null;
	}, {
		invalidate: [["patient-rx", patient], ["prescriptions", visitId]],
		successMessage: lang === "ar" ? "تم حفظ الوصفة" : "Prescription saved"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
		className: "text-base",
		children: lang === "ar" ? "الوصفة الطبية" : "Prescription"
	}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-4 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: external,
					onChange: (e) => setExternal(e.target.checked)
				}), lang === "ar" ? "وصفة خارجية / لن تُصرف من صيدلية المركز" : "External prescription / not dispensed by center"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: search,
					onChange: (e) => setSearch(e.target.value),
					placeholder: lang === "ar" ? "ابحث باسم الدواء أو المادة أو القوة" : "Search medicine, generic or strength"
				}), search && filtered.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute z-20 mt-1 max-h-64 w-full overflow-auto rounded-lg border bg-popover p-1 shadow-lg",
					children: filtered.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center justify-between rounded-md px-3 py-2 text-start text-sm hover:bg-muted",
						onClick: () => chooseMedicine(s(m, "id")),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: s(m, "name") || s(m, "generic_name")
						}), s(m, "strength") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ms-2 text-xs text-muted-foreground",
							children: s(m, "strength")
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: s(m, "stock_quantity") || "0"
						})]
					}, s(m, "id")))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.name,
					onChange: (e) => setForm({
						...form,
						name: e.target.value
					}),
					placeholder: lang === "ar" ? "اسم الدواء" : "Medication name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.dosage_form || "custom",
					onValueChange: (v) => setForm({
						...form,
						dosage_form: v === "custom" ? "" : v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "الشكل الدوائي" : "Dosage form" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [DOSAGE_FORMS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: x.value,
						children: lang === "ar" ? x.labelAr : x.label
					}, x.value)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "custom",
						children: lang === "ar" ? "إدخال يدوي" : "Custom"
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: form.dose || "custom",
						onValueChange: (v) => setForm({
							...form,
							dose: v === "custom" ? "" : v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "الجرعة" : "Dose" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [DOSES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: x.value,
							children: lang === "ar" ? x.labelAr : x.label
						}, x.value)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "custom",
							children: lang === "ar" ? "يدوي" : "Custom"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: form.frequency || "custom",
						onValueChange: (v) => setForm({
							...form,
							frequency: v === "custom" ? "" : v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "التكرار" : "Frequency" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [FREQUENCIES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: x.value,
							children: lang === "ar" ? x.labelAr : x.label
						}, x.value)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "custom",
							children: lang === "ar" ? "يدوي" : "Custom"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: form.duration || "custom",
						onValueChange: (v) => setForm({
							...form,
							duration: v === "custom" ? "" : v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "المدة" : "Duration" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [DURATIONS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: x.value,
							children: lang === "ar" ? x.labelAr : x.label
						}, x.value)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "custom",
							children: lang === "ar" ? "يدوي" : "Custom"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						dir: "ltr",
						type: "number",
						min: "1",
						value: form.quantity,
						onChange: (e) => setForm({
							...form,
							quantity: e.target.value
						}),
						placeholder: lang === "ar" ? "الكمية" : "Qty"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.route || "custom",
					onValueChange: (v) => setForm({
						...form,
						route: v === "custom" ? "" : v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: lang === "ar" ? "طريق الإعطاء" : "Route" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [ROUTES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: x.value,
						children: lang === "ar" ? x.labelAr : x.label
					}, x.value)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "custom",
						children: lang === "ar" ? "يدوي" : "Custom"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.instructions,
					onChange: (e) => setForm({
						...form,
						instructions: e.target.value
					}),
					placeholder: lang === "ar" ? "تعليمات إضافية" : "Instructions"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				type: "button",
				onClick: add,
				children: ["+ ", lang === "ar" ? "إضافة للروشتة" : "Add to prescription"]
			}),
			items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b bg-muted/30",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-2 text-start",
								children: lang === "ar" ? "الدواء" : "Drug"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-2 text-start",
								children: lang === "ar" ? "الجرعة" : "Dose"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-2 text-start",
								children: lang === "ar" ? "التكرار" : "Frequency"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-2 text-start",
								children: lang === "ar" ? "المدة" : "Duration"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((i, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-2",
								children: i.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-2",
								children: i.dose || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-2",
								children: i.frequency || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-2",
								children: i.duration || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-2 text-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => setItems(items.filter((_, x) => x !== index)),
									children: lang === "ar" ? "حذف" : "Remove"
								})
							})
						]
					}, `${i.medicine_id}-${index}`)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: save.isPending || !items.length,
					onClick: () => save.mutate(void 0),
					children: save.isPending ? lang === "ar" ? "جاري الحفظ..." : "Saving..." : lang === "ar" ? "حفظ الوصفة" : "Save prescription"
				})
			})
		]
	})] });
}
function rel$1(row, key) {
	const x = row?.[key];
	return (Array.isArray(x) ? x[0] : x) || {};
}
function HistoryTab({ visitId }) {
	const { lang } = useLang();
	const visitQ = useRows(["history-visit", visitId], () => supabase.from("visits").select("patient_id").eq("id", visitId).limit(1));
	const patientId = s((visitQ.data ?? [])[0], "patient_id");
	const visits = useRows(["history-visits", patientId], () => supabase.from("visits").select("id,visit_number,visit_date,status,departments(name,name_ar),users!visits_doctor_id_fkey(full_name),diagnoses(diagnosis_name,is_primary)").eq("patient_id", patientId).is("deleted_at", null).neq("id", visitId).order("visit_date", { ascending: false }).limit(30));
	if (visits.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const rows = visits.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { label: lang === "ar" ? "لا توجد زيارات سابقة" : "No previous visits" }) : rows.map((v) => {
			const dept = rel(v, "departments");
			const ds = v["diagnoses"] ?? [];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: s(v, "visit_number") || s(v, "id").slice(0, 8)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							dir: "ltr",
							children: formatDate(s(v, "visit_date"))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(v, "status") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: s(rel(v, "users"), "full_name")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "ms-auto text-primary underline",
							to: "/clinic/$visitId",
							params: { visitId: s(v, "id") },
							children: "Open"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: ds.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-muted px-2 py-1 text-xs",
						children: s(d, "diagnosis_name")
					}, s(d, "id")))
				})]
			}) }, s(v, "id"));
		})
	});
}
function rel(row, key) {
	const x = row?.[key];
	return (Array.isArray(x) ? x[0] : x) || {};
}
function ConsultationPage({ visitId }) {
	const { lang } = useLang();
	const { user } = useAuth();
	const { currency } = useSettings();
	const [tab, setTab] = (0, import_react.useState)("note");
	const visitQ = useRows(["consultation-visit", visitId], () => supabase.from("visits").select("id,visit_number,status,visit_date,patient_id,doctor_id,department_id,consultation_fee,patients(id,full_name,mrn,gender,date_of_birth),departments(name,name_ar),users!visits_doctor_id_fkey(full_name)").eq("id", visitId).limit(1));
	const visit = (visitQ.data ?? [])[0];
	const patient = rel$3(visit, "patients");
	const finish = useSave(async () => {
		const { error } = await supabase.from("visits").update({
			status: "completed",
			completed_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_by: user?.id ?? null
		}).eq("id", visitId);
		if (error) throw new Error(error.message);
		const { error: qErr } = await supabase.from("queue_tickets").update({
			status: "completed",
			completed_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("visit_id", visitId).in("status", [
			"waiting",
			"called",
			"in_progress"
		]);
		if (qErr) throw new Error(qErr.message);
		return null;
	}, {
		invalidate: [
			["consultation-visit", visitId],
			["clinic-visits"],
			["visits"],
			["queue"],
			["patient-visits"],
			["patient-snapshot-visits"]
		],
		successMessage: lang === "ar" ? "تم إنهاء الزيارة" : "Visit completed"
	});
	const invoiceQ = useRows(["consultation-invoice", visitId], () => supabase.from("invoices").select("id,invoice_number,net_amount,paid_amount,status").eq("visit_id", visitId).is("deleted_at", null).limit(1), { enabled: Boolean(visitId) });
	const existingInvoice = (invoiceQ.data ?? [])[0];
	const createInvoice = useSave(async () => {
		if (!visit) throw new Error("Visit not loaded");
		const fee = n(visit, "consultation_fee");
		if (fee <= 0) throw new Error(lang === "ar" ? "رسوم الاستشارة غير محددة أو صفر" : "Consultation fee is not set or is zero");
		const invoiceNumber = await rpc("next_invoice_number");
		const { data: inv, error } = await supabase.from("invoices").insert({
			invoice_number: invoiceNumber,
			patient_id: s(visit, "patient_id"),
			visit_id: visitId,
			invoice_date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
			total_amount: fee,
			subtotal: fee,
			discount_amount: 0,
			net_amount: fee,
			paid_amount: 0,
			status: "unpaid",
			payment_status: "unpaid",
			created_by: user?.id ?? null
		}).select("id").single();
		if (error) throw new Error(error.message);
		const { error: itemError } = await supabase.from("invoice_items").insert({
			invoice_id: inv.id,
			item_type: "consultation",
			item_name: "Consultation",
			quantity: 1,
			unit_price: fee,
			total_price: fee
		});
		if (itemError) throw new Error(itemError.message);
		return null;
	}, {
		invalidate: [["consultation-invoice", visitId], ["invoices"]],
		successMessage: lang === "ar" ? "تم إنشاء الفاتورة" : "Invoice created"
	});
	if (!visit) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6",
		children: visitQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : lang === "ar" ? "لم يتم العثور على الزيارة" : "Visit not found"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container mx-auto max-w-7xl space-y-4 p-4",
		dir: "auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/clinic",
					className: buttonVariants({
						variant: "outline",
						size: "sm"
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
						" ",
						lang === "ar" ? "العيادة" : "Clinic"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ms-auto flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(visit, "status") }),
						invoiceQ.isLoading ? null : existingInvoice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/billing/$invoiceId",
							params: { invoiceId: s(existingInvoice, "id") },
							className: buttonVariants({
								variant: "outline",
								size: "sm"
							}),
							title: lang === "ar" ? "عرض الفاتورة المرتبطة بهذه الزيارة" : "View the invoice linked to this visit",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" }),
								" ",
								money(n(existingInvoice, "net_amount"), currency),
								" ·",
								" ",
								s(existingInvoice, "status")
							]
						}) : n(visit, "consultation_fee") > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => createInvoice.mutate(void 0),
							disabled: createInvoice.isPending,
							title: lang === "ar" ? "إنشاء فاتورة لهذه الزيارة" : "Create an invoice for this visit",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" }),
								" ",
								lang === "ar" ? "إنشاء فاتورة" : "Create invoice"
							]
						}) : null,
						s(visit, "status") !== "completed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => finish.mutate(void 0),
							disabled: finish.isPending,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), lang === "ar" ? "إنهاء الزيارة" : "Finish visit"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: lang === "ar" ? "المريض" : "Patient"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold",
							children: s(patient, "full_name")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs",
							dir: "ltr",
							children: s(patient, "mrn")
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: lang === "ar" ? "العمر / الجنس" : "Age / Sex"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						calcAge(s(patient, "date_of_birth")) ?? "—",
						" · ",
						s(patient, "gender")
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: lang === "ar" ? "القسم" : "Department"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: lang === "ar" ? s(rel$3(visit, "departments"), "name_ar") || s(rel$3(visit, "departments"), "name") : s(rel$3(visit, "departments"), "name") })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: lang === "ar" ? "الطبيب" : "Doctor"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: s(rel$3(visit, "users"), "full_name") || "—" })] })
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto border-b",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-w-max gap-1",
					children: [
						["note", "الملاحظات"],
						["vitals", "العلامات الحيوية"],
						["labs", "المختبر"],
						["prescription", "الوصفة"],
						["history", "السجل السابق"]
					].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(k),
						className: `border-b-2 px-4 py-3 text-sm font-medium ${tab === k ? "border-primary text-primary" : "border-transparent text-muted-foreground"}`,
						children: l
					}, k))
				})
			}),
			tab === "note" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClinicalNoteTab, { visitId }),
			" ",
			tab === "vitals" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VitalsTab, { visitId }),
			" ",
			tab === "labs" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaboratoryTab, { visitId }),
			" ",
			tab === "prescription" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrescriptionTab, { visitId }),
			" ",
			tab === "history" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryTab, { visitId })
		]
	});
}
function ConsultationRouteComponent() {
	const { visitId } = Route$2.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "visits.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsultationPage, { visitId })
	});
}
//#endregion
export { ConsultationRouteComponent as component };
