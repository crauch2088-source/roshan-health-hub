//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C7n-XDTR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/repo/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/setup"
		],
		preloads: [
			"/assets/index-BnTAc6VZ.js",
			"/assets/i18n-BELjA0u6.js",
			"/assets/link-CvC6Mtt0.js",
			"/assets/preload-helper-FFfQgg3i.js",
			"/assets/useMatch-BFdlwlV0.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BnTAc6VZ.js"
		} }]
	},
	"/": {
		filePath: "/home/user/repo/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cv4sWyXm.js",
			"/assets/useNavigate-BVjm2AUF.js",
			"/assets/db-DivDa7OL.js"
		]
	},
	"/_authenticated": {
		filePath: "/home/user/repo/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounting",
			"/_authenticated/analytics",
			"/_authenticated/appointments",
			"/_authenticated/audit",
			"/_authenticated/billing",
			"/_authenticated/certificates",
			"/_authenticated/clinic",
			"/_authenticated/dashboard",
			"/_authenticated/expenses",
			"/_authenticated/finance",
			"/_authenticated/followups",
			"/_authenticated/insurance",
			"/_authenticated/inventory",
			"/_authenticated/lab",
			"/_authenticated/lab-catalog",
			"/_authenticated/partners",
			"/_authenticated/patients",
			"/_authenticated/pharmacy",
			"/_authenticated/queue",
			"/_authenticated/reports",
			"/_authenticated/settings",
			"/_authenticated/users",
			"/_authenticated/visits",
			"/_authenticated/billing_/$invoiceId",
			"/_authenticated/clinic_/$visitId",
			"/_authenticated/lab_/$orderId",
			"/_authenticated/patients_/$patientId"
		],
		preloads: [
			"/assets/route-2TtYcNaZ.js",
			"/assets/useNavigate-BVjm2AUF.js",
			"/assets/kit-BAtKSeEk.js",
			"/assets/wallet-g4nnFYfX.js",
			"/assets/stethoscope-Bj7P8VRd.js",
			"/assets/dist-CldjAY6G.js",
			"/assets/flask-conical-DOHIuU5M.js",
			"/assets/landmark-BEcerR7L.js",
			"/assets/plus-DTVSM5ws.js",
			"/assets/receipt-beZIRAha.js",
			"/assets/shield-check-B0GvJ_Bp.js",
			"/assets/users-BuNFdTxk.js",
			"/assets/dist-DEJh3i-f.js",
			"/assets/es2015-BjQq4YLV.js",
			"/assets/dialog-DIIhNHyj.js",
			"/assets/dist-DQFrY4u0.js",
			"/assets/dist-SacdokTF.js",
			"/assets/command-B5VyiAgK.js",
			"/assets/search-CKfVMeOa.js",
			"/assets/dist-CksCgT7J.js"
		]
	},
	"/auth": {
		filePath: "/home/user/repo/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-D8bDbU9S.js",
			"/assets/useNavigate-BVjm2AUF.js",
			"/assets/db-DivDa7OL.js",
			"/assets/kit-BAtKSeEk.js",
			"/assets/card-aMCmGzna.js"
		]
	},
	"/setup": {
		filePath: "/home/user/repo/src/routes/setup.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-eAsrvtOL.js",
			"/assets/useNavigate-BVjm2AUF.js",
			"/assets/db-DivDa7OL.js",
			"/assets/kit-BAtKSeEk.js",
			"/assets/circle-check-BywsSjH-.js",
			"/assets/card-aMCmGzna.js"
		]
	},
	"/_authenticated/accounting": {
		filePath: "/home/user/repo/src/routes/_authenticated/accounting.tsx",
		children: void 0,
		preloads: [
			"/assets/accounting-Cs5V6vfB.js",
			"/assets/db-DivDa7OL.js",
			"/assets/truck-BCrXeYfQ.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/analytics": {
		filePath: "/home/user/repo/src/routes/_authenticated/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-BHGl7MHP.js",
			"/assets/db-DivDa7OL.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Ii8ABkpp.js"
		]
	},
	"/_authenticated/appointments": {
		filePath: "/home/user/repo/src/routes/_authenticated/appointments.tsx",
		children: void 0,
		preloads: [
			"/assets/appointments-CUFCpF4S.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/patient-picker-vHutJJXV.js",
			"/assets/trash-2-B_2Wjjw_.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/audit": {
		filePath: "/home/user/repo/src/routes/_authenticated/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-DFPvTw-O.js",
			"/assets/db-DivDa7OL.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/billing": {
		filePath: "/home/user/repo/src/routes/_authenticated/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-qFJ2m4LQ.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/patient-picker-vHutJJXV.js",
			"/assets/trash-2-B_2Wjjw_.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/certificates": {
		filePath: "/home/user/repo/src/routes/_authenticated/certificates.tsx",
		children: void 0,
		preloads: [
			"/assets/certificates-DmNP501Y.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/patient-picker-vHutJJXV.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/clinic": {
		filePath: "/home/user/repo/src/routes/_authenticated/clinic.tsx",
		children: void 0,
		preloads: [
			"/assets/clinic-DKj3gRGS.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/home/user/repo/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-Dh9l09Jz.js",
			"/assets/db-DivDa7OL.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/pharmacy-DjUjLUX-.js"
		]
	},
	"/_authenticated/expenses": {
		filePath: "/home/user/repo/src/routes/_authenticated/expenses.tsx",
		children: void 0,
		preloads: [
			"/assets/expenses-3X6H3142.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/finance": {
		filePath: "/home/user/repo/src/routes/_authenticated/finance.tsx",
		children: void 0,
		preloads: [
			"/assets/finance-DRGqPLzf.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Ii8ABkpp.js"
		]
	},
	"/_authenticated/followups": {
		filePath: "/home/user/repo/src/routes/_authenticated/followups.tsx",
		children: void 0,
		preloads: [
			"/assets/followups-fOzELLbc.js",
			"/assets/db-DivDa7OL.js",
			"/assets/patient-picker-vHutJJXV.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/insurance": {
		filePath: "/home/user/repo/src/routes/_authenticated/insurance.tsx",
		children: void 0,
		preloads: [
			"/assets/insurance-CQg-1qCq.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/patient-picker-vHutJJXV.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Ii8ABkpp.js"
		]
	},
	"/_authenticated/inventory": {
		filePath: "/home/user/repo/src/routes/_authenticated/inventory.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory-zJ8vlEAj.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/truck-BCrXeYfQ.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Ii8ABkpp.js",
			"/assets/pharmacy-DjUjLUX-.js"
		]
	},
	"/_authenticated/lab": {
		filePath: "/home/user/repo/src/routes/_authenticated/lab.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-BTtTXcI1.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/lab-catalog": {
		filePath: "/home/user/repo/src/routes/_authenticated/lab-catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-catalog-CfXJKLGA.js",
			"/assets/db-DivDa7OL.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/switch-CFGqlfPM.js"
		]
	},
	"/_authenticated/partners": {
		filePath: "/home/user/repo/src/routes/_authenticated/partners.tsx",
		children: void 0,
		preloads: [
			"/assets/partners-ST8mnY5w.js",
			"/assets/db-DivDa7OL.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js"
		]
	},
	"/_authenticated/patients": {
		filePath: "/home/user/repo/src/routes/_authenticated/patients.tsx",
		children: void 0,
		preloads: [
			"/assets/patients-B5nkkUtN.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/pharmacy": {
		filePath: "/home/user/repo/src/routes/_authenticated/pharmacy.tsx",
		children: void 0,
		preloads: [
			"/assets/pharmacy-BiRBOuLi.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/pharmacy-DjUjLUX-.js"
		]
	},
	"/_authenticated/queue": {
		filePath: "/home/user/repo/src/routes/_authenticated/queue.tsx",
		children: void 0,
		preloads: [
			"/assets/queue-CaN1RfDI.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/user/repo/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DGZQ8xCl.js",
			"/assets/db-DivDa7OL.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Ii8ABkpp.js",
			"/assets/pharmacy-DjUjLUX-.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/user/repo/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-ByfT8PkG.js",
			"/assets/db-DivDa7OL.js",
			"/assets/card-aMCmGzna.js"
		]
	},
	"/_authenticated/users": {
		filePath: "/home/user/repo/src/routes/_authenticated/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-cC7IeFnw.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/switch-CFGqlfPM.js"
		]
	},
	"/_authenticated/visits": {
		filePath: "/home/user/repo/src/routes/_authenticated/visits.tsx",
		children: void 0,
		preloads: [
			"/assets/visits-CTPpjk_x.js",
			"/assets/db-DivDa7OL.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/patient-picker-vHutJJXV.js",
			"/assets/trash-2-B_2Wjjw_.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/billing_/$invoiceId": {
		filePath: "/home/user/repo/src/routes/_authenticated/billing_.$invoiceId.tsx",
		children: void 0,
		preloads: [
			"/assets/billing_._invoiceId-CVwyJ8_D.js",
			"/assets/useParams-Cp3x8NB0.js",
			"/assets/db-DivDa7OL.js",
			"/assets/arrow-left-B7TkcbHx.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/clinic_/$visitId": {
		filePath: "/home/user/repo/src/routes/_authenticated/clinic_.$visitId.tsx",
		children: void 0,
		preloads: [
			"/assets/clinic_._visitId-gW8Tyxh7.js",
			"/assets/db-DivDa7OL.js",
			"/assets/arrow-left-B7TkcbHx.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/circle-check-BywsSjH-.js",
			"/assets/card-aMCmGzna.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/lab_/$orderId": {
		filePath: "/home/user/repo/src/routes/_authenticated/lab_.$orderId.tsx",
		children: void 0,
		preloads: [
			"/assets/lab_._orderId-DwhCuRpB.js",
			"/assets/useParams-Cp3x8NB0.js",
			"/assets/db-DivDa7OL.js",
			"/assets/arrow-left-B7TkcbHx.js",
			"/assets/circle-check-BywsSjH-.js",
			"/assets/card-aMCmGzna.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/patients_/$patientId": {
		filePath: "/home/user/repo/src/routes/_authenticated/patients_.$patientId.tsx",
		children: void 0,
		preloads: [
			"/assets/patients_._patientId-DogU79lx.js",
			"/assets/useParams-Cp3x8NB0.js",
			"/assets/db-DivDa7OL.js",
			"/assets/arrow-left-B7TkcbHx.js",
			"/assets/select-DX6xwVwA.js",
			"/assets/table-DZMf1VJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-Ii8ABkpp.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
