globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"107f-fNJLPcwIMpyU/0wD6lVSo+oVH0s\"",
		"mtime": "2026-10-14T05:52:36.068Z",
		"size": 4223,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-14T05:52:36.068Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/roshan-logo.png": {
		"type": "image/png",
		"etag": "\"43c23-SpzrVevvn8yGunE6Zf20Xm04Q7E\"",
		"mtime": "2026-10-14T05:52:36.072Z",
		"size": 277539,
		"path": "../public/roshan-logo.png"
	},
	"/assets/accounting-CEkscDk4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4253-Ql2+1IPGTqtloOlNWpxyFwJZYj0\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 16979,
		"path": "../public/assets/accounting-CEkscDk4.js"
	},
	"/assets/analytics-CD5Jg-BN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37fa-xf7UatDD3pR/E5FZmwDraTddG7I\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 14330,
		"path": "../public/assets/analytics-CD5Jg-BN.js"
	},
	"/assets/appointments-Bu4NMMt-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"200d-zUzD7eBURcfr9qaOM3UBO4tEmD0\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 8205,
		"path": "../public/assets/appointments-Bu4NMMt-.js"
	},
	"/assets/arrow-left-nWjfXtaS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"98-zj3YHHfIkXfjUPWwFY0YsRAHOvM\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 152,
		"path": "../public/assets/arrow-left-nWjfXtaS.js"
	},
	"/assets/audit-DXsYmtDm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c9-yN2nGJwfUIxrniLSgbAB9u5ivnI\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 1993,
		"path": "../public/assets/audit-DXsYmtDm.js"
	},
	"/assets/auth-CTb5UEM7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d30-gkfBPUZvkUcBWqhzqa46DDal3IE\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 3376,
		"path": "../public/assets/auth-CTb5UEM7.js"
	},
	"/assets/billing_._invoiceId-Dl1JOHzC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1807-AB316Ya4txNgaceKCGCRG6PuER0\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 6151,
		"path": "../public/assets/billing_._invoiceId-Dl1JOHzC.js"
	},
	"/assets/billing-B-2Onzbs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cf1-WfTONTbWH4QYtO/5ID6fWv8DnvU\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 7409,
		"path": "../public/assets/billing-B-2Onzbs.js"
	},
	"/assets/card-UDmMXW42.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"446-crNikKtMvyRxcohAN7zpJa04jsE\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 1094,
		"path": "../public/assets/card-UDmMXW42.js"
	},
	"/assets/certificates-D498RW_b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1686-COZlreqPfhxtwc+DZijs5RN5Lwg\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 5766,
		"path": "../public/assets/certificates-D498RW_b.js"
	},
	"/assets/circle-check-CzPw0iVS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-cZZyayBZM0g5juymPPxT0JQvYAY\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 165,
		"path": "../public/assets/circle-check-CzPw0iVS.js"
	},
	"/assets/clinic-Bd7Gxams.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b00-l6FIQ+YTiFAK3S4Mdl5RcPJIQrU\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 6912,
		"path": "../public/assets/clinic-Bd7Gxams.js"
	},
	"/assets/clinic_._visitId-Cj9XuO8x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b51e-FM35ZS/6vItatZe9Hw1tnyULfBE\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 46366,
		"path": "../public/assets/clinic_._visitId-Cj9XuO8x.js"
	},
	"/assets/command-B_kpNQlH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33c5-R4gFouz0HWR0aIWl0HFPSVIceVE\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 13253,
		"path": "../public/assets/command-B_kpNQlH.js"
	},
	"/assets/dashboard-C9QSD4EJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c17-oKpWD3Et20mU2afcOFSG1uRbh+A\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 11287,
		"path": "../public/assets/dashboard-C9QSD4EJ.js"
	},
	"/assets/db-Cpk46L67.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fb9-o2DdeuUN8j+stVCNyNLJYeN//zw\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 12217,
		"path": "../public/assets/db-Cpk46L67.js"
	},
	"/assets/dialog-C3KHQQF4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d94-CzpF4C3ZM3A2oJ4kfxxVwL8Ej2A\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 7572,
		"path": "../public/assets/dialog-C3KHQQF4.js"
	},
	"/assets/dist-4LrANmku.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1085-T4kOWOCVVF/OCNOkhJihK06gfVk\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 4229,
		"path": "../public/assets/dist-4LrANmku.js"
	},
	"/assets/dist-B83ubVoH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"276-GlIls9Hv27R0eygLrsRFbQI1kB4\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 630,
		"path": "../public/assets/dist-B83ubVoH.js"
	},
	"/assets/dist-BCk1FJlF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cad-4W8LxAcdw+dd6IphCPzkHDIDJb0\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 7341,
		"path": "../public/assets/dist-BCk1FJlF.js"
	},
	"/assets/dist-C4FrVhQH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e6-V+ouz6WFoZm7HIBpvzPXrbQ1kdQ\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 742,
		"path": "../public/assets/dist-C4FrVhQH.js"
	},
	"/assets/dist-DAZVaeDq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cfd-u/Dj4B7mjbSa9+ZREV0eN071UCQ\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 7421,
		"path": "../public/assets/dist-DAZVaeDq.js"
	},
	"/assets/dist-YGK52Wfy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"645d-UO393TvdtwxcJ42WzSH7Gm2wx3M\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 25693,
		"path": "../public/assets/dist-YGK52Wfy.js"
	},
	"/assets/es2015-D681WoG0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5773-wpeFGLAgWsE62NVEECfV66aRSvA\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 22387,
		"path": "../public/assets/es2015-D681WoG0.js"
	},
	"/assets/expenses-CqtPXzGl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed1-xFi9Ub25VUeC6IGyfiZ822hX0XA\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 3793,
		"path": "../public/assets/expenses-CqtPXzGl.js"
	},
	"/assets/finance-Cbk7aqze.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"503b-Qrao2hUB2JXP1cl4+3z1/prCF8w\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 20539,
		"path": "../public/assets/finance-Cbk7aqze.js"
	},
	"/assets/flask-conical-BIb0cf9i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"121-dnmTKIK3hn7KIrtcWRy9rxBguCk\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 289,
		"path": "../public/assets/flask-conical-BIb0cf9i.js"
	},
	"/assets/followups-CXMc97Ht.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"134c-gD+W6mar2Z6iZHtT07ShgVo4+tk\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 4940,
		"path": "../public/assets/followups-CXMc97Ht.js"
	},
	"/assets/i18n-Ck9Teb2i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b870-TNP6/xpUsn7BAzCpUhcXKpObkts\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 309360,
		"path": "../public/assets/i18n-Ck9Teb2i.js"
	},
	"/assets/index-cxURt-Qn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45fdf-4HUshVdTAok5yhOfx83omNNXt0o\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 286687,
		"path": "../public/assets/index-cxURt-Qn.js"
	},
	"/assets/insurance-DcE9lYSF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5387-iJGqKzidVdRiziyAQB/55ADIAdI\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 21383,
		"path": "../public/assets/insurance-DcE9lYSF.js"
	},
	"/assets/inventory-CF_zmwKH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"674a-6htseOwbyStNxSD2zH0oZTOtsGM\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 26442,
		"path": "../public/assets/inventory-CF_zmwKH.js"
	},
	"/assets/lab-catalog-CNfMyszH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1837-Mf1MSlbUqRnBliDWtgaMIckXFo8\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 6199,
		"path": "../public/assets/lab-catalog-CNfMyszH.js"
	},
	"/assets/kit-BORJPru5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ca83-WaseQnfCDJEm2QhtoXAOiVTnyAU\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 51843,
		"path": "../public/assets/kit-BORJPru5.js"
	},
	"/assets/lab_._orderId-qUN_BgbP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d23-/clnEqmZu7+aLVgnoYMwJ/InjS0\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 7459,
		"path": "../public/assets/lab_._orderId-qUN_BgbP.js"
	},
	"/assets/lab-BD82SHo2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c2-kipq2yiLdmctXieYr36Qv8fRSTI\"",
		"mtime": "2026-10-14T05:52:31.404Z",
		"size": 5058,
		"path": "../public/assets/lab-BD82SHo2.js"
	},
	"/assets/landmark-Bp2GoUFQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"183-uFTTvU46Y5KX60Lzqbqw/T60vPs\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 387,
		"path": "../public/assets/landmark-Bp2GoUFQ.js"
	},
	"/assets/patient-picker-BwWQ8AF8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2be8-4d49gqPFTWO6JTAzFtN6mC6Srmg\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 11240,
		"path": "../public/assets/patient-picker-BwWQ8AF8.js"
	},
	"/assets/medical-dPD7Cm4k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"383-a4u43nMIbq6GEHDobMs7P68scTY\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 899,
		"path": "../public/assets/medical-dPD7Cm4k.js"
	},
	"/assets/partners-CBOV_fzH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4e-7R0Ba43fT1nX9K3dU+TKVIfIVG8\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 3150,
		"path": "../public/assets/partners-CBOV_fzH.js"
	},
	"/assets/patients_._patientId-BecqFV0t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3825-16edPAQ/otNIIvtUwR0Vuv448Es\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 14373,
		"path": "../public/assets/patients_._patientId-BecqFV0t.js"
	},
	"/assets/link-BduzYzS1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7a0-HIgeqFFFd7FDgls7zSyJL6EXhU8\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 63392,
		"path": "../public/assets/link-BduzYzS1.js"
	},
	"/assets/pharmacy-Bd7wbx5i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18b0-8JOYQ5ztyNtVierx6CjYctNOawA\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 6320,
		"path": "../public/assets/pharmacy-Bd7wbx5i.js"
	},
	"/assets/patients-06BnK__e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19d3-pNTCY65ZbySmQA9C09r3ynn47pI\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 6611,
		"path": "../public/assets/patients-06BnK__e.js"
	},
	"/assets/pharmacy-CDLv5QU7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23e-cu52rb9egxfVeVjN2tDtT1oUkeY\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 574,
		"path": "../public/assets/pharmacy-CDLv5QU7.js"
	},
	"/assets/plus-B_XPxSIl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c-xD5wioDmRAruXB0SO+eVz4b1DHw\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 140,
		"path": "../public/assets/plus-B_XPxSIl.js"
	},
	"/assets/preload-helper-5AidsvkQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"138a-3l/0Femkj4yqyZMfuE6z4mr5SRk\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 5002,
		"path": "../public/assets/preload-helper-5AidsvkQ.js"
	},
	"/assets/queue-CLeK2IX_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e23-BlD63/N9idE7U3QIEcRw0MLP+Lc\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 7715,
		"path": "../public/assets/queue-CLeK2IX_.js"
	},
	"/assets/receipt-BQvJfjcW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-I1XUpX3eg7e8HFbeP4sc19dPCtk\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 279,
		"path": "../public/assets/receipt-BQvJfjcW.js"
	},
	"/assets/reports-DwLpFtBv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f4f-EJqE2URAYq6ekZ4Io2cwUjl82EE\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 8015,
		"path": "../public/assets/reports-DwLpFtBv.js"
	},
	"/assets/route-TqIL4I7_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14a25-t3r4l2eOUfPy4xuNjscEMDb+MvU\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 84517,
		"path": "../public/assets/route-TqIL4I7_.js"
	},
	"/assets/routes-COywBSIu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36c-R79oURgAunBlqB4l/rI5xV8GIAI\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 876,
		"path": "../public/assets/routes-COywBSIu.js"
	},
	"/assets/search-DvJgRhgY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54a-xPRMJX3jp2luBp40n9RiqFsQ0zY\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 1354,
		"path": "../public/assets/search-DvJgRhgY.js"
	},
	"/assets/select-UecZCct3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56ff-gLkJOj31V8oPh29voPQBDUkPjsc\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 22271,
		"path": "../public/assets/select-UecZCct3.js"
	},
	"/assets/settings-CszNl9Qe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c1e-vUFBLzJp+r7F8qpw+HrpJJAshKE\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 3102,
		"path": "../public/assets/settings-CszNl9Qe.js"
	},
	"/assets/setup-DpoNB8FJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dde-pu2J2tnarIB4T+A5YR8Tjdn3cD0\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 3550,
		"path": "../public/assets/setup-DpoNB8FJ.js"
	},
	"/assets/shield-check-CGH4wZe4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"133-nUG91BGh1OA4ptG+yJvUsyLUBAg\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 307,
		"path": "../public/assets/shield-check-CGH4wZe4.js"
	},
	"/assets/stethoscope-BcVIrFsZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45e-FquF4kOuCakmLYlhX4BUCODV75I\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 1118,
		"path": "../public/assets/stethoscope-BcVIrFsZ.js"
	},
	"/assets/table-Dz7IIFZw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7fe-YklKiQWStuHgrwcKelwlpJ0/d+c\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 2046,
		"path": "../public/assets/table-Dz7IIFZw.js"
	},
	"/assets/switch-BMu8M8wZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10b0-XSz4vMpUKo3iPViP3P9bhN72T+A\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 4272,
		"path": "../public/assets/switch-BMu8M8wZ.js"
	},
	"/assets/styles-DU4qZ0Sp.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19949-MfjTAiqcRxiPokN9nZWFZTvMpz8\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 104777,
		"path": "../public/assets/styles-DU4qZ0Sp.css"
	},
	"/assets/tabs-Cs3Cesej.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ddb-3dRomwlO2ueNWgmno6pYjhclChA\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 3547,
		"path": "../public/assets/tabs-Cs3Cesej.js"
	},
	"/assets/trash-2-BWzV5Axh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b-TKsdvBVfPp7CxLjXD5x2pvQz6sc\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 315,
		"path": "../public/assets/trash-2-BWzV5Axh.js"
	},
	"/assets/truck-aUarEoEw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"189-N0oknWhC+dJFsLrWncHfX6Ofq2o\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 393,
		"path": "../public/assets/truck-aUarEoEw.js"
	},
	"/assets/useMatch-Bv4JVF7Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8fb-N+fWLXhgu+QERktCUMYOe8Y5mdQ\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 2299,
		"path": "../public/assets/useMatch-Bv4JVF7Q.js"
	},
	"/assets/useNavigate-DdCOwrZY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-HuiNTXfjfoCRiuxNXj9ewAlxSpU\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 184,
		"path": "../public/assets/useNavigate-DdCOwrZY.js"
	},
	"/assets/useParams-CGFb77ll.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"102-ohDUFIgtjsqZbWA2AOoOMtx6dIE\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 258,
		"path": "../public/assets/useParams-CGFb77ll.js"
	},
	"/assets/users-C9LlCqVC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-J01lvNlEtO+mwLk/lrN+5hwvJkw\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 293,
		"path": "../public/assets/users-C9LlCqVC.js"
	},
	"/assets/users-CAQk0mFm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28e4-JIwc9lf4rWte3Wk+/eHDgcfo8Mk\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 10468,
		"path": "../public/assets/users-CAQk0mFm.js"
	},
	"/assets/visits-DTzJoaY7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2824-8bhq8xtutLB5Hin6dNtZXVooIXU\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 10276,
		"path": "../public/assets/visits-DTzJoaY7.js"
	},
	"/assets/wallet-BMFecPvF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e8-hyQC3LkXoYrJCRMZROkkRRRkl1w\"",
		"mtime": "2026-10-14T05:52:31.408Z",
		"size": 744,
		"path": "../public/assets/wallet-BMFecPvF.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_t2bj9K = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_t2bj9K
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
