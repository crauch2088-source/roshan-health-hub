globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"107f-fNJLPcwIMpyU/0wD6lVSo+oVH0s\"",
		"mtime": "2026-10-14T05:59:38.512Z",
		"size": 4223,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-14T05:59:38.512Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/roshan-logo.png": {
		"type": "image/png",
		"etag": "\"43c23-SpzrVevvn8yGunE6Zf20Xm04Q7E\"",
		"mtime": "2026-10-14T05:59:38.512Z",
		"size": 277539,
		"path": "../public/roshan-logo.png"
	},
	"/assets/accounting-Cs5V6vfB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4253-93YEB0VGB6fhiMxgr6QOh5jUKe4\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 16979,
		"path": "../public/assets/accounting-Cs5V6vfB.js"
	},
	"/assets/analytics-BHGl7MHP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37fa-bkFeKMHW2tA5EdsPUxD40+Fr4W0\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 14330,
		"path": "../public/assets/analytics-BHGl7MHP.js"
	},
	"/assets/appointments-CUFCpF4S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"200d-ZOIrj8q7t2DkyC488pRS5J8BEFM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 8205,
		"path": "../public/assets/appointments-CUFCpF4S.js"
	},
	"/assets/arrow-left-B7TkcbHx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"98-M0W6SmA6NccrlBaI8oNlksrtCOk\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 152,
		"path": "../public/assets/arrow-left-B7TkcbHx.js"
	},
	"/assets/audit-DFPvTw-O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c9-Jy4zFsie6NQzeB4lWBNqboNn3RA\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 1993,
		"path": "../public/assets/audit-DFPvTw-O.js"
	},
	"/assets/auth-D8bDbU9S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d30-72wXV8mMvAoQcIvceACbD59M8Yc\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 3376,
		"path": "../public/assets/auth-D8bDbU9S.js"
	},
	"/assets/billing-qFJ2m4LQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cf1-TvqMk3RlRv5jAmUI8dLALEDqI2A\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 7409,
		"path": "../public/assets/billing-qFJ2m4LQ.js"
	},
	"/assets/billing_._invoiceId-CVwyJ8_D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1807-Lh2Gb8mxqShUtvRYHjoO6PuXvdQ\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 6151,
		"path": "../public/assets/billing_._invoiceId-CVwyJ8_D.js"
	},
	"/assets/card-aMCmGzna.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"446-4dfir3rQNlAGzZSo1GDJSEKM538\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 1094,
		"path": "../public/assets/card-aMCmGzna.js"
	},
	"/assets/certificates-DmNP501Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1686-2oLZnxDvF78KqSyV5BO1KGo4hI8\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 5766,
		"path": "../public/assets/certificates-DmNP501Y.js"
	},
	"/assets/circle-check-BywsSjH-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-N/YvV7ERSCP9WFceFxgTjQGZNvk\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 165,
		"path": "../public/assets/circle-check-BywsSjH-.js"
	},
	"/assets/clinic-DKj3gRGS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b1a-63XBPND7KrYb40hKOD5IGd4ctvw\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 6938,
		"path": "../public/assets/clinic-DKj3gRGS.js"
	},
	"/assets/clinic_._visitId-gW8Tyxh7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b51e-1wLIDJEJSWvw9geq7Eh2C/NgaOM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 46366,
		"path": "../public/assets/clinic_._visitId-gW8Tyxh7.js"
	},
	"/assets/command-B5VyiAgK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33c5-KZn284eta5zoDqZYfDChnbOpg/0\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 13253,
		"path": "../public/assets/command-B5VyiAgK.js"
	},
	"/assets/dashboard-Dh9l09Jz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c17-AJgjcOTYeIsP0H62T7a5XBQBEo4\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 11287,
		"path": "../public/assets/dashboard-Dh9l09Jz.js"
	},
	"/assets/db-DivDa7OL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fb9-4+c2TfuiaVqkP72Cxd8mA+pQhIs\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 12217,
		"path": "../public/assets/db-DivDa7OL.js"
	},
	"/assets/dialog-DIIhNHyj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d94-ZaKG21yww/RK1bk3/711dn3NwBE\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 7572,
		"path": "../public/assets/dialog-DIIhNHyj.js"
	},
	"/assets/dist-Bpz_KEzT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e6-qRTjIm4ROrIeoHdfuLQ8+KpR33c\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 742,
		"path": "../public/assets/dist-Bpz_KEzT.js"
	},
	"/assets/dist-CksCgT7J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"276-KggKTpMKy+hfxVhpYsQ4iBnJeUA\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 630,
		"path": "../public/assets/dist-CksCgT7J.js"
	},
	"/assets/dist-CldjAY6G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"645d-a+oUWNxY9uTahr+Oa9u1tuTgRcY\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 25693,
		"path": "../public/assets/dist-CldjAY6G.js"
	},
	"/assets/dist-DEJh3i-f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cfd-RoyyfhRFt6L005JTjbDf5Y5xU3A\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 7421,
		"path": "../public/assets/dist-DEJh3i-f.js"
	},
	"/assets/dist-DQFrY4u0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cad-HAGg43XL6wfH6NCgsrPG2rPL7GQ\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 7341,
		"path": "../public/assets/dist-DQFrY4u0.js"
	},
	"/assets/dist-SacdokTF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1085-10DQ/ya6oc43c+GhDzY2gUh5hPM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 4229,
		"path": "../public/assets/dist-SacdokTF.js"
	},
	"/assets/es2015-BjQq4YLV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5773-suWhzmDcrIRi3oJ2LskrGxhqm8Q\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 22387,
		"path": "../public/assets/es2015-BjQq4YLV.js"
	},
	"/assets/expenses-3X6H3142.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed1-9FEWeUyn+5/gAMafKCpA5sIWkgM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 3793,
		"path": "../public/assets/expenses-3X6H3142.js"
	},
	"/assets/finance-DRGqPLzf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"503b-++Vn43rG8/9Pfqw3mNgK/yBlQGs\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 20539,
		"path": "../public/assets/finance-DRGqPLzf.js"
	},
	"/assets/flask-conical-DOHIuU5M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"121-SQs4eecXRZ5bkh7DFEy1UIoM374\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 289,
		"path": "../public/assets/flask-conical-DOHIuU5M.js"
	},
	"/assets/followups-fOzELLbc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"134c-Zcpjkeb34miWe7uHAvwMn8CvPYM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 4940,
		"path": "../public/assets/followups-fOzELLbc.js"
	},
	"/assets/i18n-BELjA0u6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b993-fAd4Eg64SEOzRj2CMLve1uIT7C8\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 309651,
		"path": "../public/assets/i18n-BELjA0u6.js"
	},
	"/assets/index-BnTAc6VZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45fdf-GNu476vLiroyOa9tWbuUfE2kZpM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 286687,
		"path": "../public/assets/index-BnTAc6VZ.js"
	},
	"/assets/insurance-CQg-1qCq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5387-HtG5Lguj1hqVc8dF7l0vIvpquTg\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 21383,
		"path": "../public/assets/insurance-CQg-1qCq.js"
	},
	"/assets/inventory-zJ8vlEAj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"674a-x4giDRH08ICqjYYqRiKLlHu6VEQ\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 26442,
		"path": "../public/assets/inventory-zJ8vlEAj.js"
	},
	"/assets/kit-BAtKSeEk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cab3-LOdaXP0vc5LZ+QALi/OAD3RH9fA\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 51891,
		"path": "../public/assets/kit-BAtKSeEk.js"
	},
	"/assets/lab-BTtTXcI1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c2-RH1Rj6tptjR4vrehQsCArKiEJqE\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 5058,
		"path": "../public/assets/lab-BTtTXcI1.js"
	},
	"/assets/lab-catalog-CfXJKLGA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1837-xmCZCCOnwLEDtJyDeAo530Krq2M\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 6199,
		"path": "../public/assets/lab-catalog-CfXJKLGA.js"
	},
	"/assets/lab_._orderId-DwhCuRpB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d23-dk9PmNDWnt878C5WqYiAs96ONOk\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 7459,
		"path": "../public/assets/lab_._orderId-DwhCuRpB.js"
	},
	"/assets/landmark-BEcerR7L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"183-hnBNg1UF9841RRJVT4QDUcbcZkk\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 387,
		"path": "../public/assets/landmark-BEcerR7L.js"
	},
	"/assets/link-CvC6Mtt0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7a0-KgBLUXj2DaO7OCJmn4+3zCF9W/A\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 63392,
		"path": "../public/assets/link-CvC6Mtt0.js"
	},
	"/assets/medical-dPD7Cm4k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"383-a4u43nMIbq6GEHDobMs7P68scTY\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 899,
		"path": "../public/assets/medical-dPD7Cm4k.js"
	},
	"/assets/partners-ST8mnY5w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4e-kLafpwFWJc0hyi3i+cVjqIfNO68\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 3150,
		"path": "../public/assets/partners-ST8mnY5w.js"
	},
	"/assets/patient-picker-vHutJJXV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2be8-aERq0O3XQBvePwLcD54zNAdlmcs\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 11240,
		"path": "../public/assets/patient-picker-vHutJJXV.js"
	},
	"/assets/patients-B5nkkUtN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19d3-7IhrR9vFqPApHlfDMbTvSEYpmgg\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 6611,
		"path": "../public/assets/patients-B5nkkUtN.js"
	},
	"/assets/patients_._patientId-DogU79lx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3825-o4GRkdPGbGHGdhd2EWE8uGDJ1GA\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 14373,
		"path": "../public/assets/patients_._patientId-DogU79lx.js"
	},
	"/assets/pharmacy-BiRBOuLi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18a9-Fn/yBqfzd0onVFq9oRV7DG26Sow\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 6313,
		"path": "../public/assets/pharmacy-BiRBOuLi.js"
	},
	"/assets/pharmacy-DjUjLUX-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23e-IvGn0KZt47aACGh4yr1AxCV6mh8\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 574,
		"path": "../public/assets/pharmacy-DjUjLUX-.js"
	},
	"/assets/plus-DTVSM5ws.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c-C0XcM2qZ+cAQxeGImpgTERVxd7U\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 140,
		"path": "../public/assets/plus-DTVSM5ws.js"
	},
	"/assets/preload-helper-FFfQgg3i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"138a-EyF+0Y1kiiNJtyycWSviIWhGXgQ\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 5002,
		"path": "../public/assets/preload-helper-FFfQgg3i.js"
	},
	"/assets/queue-CaN1RfDI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e23-b7zrVoBG7ut47OrMH3EiMUTCGfg\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 7715,
		"path": "../public/assets/queue-CaN1RfDI.js"
	},
	"/assets/receipt-beZIRAha.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-q9aCB+BLFbHcyQKp1algBzhdoKA\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 279,
		"path": "../public/assets/receipt-beZIRAha.js"
	},
	"/assets/reports-DGZQ8xCl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f4f-DCyNTRogiBD2UPvR1GKtE8eT/l0\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 8015,
		"path": "../public/assets/reports-DGZQ8xCl.js"
	},
	"/assets/route-2TtYcNaZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14a25-HItNw7HURyj04fT66tQRPWtB/dM\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 84517,
		"path": "../public/assets/route-2TtYcNaZ.js"
	},
	"/assets/routes-Cv4sWyXm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36c-hdhWMmXvzTBbvzTR7cgol+nEZ7Y\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 876,
		"path": "../public/assets/routes-Cv4sWyXm.js"
	},
	"/assets/search-CKfVMeOa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54a-XnhFXQos2TM9aQSXynJKgykuy3E\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 1354,
		"path": "../public/assets/search-CKfVMeOa.js"
	},
	"/assets/select-DX6xwVwA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56ff-H2G2Slj6QKyl2sLYhZ+g9nF2HAU\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 22271,
		"path": "../public/assets/select-DX6xwVwA.js"
	},
	"/assets/settings-ByfT8PkG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c1e-8+EHyfpwsd+SEjoTIObKyutXW2A\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 3102,
		"path": "../public/assets/settings-ByfT8PkG.js"
	},
	"/assets/setup-eAsrvtOL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dde-NKh25jeB4z8DLxJD0hcN3a8e/u0\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 3550,
		"path": "../public/assets/setup-eAsrvtOL.js"
	},
	"/assets/shield-check-B0GvJ_Bp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"133-cxkiTo2Zfz4jWWQi2mrILDAIsnc\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 307,
		"path": "../public/assets/shield-check-B0GvJ_Bp.js"
	},
	"/assets/stethoscope-Bj7P8VRd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45e-kxNvZnUnlRGPurWEZHbpeML8gUo\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 1118,
		"path": "../public/assets/stethoscope-Bj7P8VRd.js"
	},
	"/assets/styles-D8_kQYjb.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19b65-1xxeD0A2+ETS6wsR7gRZzhBRxso\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 105317,
		"path": "../public/assets/styles-D8_kQYjb.css"
	},
	"/assets/switch-CFGqlfPM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d8-v691DWQJku3RnxKr/IM7WpQW2xo\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 4312,
		"path": "../public/assets/switch-CFGqlfPM.js"
	},
	"/assets/table-DZMf1VJr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7fe-bIhG/weqcVfhkB7Hufz6gm1FrOU\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 2046,
		"path": "../public/assets/table-DZMf1VJr.js"
	},
	"/assets/tabs-Ii8ABkpp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ddb-yYKKQ+1WxZhBN0ytMtsGGoDeCcI\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 3547,
		"path": "../public/assets/tabs-Ii8ABkpp.js"
	},
	"/assets/trash-2-B_2Wjjw_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b-sq7xxHw7ha8c5UelznU9qHtie1w\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 315,
		"path": "../public/assets/trash-2-B_2Wjjw_.js"
	},
	"/assets/truck-BCrXeYfQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"189-UF5hnVZmFCLY9d+VULy/WTaln+Q\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 393,
		"path": "../public/assets/truck-BCrXeYfQ.js"
	},
	"/assets/useMatch-BFdlwlV0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8fb-2cN+C4pqTGQf+O/zjzGSIqKrx+k\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 2299,
		"path": "../public/assets/useMatch-BFdlwlV0.js"
	},
	"/assets/useNavigate-BVjm2AUF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-Tt4ehQ7LEb+zRbDHlnxPB0iNa24\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 184,
		"path": "../public/assets/useNavigate-BVjm2AUF.js"
	},
	"/assets/useParams-Cp3x8NB0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"102-WQN0Aeie6oG+E1LtuX3GSIv+vq0\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 258,
		"path": "../public/assets/useParams-Cp3x8NB0.js"
	},
	"/assets/users-BuNFdTxk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-TF57GO+jCGr0xNkM5yvcGNzp5ro\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 293,
		"path": "../public/assets/users-BuNFdTxk.js"
	},
	"/assets/users-cC7IeFnw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28e4-5B1HI+d98XAyO9ua/ap/87gCBkA\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 10468,
		"path": "../public/assets/users-cC7IeFnw.js"
	},
	"/assets/visits-CTPpjk_x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2824-BMewOzzXP+1wGYLBuHMsLn6Q88w\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 10276,
		"path": "../public/assets/visits-CTPpjk_x.js"
	},
	"/assets/wallet-g4nnFYfX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e8-dMDIy19hYPakIodDGDN6lh39ZVg\"",
		"mtime": "2026-10-14T05:59:33.165Z",
		"size": 744,
		"path": "../public/assets/wallet-g4nnFYfX.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_t2bj9K = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_t2bj9K
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
