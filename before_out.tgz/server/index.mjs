globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region ../repo/node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"107f-fNJLPcwIMpyU/0wD6lVSo+oVH0s\"",
		"mtime": "2026-10-14T05:53:06.514Z",
		"size": 4223,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-14T05:53:06.514Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/roshan-logo.png": {
		"type": "image/png",
		"etag": "\"43c23-SpzrVevvn8yGunE6Zf20Xm04Q7E\"",
		"mtime": "2026-10-14T05:53:06.514Z",
		"size": 277539,
		"path": "../public/roshan-logo.png"
	},
	"/assets/accounting-D-sRwrEx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4253-sSn/zo/xrF94vWUIIBi1eXC3KfU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 16979,
		"path": "../public/assets/accounting-D-sRwrEx.js"
	},
	"/assets/analytics-c6_qJ8n4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37da-71e7uzC54nYVx8AH+x5doiLBLXE\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 14298,
		"path": "../public/assets/analytics-c6_qJ8n4.js"
	},
	"/assets/appointments-B0VJmV3n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fe3-zRrqMKcn9jfIYJzRId4d38zAoQ0\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 8163,
		"path": "../public/assets/appointments-B0VJmV3n.js"
	},
	"/assets/arrow-left-BDtvh4K_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"98-4WE+M+eagPxnTHjhlskGKBqf+K0\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 152,
		"path": "../public/assets/arrow-left-BDtvh4K_.js"
	},
	"/assets/audit-CD-pgzcv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ae-oyoDQTCqnio9C8smEfMrsHHkR8I\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 1966,
		"path": "../public/assets/audit-CD-pgzcv.js"
	},
	"/assets/auth-mFaE5yg1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d10-1VNLAESux8+NwgLz3+24VmcNrSY\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 3344,
		"path": "../public/assets/auth-mFaE5yg1.js"
	},
	"/assets/billing-BTZ3zCtL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cc7-lRe2ulqFriz6fTVVHFbE3t+no4w\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7367,
		"path": "../public/assets/billing-BTZ3zCtL.js"
	},
	"/assets/billing_._invoiceId-CEnp7v77.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17e2-QNEVuvqnmDE2KnN9whcnAX+qnpw\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 6114,
		"path": "../public/assets/billing_._invoiceId-CEnp7v77.js"
	},
	"/assets/certificates-Cy_13Zh5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1666-quG/+Ade9a6cy8KomhInTdSJorA\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 5734,
		"path": "../public/assets/certificates-Cy_13Zh5.js"
	},
	"/assets/check-c0UR29pv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6f-qJQaftr/MgKYAZH7zO5MlpYjyfc\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 111,
		"path": "../public/assets/check-c0UR29pv.js"
	},
	"/assets/circle-check-DA4TZbUV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-mAwKS1xbo5vhA74ZTRw0fSqDqsc\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 165,
		"path": "../public/assets/circle-check-DA4TZbUV.js"
	},
	"/assets/clinic-Dm0UhpcV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12e3-m02RBnryQrBnWBhS3SgrqqwMYg0\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 4835,
		"path": "../public/assets/clinic-Dm0UhpcV.js"
	},
	"/assets/clinic_._visitId-8s2uICP3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b538-VI66d4IEQp6Dck4lI3GbF/kFG2I\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 46392,
		"path": "../public/assets/clinic_._visitId-8s2uICP3.js"
	},
	"/assets/command-CsTfkJxi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33e7-yT60Lev4bYDLK0HMtWl7LuMWlRU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 13287,
		"path": "../public/assets/command-CsTfkJxi.js"
	},
	"/assets/dashboard-Dp4Fhqd7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d3d-OF/qYRNXPwNBa9jeBalAxOtHcjk\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 11581,
		"path": "../public/assets/dashboard-Dp4Fhqd7.js"
	},
	"/assets/db-BBNnhu_u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fb9-ZNk4n/LyqGk20rPluclKHLalouA\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 12217,
		"path": "../public/assets/db-BBNnhu_u.js"
	},
	"/assets/dialog-zLgwYgBq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1db1-3F6wU+LAA9SgoLq8m/CwwL+dz5s\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7601,
		"path": "../public/assets/dialog-zLgwYgBq.js"
	},
	"/assets/dist-ByE7rZEn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bde-2TKvvLGH7z4a8tEqBy8zQ1R/Opw\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7134,
		"path": "../public/assets/dist-ByE7rZEn.js"
	},
	"/assets/dist-CGjL2AST.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e6-BbH1iTfKyMCD3ezT925wvGXcqCk\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 742,
		"path": "../public/assets/dist-CGjL2AST.js"
	},
	"/assets/dist-D1fTlBCO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"276-/KT3NZVE3TyRBb/S6NLsA2twOgE\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 630,
		"path": "../public/assets/dist-D1fTlBCO.js"
	},
	"/assets/dist-De4y6TaI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cfd-IBPPT9vbDiaATl0Sh8fvDmd0vrU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7421,
		"path": "../public/assets/dist-De4y6TaI.js"
	},
	"/assets/dist-DgJknwIR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11f-S4sB9QiHpgV4yPld/0RQvyXknmU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 287,
		"path": "../public/assets/dist-DgJknwIR.js"
	},
	"/assets/dist-DxEv1w84.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"640f-442BBvlJNEXSRmKbHOKg6JOxMwM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 25615,
		"path": "../public/assets/dist-DxEv1w84.js"
	},
	"/assets/es2015-BOftChoq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5773-/60Htl0IaGq+y7lLf9mqmbx9fKU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 22387,
		"path": "../public/assets/es2015-BOftChoq.js"
	},
	"/assets/expenses-DRPnMbJX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eb1-yJkkORuPID0MqiCvf2aDleOLpAY\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 3761,
		"path": "../public/assets/expenses-DRPnMbJX.js"
	},
	"/assets/finance-D6b8gp0V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5016-7fvCGnOjRHomtdr4mxZgrRQf4MI\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 20502,
		"path": "../public/assets/finance-D6b8gp0V.js"
	},
	"/assets/flask-conical-QaEt9vSc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"121-KXx9QQNZSs8Nb06JlZdTWd5zPmQ\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 289,
		"path": "../public/assets/flask-conical-QaEt9vSc.js"
	},
	"/assets/followups-Brj1uOZL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1327-ioJwSDlP3eTVt5dg6Z1cBBnq98c\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 4903,
		"path": "../public/assets/followups-Brj1uOZL.js"
	},
	"/assets/i18n-DR22Mx4s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b5a8-mm0y8Vj8pjRc/kqInFdkB3M3w1w\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 308648,
		"path": "../public/assets/i18n-DR22Mx4s.js"
	},
	"/assets/index-C2B10XrZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"46093-kHgVgbW9r8hVOX1BscuIuLlH6Ok\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 286867,
		"path": "../public/assets/index-C2B10XrZ.js"
	},
	"/assets/insurance-DPxLFn1E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5367-2Blf/0Bh7ssTgh9XITjgAt7ojTQ\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 21351,
		"path": "../public/assets/insurance-DPxLFn1E.js"
	},
	"/assets/inventory-CFIIN0Qy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"672f-zYnYC85Od8Cz00z1AI9kqNDrnpM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 26415,
		"path": "../public/assets/inventory-CFIIN0Qy.js"
	},
	"/assets/kit-GWlksCrm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b912-b1aYZKs0imxHiO84FONQmRDPnlc\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 47378,
		"path": "../public/assets/kit-GWlksCrm.js"
	},
	"/assets/lab-catalog-Ds5IXYZ7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1817-IFPFbvQZZvGvhe+I+MobKCZPZVM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 6167,
		"path": "../public/assets/lab-catalog-Ds5IXYZ7.js"
	},
	"/assets/lab-sbecuByc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12a3-iyX7ljfTdKytw2DeGWHshhHEGbo\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 4771,
		"path": "../public/assets/lab-sbecuByc.js"
	},
	"/assets/lab_._orderId-CnUf8SHY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d08-0253MC+PeWWoc1qYvyFIjEXxGiI\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7432,
		"path": "../public/assets/lab_._orderId-CnUf8SHY.js"
	},
	"/assets/landmark-BdXXM74i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"183-8w9kLZMLTet1Ld9wOJxd8Pjquks\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 387,
		"path": "../public/assets/landmark-BdXXM74i.js"
	},
	"/assets/link-AJqqhZHy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7a0-qI08uSI6ujOQVXVbBklH14J3MDk\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 63392,
		"path": "../public/assets/link-AJqqhZHy.js"
	},
	"/assets/medical-dPD7Cm4k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"383-a4u43nMIbq6GEHDobMs7P68scTY\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 899,
		"path": "../public/assets/medical-dPD7Cm4k.js"
	},
	"/assets/partners-B2RCISNI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c29-Cb/Rn6zwr4yZTQCJ8IXpThJv0vE\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 3113,
		"path": "../public/assets/partners-B2RCISNI.js"
	},
	"/assets/patient-picker-CxI-fpu7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c09-y618jgCm/boxfApBfyEARZhJ7Uw\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 11273,
		"path": "../public/assets/patient-picker-CxI-fpu7.js"
	},
	"/assets/patients-CIm5HX8E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bc1-w1EmEshJ8EAxE9vRkK4TBAOfkdU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7105,
		"path": "../public/assets/patients-CIm5HX8E.js"
	},
	"/assets/patients_._patientId-DWuQELLb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3824-/i6uWKYAWIMvmBWs7aeBNrIDX7U\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 14372,
		"path": "../public/assets/patients_._patientId-DWuQELLb.js"
	},
	"/assets/pharmacy-BZ_eZolb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23e-Uj7LJ5OSLYYgWwoHJdl+6afmQJw\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 574,
		"path": "../public/assets/pharmacy-BZ_eZolb.js"
	},
	"/assets/pharmacy-C_TiI2Ai.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1743-XYRAPVJG9dKAQR3EdF2eW0yUHfc\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 5955,
		"path": "../public/assets/pharmacy-C_TiI2Ai.js"
	},
	"/assets/plus-C1nhZ2OU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c-fhieWnDy5XpumIbGR4XxXeVecKw\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 140,
		"path": "../public/assets/plus-C1nhZ2OU.js"
	},
	"/assets/preload-helper-BijRsIbo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"138a-XOLVjYJdn1hdt70+CtImoWKc6tE\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 5002,
		"path": "../public/assets/preload-helper-BijRsIbo.js"
	},
	"/assets/queue-BwulakIE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ede-0SllTilX/SRMs3aL1/OC15uGnU4\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7902,
		"path": "../public/assets/queue-BwulakIE.js"
	},
	"/assets/receipt-CDMGuOpa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-5E8pknUUQPjgyoWJIzIVlhimVC4\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 279,
		"path": "../public/assets/receipt-CDMGuOpa.js"
	},
	"/assets/reports-BIZaZ4C6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f25-LkAAOp0EVTopiHnZai5e0TLFxgA\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7973,
		"path": "../public/assets/reports-BIZaZ4C6.js"
	},
	"/assets/route-RX4NdSDK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f718-C9fEX6oigcSHV71qeA64vEXjLdM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 63256,
		"path": "../public/assets/route-RX4NdSDK.js"
	},
	"/assets/routes-DVjGTV4X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36c-GTBpjeMD2wzTVUgHv2X4zs2zfeU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 876,
		"path": "../public/assets/routes-DVjGTV4X.js"
	},
	"/assets/search-BG5wbTg1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54a-eC10lSo/KOSixbbT2yEh9YpLnyM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 1354,
		"path": "../public/assets/search-BG5wbTg1.js"
	},
	"/assets/search-CXUU0rxN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1-40xwdeZqU5jTuzzYfxRrvF4LcmM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 161,
		"path": "../public/assets/search-CXUU0rxN.js"
	},
	"/assets/select-CIO7arC3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5740-bb7HaMZrOR6d1at3n2ADZL3c7AE\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 22336,
		"path": "../public/assets/select-CIO7arC3.js"
	},
	"/assets/settings-fYSy08OY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bfe-jgSFOJbRFb7OFH5FQ+YBI6iR844\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 3070,
		"path": "../public/assets/settings-fYSy08OY.js"
	},
	"/assets/setup-DjQ6XiK_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dbe-qmOgrHQFDIAsrpY3PA+ZSJtEwQM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 3518,
		"path": "../public/assets/setup-DjQ6XiK_.js"
	},
	"/assets/shield-check-C6E4ryYM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"133-5V1Ih8K4egem0vhPpVS7leCCvFY\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 307,
		"path": "../public/assets/shield-check-C6E4ryYM.js"
	},
	"/assets/stethoscope-ITrI_LqH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45e-ODDPBsYIc4xIGFOd9L2rfDlQdDM\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 1118,
		"path": "../public/assets/stethoscope-ITrI_LqH.js"
	},
	"/assets/styles-DFcoBuez.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a0f1-I74conif7xPzVwhvAAtJocY9MSo\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 106737,
		"path": "../public/assets/styles-DFcoBuez.css"
	},
	"/assets/switch-BGjqYsDI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10b0-AijtTIw1VXTayX4RY6vJuw2PVAI\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 4272,
		"path": "../public/assets/switch-BGjqYsDI.js"
	},
	"/assets/table-yQA39uJr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7d0-m/XiWzePxwc3kla+BGgrExcR5jI\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 2e3,
		"path": "../public/assets/table-yQA39uJr.js"
	},
	"/assets/tabs-DlyH31Ox.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d88-K4dcEDB9+J6+FZWJASkblnYB+rk\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 7560,
		"path": "../public/assets/tabs-DlyH31Ox.js"
	},
	"/assets/trash-2-BH9TD5o5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b-f+56LdRG7TfmqZIoQkgBctGFDCQ\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 315,
		"path": "../public/assets/trash-2-BH9TD5o5.js"
	},
	"/assets/truck-CeoxuzlW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"189-zN58nr0gGqpR/BP9vwMvLUn2g88\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 393,
		"path": "../public/assets/truck-CeoxuzlW.js"
	},
	"/assets/useMatch-s8RYncbA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8fb-PIwqXjlBRRJzWbcb7ydMDa60byo\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 2299,
		"path": "../public/assets/useMatch-s8RYncbA.js"
	},
	"/assets/useNavigate-JwUtLeSU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-W3ADCbRZWYYWuAm5PwGcvthv3Yk\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 184,
		"path": "../public/assets/useNavigate-JwUtLeSU.js"
	},
	"/assets/useParams-DeGenlI1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"102-8WNRoGEJlEWKbzMYojyupow/LkE\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 258,
		"path": "../public/assets/useParams-DeGenlI1.js"
	},
	"/assets/user-round-Le0PpQuB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-dkM0/KE7S08L7IwGK787iQuPLrk\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 169,
		"path": "../public/assets/user-round-Le0PpQuB.js"
	},
	"/assets/users-C6LNPvnt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25d7-hyQyeRUDFN8pp4obs9FKdDM4oI4\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 9687,
		"path": "../public/assets/users-C6LNPvnt.js"
	},
	"/assets/users-DtBpXxS8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-lOEkrjSm9q70rzbTZ1D4m+x8liY\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 293,
		"path": "../public/assets/users-DtBpXxS8.js"
	},
	"/assets/visits-CjPOybYp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27ff-l/27EtxQQZkn6+Ueb2ZY07HY0LQ\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 10239,
		"path": "../public/assets/visits-CjPOybYp.js"
	},
	"/assets/wallet-BO1jAcoD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"267-bwP8NKROpyVMSiukfG6misvzAkQ\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 615,
		"path": "../public/assets/wallet-BO1jAcoD.js"
	},
	"/assets/x-YndUH1l2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-JAzRrP1xdBocB1qO5OPxsoFvZpU\"",
		"mtime": "2026-10-14T05:53:01.561Z",
		"size": 141,
		"path": "../public/assets/x-YndUH1l2.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region ../repo/node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_t2bj9K = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_t2bj9K
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region ../repo/node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region ../repo/node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region ../repo/node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region ../repo/node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
