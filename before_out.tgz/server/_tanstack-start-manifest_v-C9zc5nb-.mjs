//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C9zc5nb-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/before/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/setup"
		],
		preloads: [
			"/assets/index-C2B10XrZ.js",
			"/assets/i18n-DR22Mx4s.js",
			"/assets/link-AJqqhZHy.js",
			"/assets/preload-helper-BijRsIbo.js",
			"/assets/useMatch-s8RYncbA.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C2B10XrZ.js"
		} }]
	},
	"/": {
		filePath: "/home/user/before/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DVjGTV4X.js",
			"/assets/useNavigate-JwUtLeSU.js",
			"/assets/db-BBNnhu_u.js"
		]
	},
	"/_authenticated": {
		filePath: "/home/user/before/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounting",
			"/_authenticated/analytics",
			"/_authenticated/appointments",
			"/_authenticated/audit",
			"/_authenticated/billing",
			"/_authenticated/certificates",
			"/_authenticated/clinic",
			"/_authenticated/dashboard",
			"/_authenticated/expenses",
			"/_authenticated/finance",
			"/_authenticated/followups",
			"/_authenticated/insurance",
			"/_authenticated/inventory",
			"/_authenticated/lab",
			"/_authenticated/lab-catalog",
			"/_authenticated/partners",
			"/_authenticated/patients",
			"/_authenticated/pharmacy",
			"/_authenticated/queue",
			"/_authenticated/reports",
			"/_authenticated/settings",
			"/_authenticated/users",
			"/_authenticated/visits",
			"/_authenticated/billing_/$invoiceId",
			"/_authenticated/clinic_/$visitId",
			"/_authenticated/lab_/$orderId",
			"/_authenticated/patients_/$patientId"
		],
		preloads: [
			"/assets/route-RX4NdSDK.js",
			"/assets/useNavigate-JwUtLeSU.js",
			"/assets/kit-GWlksCrm.js",
			"/assets/wallet-BO1jAcoD.js",
			"/assets/stethoscope-ITrI_LqH.js",
			"/assets/flask-conical-QaEt9vSc.js",
			"/assets/landmark-BdXXM74i.js",
			"/assets/plus-C1nhZ2OU.js",
			"/assets/receipt-CDMGuOpa.js",
			"/assets/search-CXUU0rxN.js",
			"/assets/shield-check-C6E4ryYM.js",
			"/assets/user-round-Le0PpQuB.js",
			"/assets/users-DtBpXxS8.js",
			"/assets/x-YndUH1l2.js",
			"/assets/dist-De4y6TaI.js",
			"/assets/es2015-BOftChoq.js",
			"/assets/dialog-zLgwYgBq.js",
			"/assets/dist-DgJknwIR.js",
			"/assets/command-CsTfkJxi.js",
			"/assets/dist-DxEv1w84.js",
			"/assets/search-BG5wbTg1.js",
			"/assets/dist-D1fTlBCO.js"
		]
	},
	"/auth": {
		filePath: "/home/user/before/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-mFaE5yg1.js",
			"/assets/useNavigate-JwUtLeSU.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/kit-GWlksCrm.js"
		]
	},
	"/setup": {
		filePath: "/home/user/before/src/routes/setup.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-DjQ6XiK_.js",
			"/assets/useNavigate-JwUtLeSU.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/kit-GWlksCrm.js",
			"/assets/circle-check-DA4TZbUV.js"
		]
	},
	"/_authenticated/accounting": {
		filePath: "/home/user/before/src/routes/_authenticated/accounting.tsx",
		children: void 0,
		preloads: [
			"/assets/accounting-D-sRwrEx.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/truck-CeoxuzlW.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/analytics": {
		filePath: "/home/user/before/src/routes/_authenticated/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-c6_qJ8n4.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-DlyH31Ox.js"
		]
	},
	"/_authenticated/appointments": {
		filePath: "/home/user/before/src/routes/_authenticated/appointments.tsx",
		children: void 0,
		preloads: [
			"/assets/appointments-B0VJmV3n.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/patient-picker-CxI-fpu7.js",
			"/assets/trash-2-BH9TD5o5.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/audit": {
		filePath: "/home/user/before/src/routes/_authenticated/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-CD-pgzcv.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/billing": {
		filePath: "/home/user/before/src/routes/_authenticated/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-BTZ3zCtL.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/patient-picker-CxI-fpu7.js",
			"/assets/trash-2-BH9TD5o5.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/certificates": {
		filePath: "/home/user/before/src/routes/_authenticated/certificates.tsx",
		children: void 0,
		preloads: [
			"/assets/certificates-Cy_13Zh5.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/patient-picker-CxI-fpu7.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/clinic": {
		filePath: "/home/user/before/src/routes/_authenticated/clinic.tsx",
		children: void 0,
		preloads: [
			"/assets/clinic-Dm0UhpcV.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/home/user/before/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-Dp4Fhqd7.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/pharmacy-BZ_eZolb.js"
		]
	},
	"/_authenticated/expenses": {
		filePath: "/home/user/before/src/routes/_authenticated/expenses.tsx",
		children: void 0,
		preloads: [
			"/assets/expenses-DRPnMbJX.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/finance": {
		filePath: "/home/user/before/src/routes/_authenticated/finance.tsx",
		children: void 0,
		preloads: [
			"/assets/finance-D6b8gp0V.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-DlyH31Ox.js"
		]
	},
	"/_authenticated/followups": {
		filePath: "/home/user/before/src/routes/_authenticated/followups.tsx",
		children: void 0,
		preloads: [
			"/assets/followups-Brj1uOZL.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/patient-picker-CxI-fpu7.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/insurance": {
		filePath: "/home/user/before/src/routes/_authenticated/insurance.tsx",
		children: void 0,
		preloads: [
			"/assets/insurance-DPxLFn1E.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/patient-picker-CxI-fpu7.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-DlyH31Ox.js"
		]
	},
	"/_authenticated/inventory": {
		filePath: "/home/user/before/src/routes/_authenticated/inventory.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory-CFIIN0Qy.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/truck-CeoxuzlW.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-DlyH31Ox.js",
			"/assets/pharmacy-BZ_eZolb.js"
		]
	},
	"/_authenticated/lab": {
		filePath: "/home/user/before/src/routes/_authenticated/lab.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-sbecuByc.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/lab-catalog": {
		filePath: "/home/user/before/src/routes/_authenticated/lab-catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-catalog-Ds5IXYZ7.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/switch-BGjqYsDI.js"
		]
	},
	"/_authenticated/partners": {
		filePath: "/home/user/before/src/routes/_authenticated/partners.tsx",
		children: void 0,
		preloads: [
			"/assets/partners-B2RCISNI.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js"
		]
	},
	"/_authenticated/patients": {
		filePath: "/home/user/before/src/routes/_authenticated/patients.tsx",
		children: void 0,
		preloads: [
			"/assets/patients-CIm5HX8E.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/pharmacy": {
		filePath: "/home/user/before/src/routes/_authenticated/pharmacy.tsx",
		children: void 0,
		preloads: [
			"/assets/pharmacy-C_TiI2Ai.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/pharmacy-BZ_eZolb.js"
		]
	},
	"/_authenticated/queue": {
		filePath: "/home/user/before/src/routes/_authenticated/queue.tsx",
		children: void 0,
		preloads: [
			"/assets/queue-BwulakIE.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/check-c0UR29pv.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/user/before/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BIZaZ4C6.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-DlyH31Ox.js",
			"/assets/pharmacy-BZ_eZolb.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/user/before/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-fYSy08OY.js", "/assets/db-BBNnhu_u.js"]
	},
	"/_authenticated/users": {
		filePath: "/home/user/before/src/routes/_authenticated/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-C6LNPvnt.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/switch-BGjqYsDI.js"
		]
	},
	"/_authenticated/visits": {
		filePath: "/home/user/before/src/routes/_authenticated/visits.tsx",
		children: void 0,
		preloads: [
			"/assets/visits-CjPOybYp.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/select-CIO7arC3.js",
			"/assets/patient-picker-CxI-fpu7.js",
			"/assets/trash-2-BH9TD5o5.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/billing_/$invoiceId": {
		filePath: "/home/user/before/src/routes/_authenticated/billing_.$invoiceId.tsx",
		children: void 0,
		preloads: [
			"/assets/billing_._invoiceId-CEnp7v77.js",
			"/assets/useParams-DeGenlI1.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/arrow-left-BDtvh4K_.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/clinic_/$visitId": {
		filePath: "/home/user/before/src/routes/_authenticated/clinic_.$visitId.tsx",
		children: void 0,
		preloads: [
			"/assets/clinic_._visitId-8s2uICP3.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/arrow-left-BDtvh4K_.js",
			"/assets/select-CIO7arC3.js",
			"/assets/circle-check-DA4TZbUV.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/lab_/$orderId": {
		filePath: "/home/user/before/src/routes/_authenticated/lab_.$orderId.tsx",
		children: void 0,
		preloads: [
			"/assets/lab_._orderId-CnUf8SHY.js",
			"/assets/useParams-DeGenlI1.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/arrow-left-BDtvh4K_.js",
			"/assets/circle-check-DA4TZbUV.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js"
		]
	},
	"/_authenticated/patients_/$patientId": {
		filePath: "/home/user/before/src/routes/_authenticated/patients_.$patientId.tsx",
		children: void 0,
		preloads: [
			"/assets/patients_._patientId-DWuQELLb.js",
			"/assets/useParams-DeGenlI1.js",
			"/assets/db-BBNnhu_u.js",
			"/assets/arrow-left-BDtvh4K_.js",
			"/assets/select-CIO7arC3.js",
			"/assets/table-yQA39uJr.js",
			"/assets/medical-dPD7Cm4k.js",
			"/assets/tabs-DlyH31Ox.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
