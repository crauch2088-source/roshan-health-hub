import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/supabase-CqpbQBDM.js
/**
* Roshan Medical Center — existing Supabase project.
* The publishable (anon) key is safe in client code; every table is protected
* by RLS policies (see db/roshan_phase1_migration.sql).
*/
var SUPABASE_URL = "https://jewzonxplxhogqrnhosl.supabase.co";
var SUPABASE_PUBLISHABLE_KEY = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_testfake"
}["VITE_SUPABASE_PUBLISHABLE_KEY"];
if (!SUPABASE_PUBLISHABLE_KEY) throw new Error("Missing VITE_SUPABASE_PUBLISHABLE_KEY environment variable.");
var isBrowser = typeof window !== "undefined";
var supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, { auth: {
	persistSession: isBrowser,
	autoRefreshToken: isBrowser,
	detectSessionInUrl: isBrowser,
	storageKey: "roshan-auth"
} });
/** Turns any Supabase/PostgREST failure into a readable, visible message. */
function dbError(error) {
	if (!error) return "";
	const e = error;
	const text = [
		e.message,
		e.details,
		e.hint
	].filter(Boolean).join(" — ") || String(error);
	if (e.code === "42501" || /row-level security/i.test(text)) return `${text} (permission denied by database policy)`;
	if (e.code === "42703") return `${text} (column missing — run db/roshan_phase1_migration.sql)`;
	if (e.code === "42883" || e.code === "PGRST202") return `${text} (database function missing — run db/roshan_phase1_migration.sql)`;
	return text;
}
//#endregion
export { dbError as n, supabase as r, SUPABASE_URL as t };
