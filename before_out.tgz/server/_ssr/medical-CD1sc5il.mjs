//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/medical-CD1sc5il.js
/** Clinical + formatting calculations shared across the app. */
function calcAge(dob) {
	if (!dob) return null;
	const d = new Date(dob);
	if (Number.isNaN(d.getTime())) return null;
	const now = /* @__PURE__ */ new Date();
	let age = now.getFullYear() - d.getFullYear();
	const m = now.getMonth() - d.getMonth();
	if (m < 0 || m === 0 && now.getDate() < d.getDate()) age--;
	return age >= 0 ? age : null;
}
function todayISO() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function money(value, currency = "SDG") {
	return `${Number(value ?? 0).toLocaleString(void 0, { maximumFractionDigits: 2 })} ${currency}`;
}
function formatDate(value) {
	if (!value) return "—";
	const d = new Date(value);
	return Number.isNaN(d.getTime()) ? String(value) : d.toISOString().slice(0, 10);
}
function formatDateTime(value) {
	if (!value) return "—";
	const d = new Date(value);
	if (Number.isNaN(d.getTime())) return String(value);
	return `${d.toISOString().slice(0, 10)} ${d.toTimeString().slice(0, 5)}`;
}
var BLOOD_GROUPS = [
	"A+",
	"A-",
	"B+",
	"B-",
	"AB+",
	"AB-",
	"O+",
	"O-"
];
var MARITAL = [
	"single",
	"married",
	"divorced",
	"widowed"
];
var EXPENSE_CATEGORIES = [
	"salaries",
	"rent",
	"electricity",
	"water",
	"internet",
	"maintenance",
	"other"
];
//#endregion
export { formatDate as a, todayISO as c, calcAge as i, EXPENSE_CATEGORIES as n, formatDateTime as o, MARITAL as r, money as s, BLOOD_GROUPS as t };
