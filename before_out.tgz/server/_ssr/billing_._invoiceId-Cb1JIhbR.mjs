import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useParams, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as rpc, c as useRows, i as rel, l as useSave, o as s, r as n, u as useSettings } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { ot as ArrowLeft } from "../_libs/lucide-react.mjs";
import { S as StatusBadge, b as SectionTitle, c as Empty, d as Field, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, v as PermissionGate, y as PrintButton } from "./kit-BTyT-Kis.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { a as formatDate, o as formatDateTime, s as money } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-By62ckhT.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/billing_._invoiceId-Cb1JIhbR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InvoicePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "billing.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicePageInner, {})
	});
}
function InvoicePageInner() {
	const { invoiceId } = useParams({ from: "/_authenticated/billing_/$invoiceId" });
	const { t } = useLang();
	const { can } = useAuth();
	const { currency, settings } = useSettings();
	const [amount, setAmount] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("cash");
	const [reference, setReference] = (0, import_react.useState)("");
	const invoiceQ = useRows(["invoice", invoiceId], () => supabase.from("invoices").select("id, invoice_number, invoice_date, status, total_amount, discount_amount, net_amount, paid_amount, notes, patients(id, full_name, mrn, phone), partners(name)").eq("id", invoiceId).limit(1));
	const invoice = (invoiceQ.data ?? [])[0];
	const itemsQ = useRows(["invoice-items", invoiceId], () => supabase.from("invoice_items").select("*").eq("invoice_id", invoiceId));
	const paymentsQ = useRows(["payments", invoiceId], () => supabase.from("payments").select("id, amount, payment_method, payment_date, created_at").eq("invoice_id", invoiceId).order("created_at", { ascending: false }));
	const pay = useSave(async () => {
		if (!invoice) throw new Error("Invoice not found");
		const value = Number(amount);
		if (!value || value <= 0) throw new Error(t("invalid_amount") || "مبلغ غير صالح");
		await rpc("post_invoice_payment", {
			_invoice_id: invoiceId,
			_amount: value,
			_method: method,
			_reference: reference.trim() || null
		});
		return null;
	}, {
		invalidate: [
			["invoice", invoiceId],
			["payments", invoiceId],
			["invoices"],
			["patient-receivables"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setAmount("");
			setReference("");
		}
	});
	if (invoiceQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	if (!invoice) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { label: t("no_data") });
	const patient = rel(invoice, "patients");
	const items = itemsQ.data ?? [];
	const balance = n(invoice, "net_amount") - n(invoice, "paid_amount");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: `${t("invoice")} ${s(invoice, "invoice_number")}`,
			subtitle: `${s(patient, "full_name")} · ${t("mrn")}: ${s(patient, "mrn")} · ${formatDate(s(invoice, "invoice_date"))}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(invoice, "status") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/billing",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), t("back")]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: invoiceQ.error ?? itemsQ.error ?? paymentsQ.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "print-area lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 border-b pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-semibold text-primary",
								children: settings["clinic_name"] || t("app_name")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									settings["clinic_address"] || "",
									" ",
									settings["clinic_phone"] || ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("items") }),
						items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							density: "compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("description") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("quantity") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("unit_price") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("total") })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(item, "item_name") || s(item, "description") || s(item, "item_type") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: n(item, "quantity")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(item, "unit_price"), currency) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(item, "total_price"), currency) })
							] }, s(item, "id"))) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: t("subtotal")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(invoice, "total_amount"), currency) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: t("discount")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(invoice, "discount_amount"), currency) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("net") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(invoice, "net_amount"), currency) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: t("paid")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(invoice, "paid_amount"), currency) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between font-semibold text-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("balance") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(balance, currency) })]
								})
							]
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [can("payments.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "no-print",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "grid gap-4 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("record_payment") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("amount"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									dir: "ltr",
									min: 0,
									value: amount,
									onChange: (event) => setAmount(event.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("payment_method"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: method,
									onValueChange: setMethod,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "cash",
											children: t("cash")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "bank",
											children: t("bank")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "bankak",
											children: "Bankak / بنكك"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "mobile",
											children: t("mobile_money")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "insurance",
											children: t("insurance")
										})
									] })]
								})
							}),
							(method === "bankak" || method === "mobile" || method === "bank") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("reference") || "Transaction reference",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: reference,
									onChange: (event) => setReference(event.target.value),
									placeholder: "Reference / transaction number"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: pay.isPending || balance <= 0,
								onClick: () => pay.mutate(void 0),
								children: pay.isPending ? t("saving") : t("save")
							})
						]
					})
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("payments") }), (paymentsQ.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2 text-sm",
						children: (paymentsQ.data ?? []).map((payment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between rounded-md border p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money(n(payment, "amount"), currency) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									t(s(payment, "payment_method")),
									" ·",
									" ",
									formatDateTime(s(payment, "created_at"))
								]
							})]
						}, s(payment, "id")))
					})]
				}) })]
			})]
		})
	] });
}
//#endregion
export { InvoicePage as component };
