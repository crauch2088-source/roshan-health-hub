import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useRows, i as rel, l as useSave, o as s } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { C as Plus, S as Printer } from "../_libs/lucide-react.mjs";
import { C as Textarea, c as Empty, d as Field, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, v as PermissionGate } from "./kit-BTyT-Kis.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-DM2RHhZs.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { a as formatDate, c as todayISO } from "./medical-CD1sc5il.mjs";
import { t as PatientPicker } from "./patient-picker-Dss6d_0U.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-By62ckhT.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/certificates-D5BrcK7q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function addDays(date, days) {
	const d = /* @__PURE__ */ new Date(`${date}T00:00:00`);
	d.setDate(d.getDate() + Math.max(days - 1, 0));
	return d.toISOString().slice(0, 10);
}
function CertificatesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "certificates.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CertificatesPageInner, {})
	});
}
function CertificatesPageInner() {
	const { lang } = useLang();
	const { can, user } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		patient_id: "",
		patient_name: "",
		type: "sick_leave",
		days: "1",
		start_date: todayISO(),
		diagnosis: "",
		notes: ""
	});
	const list = useRows(["certificates"], () => supabase.from("medical_certificates").select("*,patients(full_name,mrn,phone),users!medical_certificates_doctor_id_fkey(full_name)").is("deleted_at", null).order("created_at", { ascending: false }).limit(200));
	const endDate = (0, import_react.useMemo)(() => addDays(form.start_date, Number(form.days) || 1), [form.start_date, form.days]);
	const create = useSave(async () => {
		if (!form.patient_id) throw new Error(lang === "ar" ? "اختر المريض" : "Select patient");
		const diagnosis = [form.type === "sick_leave" ? lang === "ar" ? "إجازة مرضية" : "Sick leave" : lang === "ar" ? "لياقة طبية" : "Medical fitness", form.diagnosis.trim()].filter(Boolean).join(" — ");
		const { error } = await supabase.from("medical_certificates").insert({
			patient_id: form.patient_id,
			doctor_id: user?.id ?? null,
			diagnosis,
			start_date: form.start_date,
			end_date: endDate
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["certificates"]],
		successMessage: lang === "ar" ? "تم إصدار الشهادة" : "Certificate issued",
		onDone: () => {
			setOpen(false);
			setForm({
				patient_id: "",
				patient_name: "",
				type: "sick_leave",
				days: "1",
				start_date: todayISO(),
				diagnosis: "",
				notes: ""
			});
		}
	});
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const rows = list.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: lang === "ar" ? "الشهادات الطبية" : "Medical certificates",
				subtitle: lang === "ar" ? "إصدار وطباعة الشهادات" : "Issue and print medical certificates",
				children: can("certificates.create") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setOpen(true),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
						" ",
						lang === "ar" ? "شهادة جديدة" : "New certificate"
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0",
				children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "التاريخ" : "Date" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "المريض" : "Patient" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الفترة" : "Period" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الغرض / التشخيص" : "Purpose / diagnosis" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الطبيب" : "Doctor" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((c) => {
							const p = rel(c, "patients");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: formatDate(s(c, "created_at"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: s(p, "full_name")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									dir: "ltr",
									children: s(p, "mrn") || s(p, "phone")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
									dir: "ltr",
									children: [
										formatDate(s(c, "start_date")),
										" → ",
										formatDate(s(c, "end_date"))
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "max-w-[24rem]",
									children: s(c, "diagnosis") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(c, "users"), "full_name") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => window.print(),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" })
									})
								})
							] }, s(c, "id"));
						}) })]
					})
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: lang === "ar" ? "إصدار شهادة طبية" : "Issue medical certificate" }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: `${lang === "ar" ? "المريض" : "Patient"} *`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPicker, {
										value: form.patient_id ? {
											id: form.patient_id,
											full_name: form.patient_name || "",
											mrn: "",
											phone: ""
										} : null,
										onSelect: (p) => setForm({
											...form,
											patient_id: p?.id ?? "",
											patient_name: p?.full_name ?? ""
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: lang === "ar" ? "النوع" : "Type",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: form.type,
												onValueChange: (v) => setForm({
													...form,
													type: v
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: "sick_leave",
													children: lang === "ar" ? "إجازة مرضية" : "Sick leave"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: "fitness",
													children: lang === "ar" ? "لياقة طبية" : "Medical fitness"
												})] })]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: lang === "ar" ? "عدد الأيام" : "Days",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												dir: "ltr",
												type: "number",
												min: "1",
												value: form.days,
												onChange: (e) => setForm({
													...form,
													days: e.target.value
												})
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: lang === "ar" ? "بداية" : "Start date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												dir: "ltr",
												value: form.start_date,
												onChange: (e) => setForm({
													...form,
													start_date: e.target.value
												})
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: lang === "ar" ? "النهاية" : "End date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												dir: "ltr",
												value: endDate,
												readOnly: true
											})
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: lang === "ar" ? "التشخيص / الملاحظات الطبية" : "Diagnosis / medical notes",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: form.diagnosis,
										onChange: (e) => setForm({
											...form,
											diagnosis: e.target.value
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setOpen(false),
							children: lang === "ar" ? "إلغاء" : "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: create.isPending || !form.patient_id,
							onClick: () => create.mutate(void 0),
							children: create.isPending ? "Saving..." : lang === "ar" ? "إصدار" : "Issue"
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { CertificatesPage as component };
