import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/search-DYiW-B_v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Centralised search service.
*
* Every module (patients, visits, laboratory, pharmacy, certificates) goes
* through these helpers so that:
*   - free text is sanitised before it is embedded in a PostgREST filter,
*   - searches run in the DATABASE (`ilike` + `range`) instead of pulling a
*     whole table into React and filtering it there,
*   - patient lookups are MRN-first (a receptionist typing a card number
*     gets that exact patient at the top, not a fuzzy name match),
*   - pharmacy can accept a scanned barcode in the same input box.
*/
/** Strips characters that would break a PostgREST `or(...)` filter string. */
function sanitizeTerm(term) {
	return term.replace(/[,()%*\\"']/g, " ").replace(/\s+/g, " ").trim();
}
/** Debounces a fast-changing value (typing / scanning) for query keys. */
function useDebounced(value, delay = 350) {
	const [debounced, setDebounced] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		const id = setTimeout(() => setDebounced(value), delay);
		return () => clearTimeout(id);
	}, [value, delay]);
	return debounced;
}
/** MRN-ish input: mostly digits, optionally prefixed (e.g. `MRN-000123`). */
function looksLikeMrn(term) {
	return /^[A-Za-z]{0,5}[-/]?\d{1,}$/.test(term.trim());
}
var PATIENT_PICKER_COLUMNS = "id, full_name, mrn, phone";
/**
* Paged, MRN-first patient search. Shaped for `usePagedRows`.
*
* When the term looks like an MRN we first try an MRN prefix match; only if
* that finds nothing do we fall back to the broad name/phone/national-id
* search. That keeps the common reception case (typing a card number) to a
* single indexed lookup.
*/
async function searchPatientsPaged(opts) {
	const columns = opts.columns ?? "id, mrn, full_name, phone, gender, date_of_birth, national_id, created_at";
	const base = () => supabase.from("patients").select(columns, { count: "exact" }).is("deleted_at", null);
	const term = sanitizeTerm(opts.term);
	if (!term) return base().order("created_at", { ascending: false }).range(opts.from, opts.to);
	if (looksLikeMrn(term)) {
		const byMrn = await base().ilike("mrn", `${term}%`).order("mrn", { ascending: true }).range(opts.from, opts.to);
		if (!byMrn.error && (byMrn.count ?? 0) > 0) return byMrn;
	}
	return base().or(`mrn.ilike.%${term}%,full_name.ilike.%${term}%,phone.ilike.%${term}%,national_id.ilike.%${term}%`).order("created_at", { ascending: false }).range(opts.from, opts.to);
}
/** Short patient list for pickers/combos — never a full-table scan. */
function patientPickerQuery(term, limit = 30) {
	const clean = sanitizeTerm(term);
	let q = supabase.from("patients").select(PATIENT_PICKER_COLUMNS).is("deleted_at", null).order("created_at", { ascending: false }).limit(limit);
	if (clean.length >= 2) q = q.or(`mrn.ilike.%${clean}%,full_name.ilike.%${clean}%,phone.ilike.%${clean}%,national_id.ilike.%${clean}%`);
	return q;
}
/**
* Applies a patient-scoped text filter to a query that embeds
* `patients!inner(...)` — used by the laboratory and pharmacy worklists so
* their search happens server-side across the joined patient row.
*/
function patientEmbeddedFilter(query, term) {
	const clean = sanitizeTerm(term);
	if (!clean) return query;
	return query.or(`mrn.ilike.%${clean}%,full_name.ilike.%${clean}%,phone.ilike.%${clean}%`, { referencedTable: "patients" });
}
//#endregion
export { useDebounced as a, searchPatientsPaged as i, patientPickerQuery as n, sanitizeTerm as r, patientEmbeddedFilter as t };
