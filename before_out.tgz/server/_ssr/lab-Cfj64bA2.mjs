import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useRows, i as rel, o as s } from "./db-DHEMzLVy.mjs";
import { i as useLang } from "./router-STLCkGVF.mjs";
import { g as Search } from "../_libs/lucide-react.mjs";
import { S as StatusBadge, c as Empty, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, u as ExportButtons, v as PermissionGate } from "./kit-BTyT-Kis.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { o as formatDateTime } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-By62ckhT.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/lab-Cfj64bA2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"all",
	"ordered",
	"sample_collected",
	"in_progress",
	"completed",
	"verified"
];
function LabPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "lab.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabPageInner, {})
	});
}
function LabPageInner() {
	const { t, lang } = useLang();
	const labelOf = (key) => t(key) === key ? key : t(key);
	const testNames = (o) => (o["lab_order_items"] ?? []).map((i) => {
		const test = rel(i, "lab_tests");
		return lang === "ar" ? s(test, "name_ar") || s(test, "name") : s(test, "name");
	}).join(", ") || "—";
	const [status, setStatus] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const orders = useRows(["lab-orders", status], () => {
		let q = supabase.from("lab_orders").select("id,status,created_at,ordered_at,priority,visit_id,patients(id,full_name,mrn,phone),users!lab_orders_ordered_by_fkey(full_name),lab_order_items(id,status,price,lab_tests(id,name,name_ar))").is("deleted_at", null).order("created_at", { ascending: false }).limit(300);
		if (status !== "all") q = q.eq("status", status);
		return q;
	}, {
		refetchInterval: 15e3,
		keepPrevious: true
	});
	if (orders.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const rows = (orders.data ?? []).filter((o) => {
		const p = rel(o, "patients");
		const term = search.trim().toLowerCase();
		if (!term) return true;
		const tests = (o["lab_order_items"] ?? []).map((i) => {
			const t = rel(i, "lab_tests");
			return `${s(t, "name")} ${s(t, "name_ar")}`;
		}).join(" ");
		return `${s(p, "full_name")} ${s(p, "mrn")} ${s(p, "phone")} ${s(o, "id")} ${s(o, "visit_id")} ${tests}`.toLowerCase().includes(term);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
				title: t("laboratory"),
				subtitle: lang === "ar" ? "قائمة المختبر وإدخال النتائج" : "Laboratory worklist and result entry",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-full sm:w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "ps-9",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: lang === "ar" ? "المريض أو الفحص" : "Patient or test"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: status,
						onValueChange: setStatus,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-full sm:w-44",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: STATUSES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: x,
							children: t(x)
						}, x)) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
						rows,
						filename: "roshan-lab-orders"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: orders.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0",
				children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: t("no_data"),
					description: lang === "ar" ? "لا طلبات تحاليل مطابقة." : "No matching lab orders."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y md:hidden",
					"aria-label": t("laboratory"),
					children: rows.map((o) => {
						const p = rel(o, "patients");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/lab/$orderId",
							params: { orderId: s(o, "id") },
							className: "block space-y-1.5 p-3 outline-none hover:bg-muted/50 focus-visible:bg-muted/50 active:bg-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate font-medium",
											children: s(p, "full_name")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											dir: "ltr",
											children: s(p, "mrn")
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(o, "status") })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "line-clamp-2 text-sm",
									children: testNames(o)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "ltr",
										children: formatDateTime(s(o, "created_at"))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: labelOf(s(o, "priority") || "normal") })]
								})
							]
						}) }, s(o, "id"));
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden overflow-x-auto md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("test") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("priority") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "text-end" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((o) => {
							const p = rel(o, "patients");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									children: formatDateTime(s(o, "created_at"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: s(p, "full_name")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									dir: "ltr",
									children: s(p, "mrn")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "max-w-[24rem]",
									children: testNames(o)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: labelOf(s(o, "priority") || "normal") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(o, "status") }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/lab/$orderId",
											params: { orderId: s(o, "id") },
											children: t("open")
										})
									})
								})
							] }, s(o, "id"));
						}) })]
					})
				})] })
			}) })
		]
	});
}
//#endregion
export { LabPage as component };
