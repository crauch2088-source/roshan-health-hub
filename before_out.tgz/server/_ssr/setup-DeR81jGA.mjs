import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as rpc } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { K as CircleCheck } from "../_libs/lucide-react.mjs";
import { a as CardDescription, d as Field, i as CardContent, l as ErrorBox, n as Button, o as CardHeader, p as Input, r as Card, s as CardTitle } from "./kit-BTyT-Kis.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/setup-DeR81jGA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SetupPage() {
	const { t, lang } = useLang();
	const navigate = useNavigate();
	const { refresh } = useAuth();
	const [checking, setChecking] = (0, import_react.useState)(true);
	const [required, setRequired] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		full_name: "",
		email: "",
		phone: "",
		password: ""
	});
	(0, import_react.useEffect)(() => {
		rpc("setup_required").then((need) => setRequired(Boolean(need))).catch((e) => setError(e.message)).finally(() => setChecking(false));
	}, []);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		try {
			const { data: signUp, error: suErr } = await supabase.auth.signUp({
				email: form.email.trim(),
				password: form.password,
				options: { emailRedirectTo: window.location.origin }
			});
			if (suErr && !/already/i.test(suErr.message)) throw new Error(suErr.message);
			if (!signUp?.session) {
				const { error: siErr } = await supabase.auth.signInWithPassword({
					email: form.email.trim(),
					password: form.password
				});
				if (siErr) throw new Error(lang === "ar" ? `${siErr.message} — إذا كان تأكيد البريد مطلوباً، افتح رابط التأكيد ثم أعد المحاولة.` : `${siErr.message} — if email confirmation is enabled, confirm the address then retry.`);
			}
			await rpc("bootstrap_super_admin", {
				_full_name: form.full_name,
				_email: form.email.trim(),
				_phone: form.phone
			});
			await refresh();
			navigate({
				to: "/dashboard",
				replace: true
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : String(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/40 to-background px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-col items-center gap-3 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/roshan-logo.png",
					alt: t("app_name"),
					className: "h-20 object-contain"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-bold",
					children: t("first_run_setup")
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: t("create_super_admin") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: lang === "ar" ? "يتم إنشاء حساب واحد فقط. بعد ذلك يقوم المدير العام بإنشاء بقية المستخدمين." : "Only one account is created here. The Super Admin then creates all other users." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error }), checking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: t("loading")
			}) : !required ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-lg border border-success/40 bg-success/10 p-3 text-sm text-success",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }),
						" ",
						t("setup_done")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: () => void navigate({ to: "/auth" }),
					children: t("sign_in")
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("full_name"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: form.full_name,
							onChange: (e) => setForm({
								...form,
								full_name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("email"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							dir: "ltr",
							required: true,
							value: form.email,
							onChange: (e) => setForm({
								...form,
								email: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("phone"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							dir: "ltr",
							value: form.phone,
							onChange: (e) => setForm({
								...form,
								phone: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("password"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							dir: "ltr",
							required: true,
							minLength: 8,
							value: form.password,
							onChange: (e) => setForm({
								...form,
								password: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: busy,
						children: busy ? t("saving") : t("create_super_admin")
					})
				]
			})] })] })]
		})
	});
}
//#endregion
export { SetupPage as component };
