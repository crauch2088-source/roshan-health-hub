import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as dbError, r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/db-DHEMzLVy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Runs a PostgREST builder and throws a readable error. */
async function run(builder) {
	const { data, error } = await builder;
	if (error) throw new Error(dbError(error));
	return data ?? [];
}
/** Read helper: any table, any filter chain. */
function useRows(key, build, options) {
	return useQuery({
		queryKey: key,
		...options?.keepPrevious ? { placeholderData: keepPreviousData } : {},
		queryFn: async () => await run(build()),
		enabled: options?.enabled ?? true,
		refetchInterval: options?.refetchInterval ?? false,
		retry: false
	});
}
/**
* Read helper for large/growing tables: pages results at the database
* level using PostgREST's `.range()` + an exact count, instead of
* fetching an entire table and slicing/searching it in React.
*/
function usePagedRows(key, build, page, pageSize, options) {
	const safePage = Math.max(1, page);
	const from = (safePage - 1) * pageSize;
	const to = from + pageSize - 1;
	const query = useQuery({
		queryKey: [
			...key,
			"page",
			safePage,
			pageSize
		],
		queryFn: async () => {
			const { data, error, count } = await build({
				from,
				to
			});
			if (error) throw new Error(dbError(error));
			return {
				rows: data ?? [],
				count: count ?? null
			};
		},
		enabled: options?.enabled ?? true,
		retry: false,
		placeholderData: (prev) => prev
	});
	const count = query.data?.count ?? null;
	const rows = query.data?.rows ?? [];
	const rowCount = Array.isArray(rows) ? rows.length : 0;
	const pageCount = count != null ? Math.max(1, Math.ceil(count / pageSize)) : null;
	return {
		...query,
		rows,
		count,
		page: safePage,
		pageSize,
		pageCount,
		hasPrev: safePage > 1,
		hasNext: pageCount != null ? safePage < pageCount : rowCount === pageSize
	};
}
/** Write helper with toast + cache invalidation. */
function useSave(fn, opts) {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: async (vars) => fn(vars),
		onSuccess: (result) => {
			if (opts?.invalidate) for (const key of opts.invalidate) qc.invalidateQueries({ queryKey: key });
			if (opts?.successMessage) toast.success(opts.successMessage);
			opts?.onDone?.(result);
		},
		onError: (e) => toast.error(e.message)
	});
}
async function rpc(name, args) {
	const { data, error } = await supabase.rpc(name, args ?? {});
	if (error) throw new Error(dbError(error));
	return data;
}
/** System settings as a flat map. */
function useSettings() {
	const query = useRows(["system_settings"], () => supabase.from("system_settings").select("setting_key, setting_value"));
	const settings = (0, import_react.useMemo)(() => {
		const map = {};
		const dataList = Array.isArray(query.data) ? query.data : [];
		for (const r of dataList) map[String(r["setting_key"])] = String(r["setting_value"] ?? "");
		return map;
	}, [query.data]);
	return {
		...query,
		settings,
		currency: settings["currency"] || "SDG"
	};
}
function csvExport(rows, filename) {
	const first = rows[0];
	if (!first) {
		toast.error("No records to export");
		return;
	}
	const headers = Object.keys(first);
	const escape = (v) => `"${String(v ?? "").replace(/"/g, "\"\"")}"`;
	const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h])).join(","))].join("\n");
	const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = `${filename}.csv`;
	a.click();
	URL.revokeObjectURL(url);
}
function s(row, key) {
	const v = row?.[key];
	return v == null ? "" : String(v);
}
function n(row, key) {
	const v = Number(row?.[key]);
	return Number.isFinite(v) ? v : 0;
}
function b(row, key) {
	return Boolean(row?.[key]);
}
function rel(row, key) {
	const v = row?.[key];
	return Array.isArray(v) ? v[0] ?? null : v ?? null;
}
//#endregion
export { rpc as a, useRows as c, rel as i, useSave as l, csvExport as n, s as o, n as r, usePagedRows as s, b as t, useSettings as u };
