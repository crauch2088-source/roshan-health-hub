import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as rpc, c as useRows, i as rel, l as useSave, o as s, r as n, u as useSettings } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { C as Plus, m as ShieldCheck } from "../_libs/lucide-react.mjs";
import { S as StatusBadge, c as Empty, d as Field, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, u as ExportButtons, v as PermissionGate, x as StatCard } from "./kit-BTyT-Kis.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-DM2RHhZs.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { a as formatDate, s as money } from "./medical-CD1sc5il.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-BZt1-z9l.mjs";
import { t as PatientPicker } from "./patient-picker-Dss6d_0U.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-By62ckhT.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/insurance-C7A0258e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Allowed forward transitions — mirrors update_insurance_claim_status()'s own check. */
var NEXT_CLAIM_STATUS = {
	draft: ["submitted"],
	submitted: ["under_review"],
	under_review: [
		"approved",
		"partially_approved",
		"rejected"
	],
	approved: ["paid"],
	partially_approved: ["paid"]
};
async function calculateInsuranceCoverage(args) {
	return (await rpc("fn_calculate_insurance_coverage", {
		_patient_insurance_id: args.patientInsuranceId,
		_service_type: args.serviceType,
		_reference_id: args.referenceId ?? null,
		_generic_name: args.genericName ?? null,
		_gross_amount: args.grossAmount
	}))[0] ?? {
		covered_amount: 0,
		patient_amount: args.grossAmount,
		requires_prior_auth: false,
		excluded: false,
		coverage_rule_id: null
	};
}
function createInsuranceClaim(args) {
	return rpc("create_insurance_claim", {
		_patient_insurance_id: args.patientInsuranceId,
		_invoice_id: args.invoiceId,
		_items: args.items,
		_notes: args.notes ?? null
	});
}
function updateInsuranceClaimStatus(args) {
	return rpc("update_insurance_claim_status", {
		_claim_id: args.claimId,
		_new_status: args.newStatus,
		_approved_amount: args.approvedAmount ?? null,
		_notes: args.notes ?? null
	});
}
function postInsuranceClaimPayment(args) {
	return rpc("post_insurance_claim_payment", {
		_claim_id: args.claimId,
		_amount: args.amount,
		_method: args.method ?? "bank",
		_reference: args.reference ?? null
	});
}
function InsurancePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "insurance.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsurancePageInner, {})
	});
}
function InsurancePageInner() {
	const { t } = useLang();
	const { currency } = useSettings();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: t("insurance"),
		subtitle: t("insurance_subtitle")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		defaultValue: "companies",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
				className: "mb-4 flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "companies",
						children: t("insurance_companies")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "plans",
						children: t("insurance_plans")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "membership",
						children: t("patient_insurance")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "claims",
						children: t("insurance_claims")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "companies",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompaniesTab, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "plans",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlansTab, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "membership",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MembershipTab, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "claims",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimsTab, { currency })
			})
		]
	})] });
}
function CompaniesTab() {
	const { t } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		contact_person: "",
		phone: "",
		email: ""
	});
	const list = useRows(["insurance-companies"], () => supabase.from("insurance_companies").select("id, name, contact_person, phone, email, active").is("deleted_at", null).order("name", { ascending: true }));
	const create = useSave(async () => {
		if (!form.name.trim()) throw new Error(t("name_required"));
		const { error } = await supabase.from("insurance_companies").insert({
			name: form.name.trim(),
			contact_person: form.contact_person || null,
			phone: form.phone || null,
			email: form.email || null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["insurance-companies"], ["insurance-companies-picker"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm({
				name: "",
				contact_person: "",
				phone: "",
				email: ""
			});
		}
	});
	const toggleActive = useSave(async (row) => {
		const { error } = await supabase.from("insurance_companies").update({ active: !row["active"] }).eq("id", s(row, "id"));
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["insurance-companies"]],
		successMessage: t("saved")
	});
	const rows = list.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-insurance-companies"
			}), can("insurance.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t("add")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("insurance_companies") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("name")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("contact_person"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.contact_person,
									onChange: (e) => setForm({
										...form,
										contact_person: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("phone"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.phone,
									onChange: (e) => setForm({
										...form,
										phone: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("email"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.email,
									onChange: (e) => setForm({
										...form,
										email: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.name || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				] })]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("contact_person") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("phone") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-muted-foreground" }),
								" ",
								s(c, "name")
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(c, "contact_person") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(c, "phone") || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c["active"] ? "active" : "inactive" }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "no-print text-end",
						children: can("insurance.update") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: () => toggleActive.mutate(c),
							children: c["active"] ? t("deactivate") : t("activate")
						}) : null
					})
				] }, s(c, "id"))) })]
			})
		}) })
	] });
}
function PlansTab() {
	const { t } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		company_id: "",
		name: "",
		default_coverage_percent: "70"
	});
	const companies = useRows(["insurance-companies-picker"], () => supabase.from("insurance_companies").select("id, name").is("deleted_at", null).eq("active", true).order("name", { ascending: true }));
	const list = useRows(["insurance-plans"], () => supabase.from("insurance_plans").select("id, name, default_coverage_percent, requires_prior_auth, active, insurance_companies(name)").is("deleted_at", null).order("name", { ascending: true }));
	const create = useSave(async () => {
		if (!form.company_id || !form.name.trim()) throw new Error(t("name_required"));
		const { error } = await supabase.from("insurance_plans").insert({
			company_id: form.company_id,
			name: form.name.trim(),
			default_coverage_percent: Number(form.default_coverage_percent) || 0
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["insurance-plans"], ["insurance-plans-picker"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setForm({
				company_id: "",
				name: "",
				default_coverage_percent: "70"
			});
		}
	});
	const rows = list.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-insurance-plans"
			}), can("insurance.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t("add")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("insurance_plans") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("insurance_companies")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									...form.company_id ? { value: form.company_id } : {},
									onValueChange: (v) => setForm({
										...form,
										company_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (companies.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s(c, "id"),
										children: s(c, "name")
									}, s(c, "id"))) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("name")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("default_coverage_percent"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									dir: "ltr",
									value: form.default_coverage_percent,
									onChange: (e) => setForm({
										...form,
										default_coverage_percent: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.company_id || !form.name || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				] })]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("name") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("insurance_companies") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("default_coverage_percent") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: s(p, "name")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(p, "insurance_companies"), "name") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						dir: "ltr",
						children: [n(p, "default_coverage_percent"), "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: p["active"] ? "active" : "inactive" }) })
				] }, s(p, "id"))) })]
			})
		}) })
	] });
}
function MembershipTab() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [patient, setPatient] = (0, import_react.useState)(null);
	const [companyId, setCompanyId] = (0, import_react.useState)("");
	const [planId, setPlanId] = (0, import_react.useState)("");
	const [policyNumber, setPolicyNumber] = (0, import_react.useState)("");
	const [memberNumber, setMemberNumber] = (0, import_react.useState)("");
	const [expiryDate, setExpiryDate] = (0, import_react.useState)("");
	const companies = useRows(["insurance-companies-picker"], () => supabase.from("insurance_companies").select("id, name").is("deleted_at", null).eq("active", true).order("name", { ascending: true }));
	const plans = useRows(["insurance-plans-picker", companyId], () => supabase.from("insurance_plans").select("id, name").eq("company_id", companyId).is("deleted_at", null).eq("active", true).order("name", { ascending: true }), { enabled: Boolean(companyId) });
	const list = useRows(["patient-insurance-list"], () => supabase.from("patient_insurance").select("id, policy_number, member_number, is_primary, status, expiry_date, patients(full_name, mrn), insurance_companies(name), insurance_plans(name)").is("deleted_at", null).order("created_at", { ascending: false }).limit(300));
	const create = useSave(async () => {
		if (!patient || !companyId || !planId) throw new Error(lang === "ar" ? "اختر المريض والشركة والخطة" : "Select patient, company and plan");
		const { error } = await supabase.from("patient_insurance").insert({
			patient_id: patient.id,
			company_id: companyId,
			plan_id: planId,
			policy_number: policyNumber || null,
			member_number: memberNumber || null,
			expiry_date: expiryDate || null
		});
		if (error) throw new Error(error.message);
		return null;
	}, {
		invalidate: [["patient-insurance-list"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setPatient(null);
			setCompanyId("");
			setPlanId("");
			setPolicyNumber("");
			setMemberNumber("");
			setExpiryDate("");
		}
	});
	const rows = list.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-patient-insurance"
			}), can("insurance.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t("add")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("patient_insurance") }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: `${t("patient")} *`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPicker, {
										value: patient,
										onSelect: setPatient
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: `${t("insurance_companies")} *`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										...companyId ? { value: companyId } : {},
										onValueChange: (v) => {
											setCompanyId(v);
											setPlanId("");
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (companies.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: s(c, "id"),
											children: s(c, "name")
										}, s(c, "id"))) })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: `${t("insurance_plans")} *`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										...planId ? { value: planId } : {},
										onValueChange: setPlanId,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (plans.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: s(p, "id"),
											children: s(p, "name")
										}, s(p, "id"))) })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("policy_number"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										dir: "ltr",
										value: policyNumber,
										onChange: (e) => setPolicyNumber(e.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("member_number"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										dir: "ltr",
										value: memberNumber,
										onChange: (e) => setMemberNumber(e.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t("expiry_date"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										dir: "ltr",
										value: expiryDate,
										onChange: (e) => setExpiryDate(e.target.value)
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setOpen(false),
							children: t("cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !patient || !companyId || !planId || create.isPending,
							onClick: () => create.mutate(void 0),
							children: create.isPending ? t("saving") : t("save")
						})] })
					]
				})]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("insurance_companies") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("insurance_plans") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("policy_number") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("expiry_date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						className: "font-medium",
						children: [s(rel(r, "patients"), "full_name"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ms-1 text-xs text-muted-foreground",
							dir: "ltr",
							children: [
								"(",
								s(rel(r, "patients"), "mrn"),
								")"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(r, "insurance_companies"), "name") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(r, "insurance_plans"), "name") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "policy_number") || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "expiry_date") ? formatDate(s(r, "expiry_date")) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(r, "status") }) })
				] }, s(r, "id"))) })]
			})
		}) })
	] });
}
function ClaimsTab({ currency }) {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [patientInsuranceId, setPatientInsuranceId] = (0, import_react.useState)("");
	const [items, setItems] = (0, import_react.useState)([]);
	const [itemForm, setItemForm] = (0, import_react.useState)({
		service_type: "consultation",
		description: "",
		gross_amount: "0"
	});
	const [decision, setDecision] = (0, import_react.useState)(null);
	const [approvedAmount, setApprovedAmount] = (0, import_react.useState)("0");
	const [payTarget, setPayTarget] = (0, import_react.useState)(null);
	const [payAmount, setPayAmount] = (0, import_react.useState)("0");
	const membership = useRows(["patient-insurance-picker"], () => supabase.from("patient_insurance").select("id, patients(full_name, mrn), insurance_companies(name)").eq("status", "active").is("deleted_at", null).order("created_at", { ascending: false }).limit(200));
	const claims = useRows(["insurance-claims"], () => supabase.from("insurance_claims").select("id, claim_number, status, submitted_amount, approved_amount, paid_amount, submitted_at, patient_insurance(patients(full_name, mrn), insurance_companies(name))").is("deleted_at", null).order("created_at", { ascending: false }).limit(300));
	async function addItem() {
		const gross = Number(itemForm.gross_amount) || 0;
		if (!itemForm.description.trim() || gross <= 0 || !patientInsuranceId) return;
		const coverage = await calculateInsuranceCoverage({
			patientInsuranceId,
			serviceType: itemForm.service_type,
			grossAmount: gross
		});
		setItems((prev) => [...prev, {
			service_type: itemForm.service_type,
			reference_id: null,
			description: itemForm.description.trim(),
			gross_amount: gross,
			covered_amount: coverage.covered_amount,
			patient_amount: coverage.patient_amount,
			coverage_rule_id: coverage.coverage_rule_id
		}]);
		setItemForm({
			service_type: "consultation",
			description: "",
			gross_amount: "0"
		});
	}
	const create = useSave(async () => {
		if (!patientInsuranceId || items.length === 0) throw new Error(lang === "ar" ? "اختر تأمين المريض وأضف بنوداً" : "Select patient insurance and add line items");
		await createInsuranceClaim({
			patientInsuranceId,
			invoiceId: null,
			items
		});
		return null;
	}, {
		invalidate: [["insurance-claims"]],
		successMessage: t("saved"),
		onDone: () => {
			setOpen(false);
			setPatientInsuranceId("");
			setItems([]);
		}
	});
	const transition = useSave(async () => {
		if (!decision) return null;
		await updateInsuranceClaimStatus({
			claimId: s(decision.claim, "id"),
			newStatus: decision.status,
			approvedAmount: ["approved", "partially_approved"].includes(decision.status) ? Number(approvedAmount) || 0 : null
		});
		return null;
	}, {
		invalidate: [["insurance-claims"]],
		successMessage: t("saved"),
		onDone: () => {
			setDecision(null);
			setApprovedAmount("0");
		}
	});
	const pay = useSave(async () => {
		if (!payTarget) return null;
		const amt = Number(payAmount) || 0;
		if (amt <= 0) throw new Error(t("invalid_quantity"));
		await postInsuranceClaimPayment({
			claimId: s(payTarget, "id"),
			amount: amt
		});
		return null;
	}, {
		invalidate: [
			["insurance-claims"],
			["cashbox-balance"],
			["cashbox-transactions"]
		],
		successMessage: t("saved"),
		onDone: () => {
			setPayTarget(null);
			setPayAmount("0");
		}
	});
	const rows = claims.data ?? [];
	const pendingCount = rows.filter((r) => ["submitted", "under_review"].includes(s(r, "status"))).length;
	const outstandingApproved = rows.reduce((sum, r) => {
		if (!["approved", "partially_approved"].includes(s(r, "status"))) return sum;
		return sum + (n(r, "approved_amount") - n(r, "paid_amount"));
	}, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-insurance-claims"
			}), can("insurance.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => setOpen(true),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
					" ",
					t("new_claim")
				]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: claims.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: t("pending_claims"),
				value: String(pendingCount),
				tone: "warning"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: t("outstanding_insurance"),
				value: money(outstandingApproved, currency),
				tone: "warning"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: claims.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("claim_number") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("insurance_companies") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("net") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("approved_amount") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "no-print" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((c) => {
					const pi = rel(c, "patient_insurance");
					const status = s(c, "status");
					const nextOptions = NEXT_CLAIM_STATUS[status] ?? [];
					const outstanding = n(c, "approved_amount") - n(c, "paid_amount");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							className: "font-mono text-xs",
							children: s(c, "claim_number")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: s(rel(pi, "patients"), "full_name") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(pi, "insurance_companies"), "name") || "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: money(n(c, "submitted_amount"), currency) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c["approved_amount"] != null ? money(n(c, "approved_amount"), currency) : "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "no-print",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-1.5",
								children: [can("insurance.update") && nextOptions.length > 0 ? nextOptions.map((next) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => {
										setDecision({
											claim: c,
											status: next
										});
										setApprovedAmount(String(n(c, "submitted_amount")));
									},
									children: t(next)
								}, next)) : null, can("insurance.update") && status !== "paid" && ["approved", "partially_approved"].includes(status) && outstanding > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => {
										setPayTarget(c);
										setPayAmount(String(outstanding));
									},
									children: t("record_payment")
								}) : null]
							})
						})
					] }, s(c, "id"));
				}) })]
			})
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-h-[90vh] max-w-2xl overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("new_claim") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("patient_insurance")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									...patientInsuranceId ? { value: patientInsuranceId } : {},
									onValueChange: setPatientInsuranceId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (membership.data ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: s(m, "id"),
										children: [
											s(rel(m, "patients"), "full_name"),
											" —",
											" ",
											s(rel(m, "insurance_companies"), "name")
										]
									}, s(m, "id"))) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground",
										children: t("add_item")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2 sm:grid-cols-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: itemForm.service_type,
												onValueChange: (v) => setItemForm({
													...itemForm,
													service_type: v
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "consultation",
														children: t("consultation")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "lab",
														children: t("laboratory")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "medicine",
														children: t("medicines")
													})
												] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												className: "sm:col-span-2",
												placeholder: t("description"),
												value: itemForm.description,
												onChange: (e) => setItemForm({
													...itemForm,
													description: e.target.value
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												dir: "ltr",
												placeholder: t("amount"),
												value: itemForm.gross_amount,
												onChange: (e) => setItemForm({
													...itemForm,
													gross_amount: e.target.value
												})
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "outline",
										size: "sm",
										className: "mt-2",
										disabled: !patientInsuranceId || !itemForm.description.trim() || !itemForm.gross_amount,
										onClick: () => void addItem(),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }),
											" ",
											t("add_item")
										]
									})
								]
							}),
							items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
								density: "compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("description") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("amount") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("covered_amount") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient_amount") })
								] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: it.description }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: money(it.gross_amount, currency)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: money(it.covered_amount, currency)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										dir: "ltr",
										children: money(it.patient_amount, currency)
									})
								] }, idx)) })]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !patientInsuranceId || items.length === 0 || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(decision),
			onOpenChange: (o) => o ? null : setDecision(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: decision ? t(decision.status) : "" }) }),
				decision && ["approved", "partially_approved"].includes(decision.status) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `${t("approved_amount")} *`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						dir: "ltr",
						value: approvedAmount,
						onChange: (e) => setApprovedAmount(e.target.value)
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: t("confirm_status_change")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setDecision(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: transition.isPending,
					onClick: () => transition.mutate(void 0),
					children: transition.isPending ? t("saving") : t("save")
				})] })
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(payTarget),
			onOpenChange: (o) => o ? null : setPayTarget(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("record_payment") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `${t("amount")} *`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						dir: "ltr",
						value: payAmount,
						onChange: (e) => setPayAmount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setPayTarget(null),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: pay.isPending,
					onClick: () => pay.mutate(void 0),
					children: pay.isPending ? t("saving") : t("save")
				})] })
			] })
		})
	] });
}
//#endregion
export { InsurancePage as component };
