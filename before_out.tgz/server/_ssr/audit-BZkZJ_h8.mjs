import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as rel, o as s, s as usePagedRows } from "./db-DHEMzLVy.mjs";
import { i as useLang } from "./router-STLCkGVF.mjs";
import { _ as Pager, c as Empty, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, p as Input, r as Card, u as ExportButtons, v as PermissionGate } from "./kit-BTyT-Kis.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { o as formatDateTime } from "./medical-CD1sc5il.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/audit-BZkZJ_h8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 50;
/** Keeps free-text search safe to embed in a PostgREST `.or()` filter string. */
function sanitizeSearch(term) {
	return term.replace(/[,()%]/g, "").trim();
}
function AuditPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "audit.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditPageInner, {})
	});
}
function AuditPageInner() {
	const { t } = useLang();
	const [page, setPage] = (0, import_react.useState)(1);
	const [q, setQ] = (0, import_react.useState)("");
	const list = usePagedRows(["audit", q], ({ from, to }) => {
		let query = supabase.from("audit_logs").select("id, action, table_name, created_at, users(full_name)", { count: "exact" });
		const term = sanitizeSearch(q);
		if (term) query = query.or(`action.ilike.%${term}%,table_name.ilike.%${term}%`);
		return query.order("created_at", { ascending: false }).range(from, to);
	}, page, PAGE_SIZE);
	const rows = list.rows;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
			title: t("audit_log"),
			subtitle: t("recent_activity"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: t("search"),
				value: q,
				onChange: (e) => {
					setQ(e.target.value);
					setPage(1);
				},
				className: "w-56"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
				rows,
				filename: "roshan-audit"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "p-0",
			children: [list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				density: "compact",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("date") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("user") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("action") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("table") })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: formatDateTime(s(r, "created_at"))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(rel(r, "users"), "full_name") || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(r, "action") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						dir: "ltr",
						children: s(r, "table_name")
					})
				] }, s(r, "id"))) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				page: list.page,
				pageCount: list.pageCount,
				count: list.count,
				pageSize: PAGE_SIZE,
				hasPrev: list.hasPrev,
				hasNext: list.hasNext,
				isFetching: list.isFetching,
				onPrev: () => setPage((p) => Math.max(1, p - 1)),
				onNext: () => setPage((p) => p + 1)
			})]
		}) })
	] });
}
//#endregion
export { AuditPage as component };
