import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as createServerFn, n as getServerFnById, o as TSS_SERVER_FUNCTION } from "./server-B-1Y5mGi.mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
import { c as useRows, i as rel, l as useSave, o as s, t as b } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { C as Plus } from "../_libs/lucide-react.mjs";
import { c as Empty, d as Field, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, v as PermissionGate } from "./kit-BTyT-Kis.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogFooter, t as Dialog } from "./dialog-DM2RHhZs.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-By62ckhT.mjs";
import { t as Switch } from "./switch-COhhY_cj.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/users-DbAghAhQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var CreateStaffUserInput = objectType({
	accessToken: stringType().min(1),
	full_name: stringType().trim().min(1, "Full name is required"),
	email: stringType().trim().toLowerCase().email("Invalid email"),
	password: stringType().min(8, "Password must be at least 8 characters"),
	phone: stringType().trim().optional(),
	role_id: stringType().uuid("Invalid role")
});
var createStaffUser = createServerFn({ method: "POST" }).validator(CreateStaffUserInput).handler(createSsrRpc("2e90f3cf3e8e7f72fb0495863df47321372aa4c10d525dafcae66416bb53c7d5"));
function UsersPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "users.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersPageInner, {})
	});
}
function UsersPageInner() {
	const { t, lang } = useLang();
	const { can } = useAuth();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		full_name: "",
		email: "",
		password: "",
		phone: "",
		role_id: ""
	});
	const list = useRows(["users"], () => supabase.from("users").select("id, full_name, email, phone, active, auth_user_id, roles(id, code, name, name_ar)").is("deleted_at", null).order("created_at", { ascending: false }));
	const roles = useRows(["roles"], () => supabase.from("roles").select("id, code, name, name_ar"));
	const create = useSave(async () => {
		const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
		const accessToken = sessionData.session?.access_token;
		if (sessionError || !accessToken) throw new Error("Your session has expired. Please sign in again.");
		await createStaffUser({ data: {
			accessToken,
			full_name: form.full_name,
			email: form.email,
			password: form.password,
			phone: form.phone,
			role_id: form.role_id
		} });
		return null;
	}, {
		invalidate: [["users"]],
		successMessage: t("user_created"),
		onDone: () => {
			setOpen(false);
			setForm({
				full_name: "",
				email: "",
				password: "",
				phone: "",
				role_id: ""
			});
		}
	});
	const toggle = useSave(async ({ id, active }) => {
		const { error } = await supabase.from("users").update({ active }).eq("id", id);
		if (error) throw new Error(error.message);
		return null;
	}, { invalidate: [["users"]] });
	const rows = list.data ?? [];
	if (list.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: t("users"),
			subtitle: t("staff_accounts"),
			children: can("users.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t("add")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("users") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("full_name")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.full_name,
									onChange: (e) => setForm({
										...form,
										full_name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("email")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									dir: "ltr",
									value: form.email,
									onChange: (e) => setForm({
										...form,
										email: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("password")} * (min. 8 characters)`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									dir: "ltr",
									minLength: 8,
									value: form.password,
									onChange: (e) => setForm({
										...form,
										password: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: t("phone"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									dir: "ltr",
									value: form.phone,
									onChange: (e) => setForm({
										...form,
										phone: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `${t("role")} *`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									...form.role_id ? { value: form.role_id } : {},
									onValueChange: (v) => setForm({
										...form,
										role_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("role") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (roles.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s(r, "id"),
										children: lang === "ar" ? s(r, "name_ar") || s(r, "name") : s(r, "name")
									}, s(r, "id"))) })]
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !form.full_name || !form.email || form.password.length < 8 || !form.role_id || create.isPending,
						onClick: () => create.mutate(void 0),
						children: create.isPending ? t("saving") : t("save")
					})] })
				] })]
			}) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: list.error }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y md:hidden",
				"aria-label": t("users"),
				children: rows.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "space-y-1.5 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: s(u, "full_name")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted-foreground",
								dir: "ltr",
								children: s(u, "email")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: b(u, "active"),
							disabled: !can("users.update"),
							"aria-label": t("active"),
							onCheckedChange: (v) => toggle.mutate({
								id: s(u, "id"),
								active: v
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							lang === "ar" ? s(rel(u, "roles"), "name_ar") || s(rel(u, "roles"), "name") : s(rel(u, "roles"), "name"),
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								children: s(u, "phone") || "—"
							})
						]
					})]
				}, s(u, "id")))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("full_name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("email") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("phone") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("role") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "no-print",
							children: t("active")
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium",
							children: s(u, "full_name")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(u, "email")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							dir: "ltr",
							children: s(u, "phone") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: lang === "ar" ? s(rel(u, "roles"), "name_ar") || s(rel(u, "roles"), "name") : s(rel(u, "roles"), "name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "no-print",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: b(u, "active"),
								disabled: !can("users.update"),
								onCheckedChange: (v) => toggle.mutate({
									id: s(u, "id"),
									active: v
								})
							})
						})
					] }, s(u, "id"))) })]
				})
			})] })
		}) })
	] });
}
//#endregion
export { UsersPage as component };
