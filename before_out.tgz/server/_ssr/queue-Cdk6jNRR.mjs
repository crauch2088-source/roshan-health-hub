import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useRows, i as rel, l as useSave, o as s } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { W as Clock3, a as UserRound, et as Check, g as Search, w as Play } from "../_libs/lucide-react.mjs";
import { S as StatusBadge, c as Empty, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, v as PermissionGate, w as buttonVariants } from "./kit-BTyT-Kis.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { c as todayISO } from "./medical-CD1sc5il.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-By62ckhT.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/queue-Cdk6jNRR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"all",
	"waiting",
	"called",
	"in_progress",
	"completed",
	"cancelled"
];
function QueuePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "queue.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueuePageInner, {})
	});
}
function QueuePageInner() {
	const { lang, t } = useLang();
	const { can } = useAuth();
	const canUpdate = can("visits.update");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [status, setStatus] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const queue = useRows([
		"queue",
		date,
		status
	], () => {
		let q = supabase.from("queue_tickets").select("id,visit_id,queue_number,status,created_at,called_at,completed_at,visits(id,visit_number,patient_id,department_id,status,consultation_fee,patients(id,full_name,mrn),departments(id,name,name_ar),users!visits_doctor_id_fkey(full_name))").eq("visit_date", date).is("deleted_at", null).order("created_at", { ascending: true });
		if (status !== "all") q = q.eq("status", status);
		return q;
	}, { refetchInterval: 1e4 });
	const update = useSave(async ({ id, status }) => {
		if (!canUpdate) throw new Error("Not authorized");
		const patch = { status };
		if (status === "called") patch["called_at"] = (/* @__PURE__ */ new Date()).toISOString();
		if (status === "completed") patch["completed_at"] = (/* @__PURE__ */ new Date()).toISOString();
		const { error } = await supabase.from("queue_tickets").update(patch).eq("id", id);
		if (error) throw new Error(error.message);
		const ticket = (queue.data ?? []).find((r) => s(r, "id") === id);
		const visitId = s(ticket, "visit_id") || s(rel(ticket, "visits"), "id");
		if (visitId) {
			const visitStatus = status === "called" ? "in_progress" : status === "completed" ? "completed" : status === "cancelled" ? "cancelled" : "waiting";
			await supabase.from("visits").update({ status: visitStatus }).eq("id", visitId);
		}
		return null;
	}, {
		invalidate: [[
			"queue",
			date,
			status
		], ["visits", date]],
		successMessage: t("saved")
	});
	if (queue.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	const rows = (queue.data ?? []).filter((ticket) => {
		const patient = rel(rel(ticket, "visits"), "patients");
		const q = search.trim().toLowerCase();
		if (!q) return true;
		return [
			s(patient, "full_name"),
			s(patient, "mrn"),
			s(ticket, "queue_number")
		].some((x) => x.toLowerCase().includes(q));
	});
	const waiting = rows.filter((r) => s(r, "status") === "waiting").length;
	const active = rows.filter((r) => ["called", "in_progress"].includes(s(r, "status"))).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeader, {
				title: lang === "ar" ? "الطابور" : "Queue",
				subtitle: lang === "ar" ? "إدارة انتظار المرضى والنداء والانتقال للعيادة" : "Live patient queue and clinic flow",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						dir: "ltr",
						className: "w-40",
						value: date,
						onChange: (e) => setDate(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-56",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "ps-9",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: lang === "ar" ? "ابحث عن المريض أو رقم الطابور" : "Search patient or queue #"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: status,
						onValueChange: setStatus,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: STATUSES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: x,
							children: x === "all" ? lang === "ar" ? "الكل" : "All" : x
						}, x)) })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: queue.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground",
						children: lang === "ar" ? "بانتظار النداء" : "Waiting"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-3xl font-bold",
						children: waiting
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground",
						children: lang === "ar" ? "نشط" : "Active"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-3xl font-bold",
						children: active
					})]
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0",
				children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: t("no_data"),
					description: lang === "ar" ? "الطابور فارغ حالياً." : "The queue is empty right now."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y md:hidden",
					"aria-label": t("queue"),
					children: rows.map((ticket) => {
						const visit = rel(ticket, "visits");
						const patient = rel(visit, "patients");
						const dept = rel(visit, "departments");
						const doctor = rel(visit, "users");
						const st = s(ticket, "status");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "space-y-2 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-10 font-mono text-lg font-bold",
										dir: "ltr",
										children: s(ticket, "queue_number")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "break-words font-semibold",
												children: s(patient, "full_name")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												dir: "ltr",
												children: s(patient, "mrn")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-0.5 text-xs text-muted-foreground",
												children: [
													lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name"),
													" · ",
													s(doctor, "full_name") || "—"
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: st })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									canUpdate && st === "waiting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										className: "min-h-10 flex-1",
										onClick: () => update.mutate({
											id: s(ticket, "id"),
											status: "called"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), lang === "ar" ? "نداء" : "Call"]
									}),
									canUpdate && st === "called" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										className: "min-h-10 flex-1",
										onClick: () => update.mutate({
											id: s(ticket, "id"),
											status: "in_progress"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }), lang === "ar" ? "بدء" : "Start"]
									}),
									canUpdate && st === "in_progress" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										className: "min-h-10 flex-1",
										onClick: () => update.mutate({
											id: s(ticket, "id"),
											status: "completed"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), lang === "ar" ? "إنهاء" : "Complete"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/clinic/$visitId",
										params: { visitId: s(visit, "id") },
										className: buttonVariants({
											variant: "outline",
											size: "sm",
											className: "min-h-10 flex-1"
										}),
										children: t("clinic")
									})
								]
							})]
						}, s(ticket, "id"));
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden overflow-x-auto md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						density: "compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "#" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("patient") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("department") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("doctor") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("status") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-end",
								children: t("actions")
							})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((ticket) => {
							const visit = rel(ticket, "visits");
							const patient = rel(visit, "patients");
							const dept = rel(visit, "departments");
							const doctor = rel(visit, "users");
							const st = s(ticket, "status");
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									dir: "ltr",
									className: "font-mono font-bold",
									children: s(ticket, "queue_number")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: s(patient, "full_name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										dir: "ltr",
										children: s(patient, "mrn")
									})] })]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: lang === "ar" ? s(dept, "name_ar") || s(dept, "name") : s(dept, "name") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: s(doctor, "full_name") || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: st }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-end gap-1",
										children: [
											canUpdate && st === "waiting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												variant: "outline",
												onClick: () => update.mutate({
													id: s(ticket, "id"),
													status: "called"
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), lang === "ar" ? "نداء" : "Call"]
											}),
											canUpdate && st === "called" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												onClick: () => update.mutate({
													id: s(ticket, "id"),
													status: "in_progress"
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }), lang === "ar" ? "بدء" : "Start"]
											}),
											canUpdate && st === "in_progress" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												onClick: () => update.mutate({
													id: s(ticket, "id"),
													status: "completed"
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), lang === "ar" ? "إنهاء" : "Complete"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/clinic/$visitId",
												params: { visitId: s(visit, "id") },
												className: buttonVariants({
													variant: "ghost",
													size: "sm"
												}),
												children: t("clinic")
											})
										]
									})
								})
							] }, s(ticket, "id"));
						}) })]
					})
				})] })
			}) })
		]
	});
}
//#endregion
export { QueuePage as component };
