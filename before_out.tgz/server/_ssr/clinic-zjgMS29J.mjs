import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useRows, i as rel, o as s } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { S as StatusBadge, c as Empty, g as PageHeader, i as CardContent, l as ErrorBox, m as Loading, n as Button, p as Input, r as Card, u as ExportButtons, v as PermissionGate } from "./kit-BTyT-Kis.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C-rQyEey.mjs";
import { a as formatDate, c as todayISO, i as calcAge } from "./medical-CD1sc5il.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/clinic-zjgMS29J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClinicPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
		perm: "visits.read",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClinicPageInner, {})
	});
}
function ClinicPageInner() {
	const { lang } = useLang();
	const { user } = useAuth();
	const [search, setSearch] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [filterMyPatients, setFilterMyPatients] = (0, import_react.useState)(false);
	const nextDate = (() => {
		const d = /* @__PURE__ */ new Date(`${date}T00:00:00+02:00`);
		d.setDate(d.getDate() + 1);
		return d.toISOString();
	})();
	const visits = useRows([
		"clinic-visits",
		date,
		filterMyPatients,
		user?.id ?? ""
	], () => supabase.from("visits").select(`
            id,
            visit_number,
            status,
            created_at,
            visit_date,
            patient_id,
            doctor_id,
            patients(
              id,
              full_name,
              mrn,
              phone,
              date_of_birth,
              gender
            ),
            departments(
              name,
              name_ar
            ),
            users(
              full_name
            )
          `).gte("visit_date", (/* @__PURE__ */ new Date(`${date}T00:00:00+02:00`)).toISOString()).lt("visit_date", nextDate).is("deleted_at", null).order("visit_date", { ascending: true }));
	const rows = (visits.data ?? []).filter((visit) => {
		if (filterMyPatients && user?.id && s(visit, "doctor_id") !== user.id) return false;
		if (status !== "all" && s(visit, "status") !== status) return false;
		const term = search.trim().toLowerCase();
		if (!term) return true;
		const patient = rel(visit, "patients");
		const dept = rel(visit, "departments");
		return `${s(patient, "full_name")} ${s(patient, "mrn")} ${s(patient, "phone")} ${s(visit, "visit_number")} ${s(dept, "name")} ${s(dept, "name_ar")}`.toLowerCase().includes(term);
	});
	if (visits.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: lang === "ar" ? "العيادة" : "Clinic",
				subtitle: formatDate(date),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: lang === "ar" ? "ابحث عن المريض" : "Search patient",
							className: "w-52"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "rounded-md border bg-background px-3 py-2 text-sm",
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: lang === "ar" ? "كل الحالات" : "All statuses"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "waiting",
									children: "Waiting"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "in_progress",
									children: "In progress"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "completed",
									children: "Completed"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: filterMyPatients ? "default" : "outline",
							size: "sm",
							type: "button",
							onClick: () => setFilterMyPatients((current) => !current),
							children: lang === "ar" ? "مرضاي فقط" : "My Patients"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							dir: "ltr",
							value: date,
							onChange: (e) => setDate(e.target.value),
							className: "w-40"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButtons, {
							rows,
							filename: `roshan-clinic-${date}`
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error: visits.error }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "overflow-x-auto p-0",
				children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					density: "compact",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "المريض" : "Patient" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "العمر / الجنس" : "Age / Gender" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "القسم" : "Department" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: lang === "ar" ? "الحالة" : "Status" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-end",
							children: lang === "ar" ? "الإجراء" : "Action"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((visit) => {
						const patient = rel(visit, "patients");
						const department = rel(visit, "departments");
						const patientId = s(patient, "id");
						const visitId = s(visit, "id");
						const dob = s(patient, "date_of_birth");
						const ageVal = calcAge(dob);
						const ageStr = ageVal !== null ? `${ageVal} yrs` : "—";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "whitespace-nowrap font-medium",
								children: [s(patient, "full_name") || "—", s(patient, "mrn") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ms-2 text-xs text-muted-foreground",
									dir: "ltr",
									children: s(patient, "mrn")
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "whitespace-nowrap text-xs text-muted-foreground",
								children: [ageStr, s(patient, "gender") ? ` (${s(patient, "gender")})` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap",
								children: lang === "ar" ? s(department, "name_ar") || s(department, "name") || "—" : s(department, "name") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s(visit, "status") }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap text-end",
								children: visitId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/clinic/$visitId",
									params: { visitId },
									className: "inline-flex h-8 items-center justify-center gap-2 whitespace-nowrap rounded-md bg-primary px-3 text-xs font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
									title: lang === "ar" ? `فتح زيارة ${s(visit, "visit_number")}` : `Open visit ${s(visit, "visit_number")}`,
									children: lang === "ar" ? "فتح" : "Open"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									disabled: true,
									title: lang === "ar" ? "معرّف الزيارة غير موجود" : "Visit ID is missing",
									children: lang === "ar" ? "فتح" : "Open"
								})
							})
						] }, visitId || `${patientId}-${s(visit, "created_at")}`);
					}) })]
				})
			}) })
		]
	});
}
//#endregion
export { ClinicPage as component };
