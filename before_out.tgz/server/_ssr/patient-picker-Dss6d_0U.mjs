import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as dbError, r as supabase } from "./supabase-CqpbQBDM.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as useRows, o as s, r as n } from "./db-DHEMzLVy.mjs";
import { i as useLang } from "./router-STLCkGVF.mjs";
import { et as Check, o as UserPlus, q as ChevronsUpDown } from "../_libs/lucide-react.mjs";
import { T as cn, n as Button } from "./kit-BTyT-Kis.mjs";
import { a as formatDate, s as money } from "./medical-CD1sc5il.mjs";
import { a as CommandItem, i as CommandInput, n as CommandEmpty, o as CommandList, r as CommandGroup, t as Command$1 } from "./command-D8Wfp1Av.mjs";
import { a as useDebounced, n as patientPickerQuery } from "./search-DYiW-B_v.mjs";
import { i as PopoverTrigger$1, n as PopoverContent$1, r as PopoverPortal, t as Popover$1 } from "../_libs/@radix-ui/react-popover+[...].mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/patient-picker-Dss6d_0U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Popover = Popover$1;
var PopoverTrigger = PopoverTrigger$1;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent$1, {
	ref,
	align,
	sideOffset,
	className: cn("z-[10050] pointer-events-auto w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}) }));
PopoverContent.displayName = PopoverContent$1.displayName;
/**
* Patient search-and-select combobox. Built on the shared `patientPickerQuery`
* from lib/search.ts (name / MRN / phone / national ID, MRN-first) so this
* doesn't become a second, slightly-different patient search implementation.
*
* Inside modal Dialogs (e.g. New Visit):
* - Popover is modal so focus is managed correctly with the parent Dialog
* - Content width is measured from the trigger (Radix Popover does NOT set
*   --radix-popover-trigger-width the way Select does)
* - pointer-events-auto is applied at the PopoverContent primitive level
*/
function PatientPicker({ value, onSelect, placeholder, autoFocus }) {
	const { t } = useLang();
	const [open, setOpen] = (0, import_react.useState)(Boolean(autoFocus));
	const [term, setTerm] = (0, import_react.useState)("");
	const debounced = useDebounced(term, 300);
	const triggerRef = (0, import_react.useRef)(null);
	const [triggerWidth, setTriggerWidth] = (0, import_react.useState)(void 0);
	const results = useRows(["patient-picker", debounced], () => patientPickerQuery(debounced), { enabled: open });
	const rows = results.data ?? [];
	const searching = term.length > 0 && (results.isFetching || term !== debounced);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const el = triggerRef.current;
		if (!el) return;
		const update = () => setTriggerWidth(el.offsetWidth);
		update();
		const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(update) : null;
		ro?.observe(el);
		return () => ro?.disconnect();
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		modal: true,
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				ref: triggerRef,
				type: "button",
				variant: "outline",
				role: "combobox",
				"aria-expanded": open,
				className: "w-full justify-between font-normal text-start",
				children: [value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "truncate",
					children: [
						value.full_name,
						" — ",
						value.mrn || value.phone || "—"
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: placeholder ?? t("search_patient_placeholder")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, {
					className: "ms-2 size-4 shrink-0 opacity-50",
					"aria-hidden": true
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			align: "start",
			sideOffset: 4,
			collisionPadding: 12,
			style: triggerWidth ? { width: triggerWidth } : void 0,
			className: "max-w-[calc(100vw-1.5rem)] overflow-hidden p-0 shadow-xl",
			onOpenAutoFocus: (e) => {
				e.preventDefault();
				const input = e.currentTarget.querySelector("[cmdk-input], input");
				requestAnimationFrame(() => input?.focus());
			},
			onCloseAutoFocus: (e) => {
				e.preventDefault();
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, {
				shouldFilter: false,
				className: "pointer-events-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
					value: term,
					onValueChange: setTerm,
					placeholder: t("search_patient_placeholder")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandList, {
					className: "max-h-[min(280px,40vh)] overscroll-contain",
					children: searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-6 text-center text-sm text-muted-foreground",
						children: t("loading")
					}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-2 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: t("no_results")
						}), term.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/patients",
							className: "inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline",
							onClick: () => setOpen(false),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3.5" }),
								" ",
								t("add_new_patient")
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-[220px] text-center text-xs text-muted-foreground",
							children: t("duplicate_patient_hint")
						})] }) : null]
					}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
						heading: term.trim() ? void 0 : t("recent_patients"),
						children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
							value: s(p, "id"),
							onSelect: () => {
								onSelect({
									id: s(p, "id"),
									full_name: s(p, "full_name"),
									mrn: s(p, "mrn"),
									phone: s(p, "phone")
								});
								setOpen(false);
								setTerm("");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								"aria-hidden": true,
								className: cn("me-2 size-4", value?.id === s(p, "id") ? "opacity-100" : "opacity-0")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 flex-col",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-medium",
									children: s(p, "full_name")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "truncate text-xs text-muted-foreground",
									dir: "ltr",
									children: [
										s(p, "mrn") || "—",
										" · ",
										s(p, "phone") || "—"
									]
								})]
							})]
						}, s(p, "id")))
					})
				})]
			})
		})]
	});
}
/**
* Previous-visits count, last visit date, and outstanding invoice balance
* for a selected patient — shown under the picker so reception can spot
* "this patient owes money" or "they were just here yesterday" before
* confirming the new visit.
*
* The visit count is resolved with a PostgREST exact count + a single row
* instead of downloading the patient's whole visit history just to call
* `.length` on it. Query keys are unchanged so existing invalidations
* (visits, consultation finish) still refresh this strip.
*/
function usePatientSnapshot(patientId) {
	const enabled = Boolean(patientId);
	const visits = useQuery({
		queryKey: ["patient-snapshot-visits", patientId ?? ""],
		enabled,
		retry: false,
		queryFn: async () => {
			const { data, error, count } = await supabase.from("visits").select("visit_date", { count: "exact" }).eq("patient_id", patientId).is("deleted_at", null).order("visit_date", { ascending: false }).limit(1);
			if (error) throw new Error(dbError(error));
			const rows = data ?? [];
			return {
				count: count ?? rows.length,
				last: rows[0] ? s(rows[0], "visit_date") : null
			};
		}
	});
	const invoices = useQuery({
		queryKey: ["patient-snapshot-invoices", patientId ?? ""],
		enabled,
		retry: false,
		queryFn: async () => {
			const { data, error } = await supabase.from("invoices").select("net_amount, paid_amount").eq("patient_id", patientId).is("deleted_at", null).limit(1e3);
			if (error) throw new Error(dbError(error));
			return (data ?? []).reduce((sum, inv) => sum + n(inv, "net_amount") - n(inv, "paid_amount"), 0);
		}
	});
	return {
		isLoading: visits.isLoading || invoices.isLoading,
		visitsCount: visits.data?.count ?? 0,
		lastVisitDate: visits.data?.last ?? null,
		outstandingBalance: invoices.data ?? 0
	};
}
/** Small inline strip rendered under the picker once a patient is selected. */
function PatientSnapshotStrip({ patientId, currency }) {
	const { t } = useLang();
	const snap = usePatientSnapshot(patientId);
	if (snap.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 h-9 animate-pulse rounded-md bg-muted/60",
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 flex flex-wrap gap-x-4 gap-y-1 rounded-md border border-border/70 bg-muted/35 px-3 py-2 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted-foreground",
				children: [t("previous_visits"), ": "]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				dir: "ltr",
				children: snap.visitsCount
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted-foreground",
				children: [t("last_visit"), ": "]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				dir: "ltr",
				children: snap.lastVisitDate ? formatDate(snap.lastVisitDate) : "—"
			})] }),
			snap.outstandingBalance > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted-foreground",
				children: [t("outstanding_balance"), ": "]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold text-destructive",
				dir: "ltr",
				children: money(snap.outstandingBalance, currency)
			})] }) : null
		]
	});
}
//#endregion
export { PatientSnapshotStrip as n, PatientPicker as t };
