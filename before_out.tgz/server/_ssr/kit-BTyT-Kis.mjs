import { i as __toESM } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as csvExport } from "./db-DHEMzLVy.mjs";
import { a as useAuth, i as useLang } from "./router-STLCkGVF.mjs";
import { A as LoaderCircle, F as Inbox, H as FileDown, Q as ChevronLeft, S as Printer, Z as ChevronRight, c as TriangleAlert, p as ShieldOff } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Label$1 } from "../_libs/radix-ui__react-label.mjs";
//#region ../repo/node_modules/.nitro/vite/services/ssr/assets/kit-BTyT-Kis.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-semibold cursor-pointer transition-[background-color,color,border-color,box-shadow,transform] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 focus-visible:ring-offset-1 focus-visible:ring-offset-background active:translate-y-px disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed disabled:translate-y-0 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-sm hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent/80 hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4 py-2 sm:h-9",
			sm: "h-9 rounded-md px-3 text-xs sm:h-8",
			lg: "h-11 rounded-md px-6",
			icon: "size-10 sm:size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-lg border border-border/70 bg-card text-card-foreground shadow-xs", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col space-y-1.5 p-4 sm:p-5", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("font-semibold leading-none tracking-tight", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-4 pt-0 sm:p-5 sm:pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var CardFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center p-4 pt-0 sm:p-5 sm:pt-0", className),
	...props
}));
CardFooter.displayName = "CardFooter";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base shadow-xs transition-[border-color,box-shadow] placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/20 disabled:cursor-not-allowed disabled:bg-muted/40 disabled:opacity-60 md:h-9 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Label$1.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full resize-y rounded-md border border-input bg-background px-3 py-2 text-base shadow-xs transition-[border-color,box-shadow] placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/20 disabled:cursor-not-allowed disabled:bg-muted/40 disabled:opacity-60 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function PageHeader({ title, subtitle, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "no-print mb-5 grid grid-cols-1 items-end gap-3 sm:mb-6 sm:grid-cols-[minmax(0,1fr)_auto]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 space-y-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "truncate text-xl font-bold text-foreground sm:text-2xl",
				children: title
			}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-sm text-muted-foreground",
				children: subtitle
			}) : null]
		}), children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex w-full flex-wrap items-center gap-2 sm:w-auto sm:justify-end [&>*]:max-w-full",
			children
		}) : null]
	});
}
function Loading() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-24 items-center justify-center gap-2 p-6 text-sm text-muted-foreground",
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }),
			" ",
			t("loading")
		]
	});
}
/** Skeleton rows for table/list areas — used where a spinner alone reads as "stuck" on slower connections. */
function LoadingRows({ count = 4 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 p-4",
		role: "status",
		children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full animate-pulse rounded-md bg-muted/60" }, i))
	});
}
function ErrorBox({ error }) {
	if (!error) return null;
	const message = error instanceof Error ? error.message : String(error);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/15 p-3 text-sm text-destructive",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "break-words",
			children: message
		})]
	});
}
function Empty({ label, title, description, action, icon }) {
	const { t } = useLang();
	const heading = title ?? label ?? t("no_data");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 px-5 py-10 text-center sm:py-12",
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-11 items-center justify-center rounded-lg bg-muted/80 text-muted-foreground",
				children: icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, {
					className: "size-5",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-foreground",
					children: heading
				}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-xs text-muted-foreground",
					children: description
				}) : null]
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pt-1",
				children: action
			}) : null
		]
	});
}
/** Full-page access denied state used by PermissionGate. */
function Forbidden({ message }) {
	const { t, lang } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[50vh] flex-col items-center justify-center gap-4 px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, {
					className: "size-6",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight",
					children: lang === "ar" ? "غير مصرح" : "Access denied"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm text-muted-foreground",
					children: message ?? t("no_permission")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					children: lang === "ar" ? "العودة للرئيسية" : "Back to dashboard"
				})
			})
		]
	});
}
/**
* Gate that renders children only when the user holds the required permission.
* Fails closed while permissions are loading or when the user lacks access.
*/
function PermissionGate({ perm, children, fallback }) {
	const { can, permissionsReady, loading } = useAuth();
	if (loading || !permissionsReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {});
	if (!(Array.isArray(perm) ? perm : [perm]).some((p) => can(p))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Forbidden, {}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function StatCard({ label, value, hint, tone = "default", icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "overflow-hidden transition-[border-color,box-shadow] duration-200 hover:border-primary/25 hover:shadow-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex items-center justify-between gap-3 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs font-medium text-muted-foreground",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-1 text-2xl font-bold tabular-nums leading-tight", {
							default: "text-foreground",
							primary: "text-primary",
							success: "text-success",
							warning: "text-warning",
							destructive: "text-destructive"
						}[tone]),
						children: value
					}),
					hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted-foreground",
						children: hint
					}) : null
				]
			}), icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("shrink-0 rounded-lg p-2.5", {
					default: "bg-accent text-foreground",
					primary: "bg-primary/10 text-primary",
					success: "bg-success/10 text-success",
					warning: "bg-warning/10 text-warning",
					destructive: "bg-destructive/10 text-destructive"
				}[tone]),
				children: icon
			}) : null]
		})
	});
}
function Field({ label, children, hint, className }) {
	const uid = (0, import_react.useId)();
	const labelId = `${uid}-label`;
	const hintId = `${uid}-hint`;
	const control = (0, import_react.isValidElement)(children) && (children.type === Input || children.type === Textarea) ? children : null;
	const controlId = control ? control.props.id ?? `${uid}-control` : null;
	const rendered = control && controlId ? (0, import_react.cloneElement)(control, {
		id: controlId,
		...hint && !control.props["aria-describedby"] ? { "aria-describedby": hintId } : {}
	}) : children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-1.5", className),
		role: "group",
		"aria-labelledby": labelId,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				id: labelId,
				...controlId ? { htmlFor: controlId } : {},
				className: "text-xs font-semibold text-foreground/80",
				children: label
			}),
			rendered,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: hintId,
				className: "text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
var statusTones = {
	waiting: "bg-warning/15 text-warning border-warning/30",
	pending: "bg-warning/15 text-warning border-warning/30",
	in_progress: "bg-primary/15 text-primary border-primary/30",
	collected: "bg-primary/15 text-primary border-primary/30",
	completed: "bg-success/15 text-success border-success/30",
	verified: "bg-success/15 text-success border-success/30",
	dispensed: "bg-success/15 text-success border-success/30",
	scheduled: "bg-primary/15 text-primary border-primary/30",
	paid: "bg-success/15 text-success border-success/30",
	partial: "bg-warning/15 text-warning border-warning/30",
	unpaid: "bg-destructive/15 text-destructive border-destructive/30",
	open: "bg-warning/15 text-warning border-warning/30",
	reversed: "bg-muted text-muted-foreground",
	cancelled: "bg-muted text-muted-foreground",
	no_show: "bg-muted text-muted-foreground",
	missed: "bg-destructive/15 text-destructive border-destructive/30",
	inactive: "bg-muted text-muted-foreground",
	active: "bg-success/15 text-success border-success/30",
	suspended: "bg-warning/15 text-warning border-warning/30",
	expired: "bg-destructive/15 text-destructive border-destructive/30",
	draft: "bg-muted text-muted-foreground",
	submitted: "bg-primary/15 text-primary border-primary/30",
	under_review: "bg-primary/15 text-primary border-primary/30",
	approved: "bg-success/15 text-success border-success/30",
	partially_approved: "bg-warning/15 text-warning border-warning/30",
	rejected: "bg-destructive/15 text-destructive border-destructive/30"
};
function StatusBadge({ status }) {
	const { t } = useLang();
	const key = (status || "").toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "outline",
		className: cn("font-medium transition-colors", statusTones[key] ?? ""),
		children: t(key) === key ? status || "—" : t(key)
	});
}
function ExportButtons({ rows, filename }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => csvExport(rows, filename),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "size-4" }),
				" ",
				t("export_excel")
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => window.print(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }),
				" ",
				t("print")
			]
		})]
	});
}
function PrintButton() {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size: "sm",
		className: "no-print",
		onClick: () => window.print(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }),
			" ",
			t("print")
		]
	});
}
/** Prev/next pagination bar for tables driven by usePagedRows(). */
function Pager({ page, pageCount, count, pageSize, hasPrev, hasNext, onPrev, onNext, isFetching }) {
	const { t } = useLang();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-t border-border/70 bg-muted/20 p-3 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: count != null ? `${t("page")} ${page} ${t("of")} ${pageCount ?? 1} · ${count} ${t("records")}` : `${t("page")} ${page}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				disabled: !hasPrev || isFetching,
				onClick: onPrev,
				"aria-label": t("previous"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 rtl:rotate-180" }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: t("previous")
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				disabled: !hasNext || isFetching,
				onClick: onNext,
				"aria-label": t("next"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: t("next")
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 rtl:rotate-180" })
				]
			})]
		})]
	});
}
function SectionTitle({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "mb-3 text-xs font-semibold text-foreground/75",
		children
	});
}
//#endregion
export { Textarea as C, StatusBadge as S, cn as T, Pager as _, CardDescription as a, SectionTitle as b, Empty as c, Field as d, Forbidden as f, PageHeader as g, LoadingRows as h, CardContent as i, ErrorBox as l, Loading as m, Button as n, CardHeader as o, Input as p, Card as r, CardTitle as s, Badge as t, ExportButtons as u, PermissionGate as v, buttonVariants as w, StatCard as x, PrintButton as y };
